package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.SosModel;

import java.util.List;

public class SosRequest {
    public int status;
    public SosModel data;
}