package com.dichvudacbiet.safetyfirst.model.network;

public class LocationRequest {

    public double lat;
    public double lng;
    public String schedule_id;
    public String info;
    public int type;
    public String call_number;
    public String number;

    private LocationRequest(Builder builder) {
        lat = builder.lat;
        lng = builder.lng;
        schedule_id = builder.schedule_id;
        info = builder.info;
        type = builder.type;
        number = builder.number;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private double lat;
        private double lng;
        private String schedule_id;
        private String info;
        private int type;
        private String number;

        private Builder() {
        }

        public Builder lat(double val) {
            lat = val;
            return this;
        }

        public Builder lng(double val) {
            lng = val;
            return this;
        }

        public Builder schedule_id(String val) {
            schedule_id = val;
            return this;
        }

        public Builder info(String val) {
            info = val;
            return this;
        }

        public Builder type(int val) {
            type = val;
            return this;
        }
        public Builder notify_to(String val) {
            number = val;
            return this;
        }

        public LocationRequest build() {
            return new LocationRequest(this);
        }
    }
}
