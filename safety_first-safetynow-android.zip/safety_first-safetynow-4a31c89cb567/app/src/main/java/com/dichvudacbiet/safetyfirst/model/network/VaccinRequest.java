package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.VaccinModel;

import java.util.ArrayList;

/**
 * Created by loi.doan on 12/18/17.
 */

public class VaccinRequest {
    public int success;
    public ArrayList<VaccinModel> data;
}
