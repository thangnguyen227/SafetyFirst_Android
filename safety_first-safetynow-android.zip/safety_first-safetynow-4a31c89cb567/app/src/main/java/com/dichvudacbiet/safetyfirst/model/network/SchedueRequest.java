package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.ScheduleModel;

import java.util.ArrayList;

public class SchedueRequest {

    public String success;
    public ArrayList<ScheduleModel> data;
}