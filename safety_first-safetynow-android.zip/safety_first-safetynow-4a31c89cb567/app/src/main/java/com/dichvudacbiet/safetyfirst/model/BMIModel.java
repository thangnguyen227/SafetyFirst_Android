package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by khant on 30/03/2018.
 */

public class BMIModel {
    public int id;
    public double score;
    public String content_html;
    public double weight;
    public double height;
    public String name;

    public BMIModel() {
    }

    public BMIModel(String name) {
        this.name = name;
    }

    public BMIModel(double weight, double height) {
        this.weight = weight;
        this.height = height;
    }

    public BMIModel(int weight, int height, String name) {
        this.weight = weight;
        this.height = height;
        this.name = name;
    }
}
