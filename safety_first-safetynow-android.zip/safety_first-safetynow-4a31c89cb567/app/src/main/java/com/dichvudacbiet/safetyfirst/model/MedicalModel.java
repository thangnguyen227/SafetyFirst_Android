package com.dichvudacbiet.safetyfirst.model;

import java.io.Serializable;

public class MedicalModel implements Serializable {
    public int id;
    public int country_id;
    public String name;
    public String address;
    public String contact_number;
    public String info;
    public int type;
    public String description;
}
