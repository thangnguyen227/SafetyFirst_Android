package com.dichvudacbiet.safetyfirst.model.network;

import java.util.List;

public class CountryEmerNumByCountryRequest {

    public int status;
    public List<EmergencyNumber> data;

    public class EmergencyNumber{
        public int country_id;
        public String name;
        public String phone;
        public String info;
    }
}