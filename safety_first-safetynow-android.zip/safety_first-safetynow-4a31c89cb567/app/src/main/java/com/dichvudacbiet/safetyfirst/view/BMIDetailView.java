
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.BMIModel;
import com.dichvudacbiet.safetyfirst.model.ScheduleModel;

import java.util.List;

public interface BMIDetailView extends BaseView {
    void navigateBack();
    void setData(List<ScheduleModel> listNews);
    void setBMIScore(BMIModel bmiModel);
    void setBodyBMI(String html);
}
