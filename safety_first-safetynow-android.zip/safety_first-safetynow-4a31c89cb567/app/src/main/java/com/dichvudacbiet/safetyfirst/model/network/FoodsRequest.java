package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.FoodsModel;

import java.util.ArrayList;

public class FoodsRequest {

    public int success;
    public ArrayList<FoodsModel> data;
}