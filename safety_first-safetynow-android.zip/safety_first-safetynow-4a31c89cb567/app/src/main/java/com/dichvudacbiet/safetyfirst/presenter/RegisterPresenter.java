
package com.dichvudacbiet.safetyfirst.presenter;

import android.util.Log;

import com.dichvudacbiet.safetyfirst.model.CountryModel;
import com.dichvudacbiet.safetyfirst.model.CoveringModel;
import com.dichvudacbiet.safetyfirst.model.JobModel;
import com.dichvudacbiet.safetyfirst.model.Language;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.Relation2Model;
import com.dichvudacbiet.safetyfirst.model.RelationModel;
import com.dichvudacbiet.safetyfirst.model.network.CountriesRequest;
import com.dichvudacbiet.safetyfirst.model.network.DataModel;
import com.dichvudacbiet.safetyfirst.model.network.JobRequest;
import com.dichvudacbiet.safetyfirst.model.network.RegisterRequest;
import com.dichvudacbiet.safetyfirst.model.network.RelationRequest;
import com.dichvudacbiet.safetyfirst.model.network.RespondData;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.RegisterView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RegisterPresenter extends BasePresenter<RegisterView> {

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            lodaData();
//            loadQuestions();
            loadCoutry();
            loadJob();
        }
    }

    private void loadCoutry() {
        if (isViewAttached()) {
            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_COUNTRY,null);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<LocationModel> respondData =  response.body().data;
                            getView().showCountryList(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }
    public void loadDataCity(int country_id) {
        if (isViewAttached()) {

            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_PROVINCE,country_id);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<LocationModel> respondData =  response.body().data;
                            getView().showCityList(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }

    public void loadJob() {
        if (isViewAttached()) {

            Call<JobRequest> call = ApiService.getClient().getJobs(PrefUtil.getTokenInfo(),Util.getLangCode());

            call.enqueue(new Callback<JobRequest>() {
                @Override
                public void onResponse(Call<JobRequest> call, Response<JobRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<JobModel> respondData =  response.body().data;
                            getView().showJobs(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<JobRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }

    public void loadDataAddress(final int id_city) {

        if (isViewAttached()) {

            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_DISTRICT,id_city);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<LocationModel> respondData =  response.body().data;
                            getView().showCoveringList(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }
    private void loadQuestions() {
        if (isViewAttached()) {

            Call<RelationRequest> call = ApiService.getClient().getRelation(Util.getLangCode());
            call.enqueue(new Callback<RelationRequest>() {
                @Override
                public void onResponse(Call<RelationRequest> call, Response<RelationRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<Relation2Model> respondData =  response.body().data;
                            getView().showRelation(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<RelationRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }

    private void lodaData() {
        if (isViewAttached()) {

            Call<RelationRequest> call = ApiService.getClient().getRelation(Util.getLangCode());
            call.enqueue(new Callback<RelationRequest>() {
                @Override
                public void onResponse(Call<RelationRequest> call, Response<RelationRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<Relation2Model> respondData =  response.body().data;
                            getView().showRelation(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                       getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<RelationRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }

    public void onRegister(String name, String address, String phone, String mobile, String job) {
        if (isViewAttached()) {
            int errMsg = Util.validateInput(name, mobile, mobile, job);
            if (errMsg != -1) {
                getView().showMessage(errMsg, false);
                return;
            }
            getView().showRelations(name, address , phone , mobile , job);
        }
    }



    public void onRegisterServer(String name, String address, String phone, String mobile, int job_id , int mIdAddress , ArrayList<RelationModel> relations) {
        if (isViewAttached()) {

            Object mData =RegisterRequest.newBuilder()
                    .name(name).address("").phone(mobile).mobile(mobile).job(job_id).relations(relations).living_location_id(mIdAddress)
                    .device_id(PrefUtil.getDeviceInfo().deviceId).fcm_token(PrefUtil.getDeviceInfo().deviceId).language_code(Util.getLangCode());
            Log.d("/////",PrefUtil.getDeviceInfo().deviceId);
            Call<RespondData> call = ApiService.getClient().getRegister(mData, Util.getLangCode());
            call.enqueue(new Callback<RespondData>() {
                @Override
                public void onResponse(Call<RespondData> call, Response<RespondData> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                                PrefUtil.setUserInfo(response.body().data);
                                PrefUtil.setTokenInfo(response.body().data.token);
                                getView().backToHome();

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu", false);
                    }

                }
                @Override
                public void onFailure(Call<RespondData> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }
            });
        }
    }


    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }

}
