package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.Answer;
import com.google.gson.annotations.SerializedName;
import com.dichvudacbiet.safetyfirst.model.RelationModel;

import java.util.ArrayList;

public class UpdateProfileRequest {
    public int user_id;
    public String fullname;
    public String address;
    public String phone_number;
    public String mobile_number;
    public String job;
    public int job_id;
    public String fcm_token;
    public String language_code;
    public ArrayList<RelationModel> relations;
    public ArrayList<Answer> answers;

    private UpdateProfileRequest(Builder builder) {
        user_id = builder.user_id;
        fullname = builder.fullname;
        address = builder.address;
        phone_number = builder.phone_number;
        mobile_number = builder.mobile_number;
        job = builder.job;
        relations = builder.relations;
        job_id = builder.job_id;
        fcm_token = builder.fcm_token;
        language_code = builder.language_code;
        answers = builder.answers;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private int user_id;
        private String fullname;
        private String address;
        private String phone_number;
        private String mobile_number;
        private String job;
        public int job_id;
        public String fcm_token;
        public String language_code;
        private ArrayList<RelationModel> relations;
        private ArrayList<Answer> answers;

        private Builder() {
        }
        public Builder user_id(int val) {
            user_id = val;
            return this;
        }
        public Builder name(String val) {
            fullname = val;
            return this;
        }

        public Builder address(String val) {
            address = val;
            return this;
        }

        public Builder phone(String val) {
            phone_number = val;
            return this;
        }

        public Builder mobile(String val) {
            mobile_number = val;
            return this;
        }

        public Builder job(String val) {
            job = val;
            return this;
        }

        public Builder fcm_token(String val) {
            fcm_token = val;
            return this;
        }

        public Builder job_id(int val) {
            job_id = val;
            return this;
        }

        public Builder language_code(String val) {
            language_code = val;
            return this;
        }

        public Builder relations(ArrayList<RelationModel> val) {
            relations = val;
            return this;
        }
        public Builder answers(ArrayList<Answer> val) {
            answers = val;
            return this;
        }

        public UpdateProfileRequest build() {
            return new UpdateProfileRequest(this);
        }
    }
}
