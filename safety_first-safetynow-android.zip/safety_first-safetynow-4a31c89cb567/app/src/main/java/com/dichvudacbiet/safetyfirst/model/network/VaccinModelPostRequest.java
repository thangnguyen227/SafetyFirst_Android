package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.VaccinInfoModel;

import java.util.List;

/**
 * Created by khant on 14/03/2018.
 */

public class VaccinModelPostRequest {
    public int id;
    public String name;
    public String gender;
    public String birthday;
    public String birth_weight;
    public String birth_height;
    public List<VaccinInfoModel> vaccination_info;

    public VaccinModelPostRequest(Builder builder) {
        id = builder.id;
        name = builder.name;
        gender = builder.gender;
        birthday = builder.birthday;
        birth_weight = builder.birth_weight;
        birth_height = builder.birth_height;
        vaccination_info =builder.schedules;
    }


    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private int id;
        private String name;
        private String gender;
        private String birthday;
        private String birth_weight;
        private String birth_height;
        private List<VaccinInfoModel> schedules;

        private Builder() {
        }

        public Builder schedules(List<VaccinInfoModel> val) {
            schedules = val;
//            for(int i =0 ; i < val.size(); i++){
////                for(int j =0 ;j< val.get(i).schedules.size();j++){
////                    VaccinInfoModel ob = new VaccinInfoModel(val.get(i).schedules.get(j).id,val.get(i).schedules.get(j).date_time);
////                    schedules.add(ob);
////                }
//                if(val.get(i).isChoose){
//                    schedules.add(val.get(i));
//                }
//
//            }
            return this;
        }

        public Builder id(int val) {
            id = val;
            return this;
        }

        public Builder name(String val) {
            name = val;
            return this;
        }

        public Builder gender(String val) {
            gender = val;
            return this;
        }

        public Builder birthday(String val) {
            birthday = val;
            return this;
        }

        public Builder birth_weight(String val) {
            birth_weight = val;
            return this;
        }

        public Builder birth_height(String val) {
            birth_height = val;
            return this;
        }


        public VaccinModelPostRequest build() {
            return new VaccinModelPostRequest(this);
        }
    }
}
