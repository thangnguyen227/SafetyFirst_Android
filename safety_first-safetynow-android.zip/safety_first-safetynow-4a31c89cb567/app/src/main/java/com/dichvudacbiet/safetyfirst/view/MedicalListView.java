
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.MedicalModel;

import java.util.List;

public interface MedicalListView extends BaseView {
    void navigateBack();
    void setData(List<MedicalModel> listNews);
    void openMedicalDetailView(MedicalModel medicalModel);
}
