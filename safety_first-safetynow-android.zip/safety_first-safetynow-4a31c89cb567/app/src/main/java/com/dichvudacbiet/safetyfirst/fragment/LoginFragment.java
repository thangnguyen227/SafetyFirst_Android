
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.activity.LoginActivity;
import com.dichvudacbiet.safetyfirst.presenter.LoginPresenter;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.LoginView;


public class LoginFragment extends BaseFragment<LoginView, LoginPresenter>
        implements LoginView, View.OnClickListener {

    private TextInputLayout inputLayoutEmail;
    private TextInputLayout inputLayoutPassword;
    private boolean isClick = false;
    private Button btnLogin;
    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_login;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView tvRegister = (TextView) view.findViewById(R.id.login_tvRegister);
        tvRegister.setOnClickListener(this);

        inputLayoutEmail = (TextInputLayout) view.findViewById(R.id.login_inputLayoutEmail);
        inputLayoutPassword = (TextInputLayout) view.findViewById(R.id.login_inputLayoutPassword);
        inputLayoutPassword.setVisibility(View.GONE);
        btnLogin = (Button) view.findViewById(R.id.login_btnLogin);
        btnLogin.setOnClickListener(this);
    }

    @Override
    public void onDestroyView() {
        Util.hideKeyboard(getActivity());
        super.onDestroyView();
    }

    @NonNull
    @Override
    public LoginPresenter createPresenter() {
        return new LoginPresenter();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.login_btnLogin:
                /*if(btnLogin.getText().equals("Đăng nhập")){
                    String email = Util.safelyGetTextFromEditText(inputLayoutEmail.getEditText());
                    String password = Util.safelyGetTextFromEditText(inputLayoutPassword.getEditText());
                    getPresenter().onLoginOTP(email , password);
                }else{
                    String email = Util.safelyGetTextFromEditText(inputLayoutEmail.getEditText());
                    getPresenter().onLoginEmail(email);
                }

*/
                break;
            case R.id.login_tvRegister:
                ((BaseActivity) getActivity()).pushFragment(new RegisterFragment(), true);
                break;
        }
    }

    @Override
    public void loginOTP(String phone, String otp) {
        ((LoginActivity) getActivity()).loginPhone(phone , otp);
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

}
