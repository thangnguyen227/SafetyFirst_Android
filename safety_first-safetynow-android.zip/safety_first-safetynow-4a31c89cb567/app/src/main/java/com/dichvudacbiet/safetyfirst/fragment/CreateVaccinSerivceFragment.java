
package com.dichvudacbiet.safetyfirst.fragment;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.presenter.CreateVaccinServicePresenter;
import com.dichvudacbiet.safetyfirst.util.AlertUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.CreateVaccinServiceView;

import java.util.Calendar;


public class CreateVaccinSerivceFragment extends BaseFragment<CreateVaccinServiceView, CreateVaccinServicePresenter>
        implements CreateVaccinServiceView, View.OnClickListener {

    private TextView mToolbarTitle;
    private Calendar myCalendar;
    private DatePickerDialog.OnDateSetListener date;

    private TextInputLayout register_inputLayoutbabyname;
    private TextView tv_babybirthday;
    private RadioGroup rdgroup_gender;
    private TextInputLayout register_inputLayoutbabyweight;
    private TextInputLayout register_inputLayoutbabyheight;
    private Button mCreate, mSchedule;

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_update_vaccin_service;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);
        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.create_vaccin_service));
        mToolbarTitle.setVisibility(View.VISIBLE);

        //
        myCalendar = Calendar.getInstance();
        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            }

        };

        //
        register_inputLayoutbabyname = view.findViewById(R.id.register_inputLayoutbabyname);
        tv_babybirthday = view.findViewById(R.id.tv_babybirthday);
        rdgroup_gender = view.findViewById(R.id.rdgroup_gender);
        register_inputLayoutbabyweight = view.findViewById(R.id.register_inputLayoutbabyweight);
        register_inputLayoutbabyheight = view.findViewById(R.id.register_inputLayoutbabyheight);
        tv_babybirthday.setOnClickListener(this);


        mCreate = (Button) view.findViewById(R.id.btn_update);
        mCreate.setOnClickListener(this);


        mSchedule = view.findViewById(R.id.btn_vaccin_list);
        mSchedule.setOnClickListener(this);

        if (Session.VACCIN_UPDATE_OR_CREATE != 0)
            initViewUpdate();
        else{
            mCreate.setText(getString(R.string.create_information));
            mSchedule.setVisibility(View.GONE);
        }

    }

    @NonNull
    @Override
    public CreateVaccinServicePresenter createPresenter() {
        return new CreateVaccinServicePresenter();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
            case R.id.tv_babybirthday:
                AlertUtil.showDatePickerDialog(getContext(), tv_babybirthday, true);
                break;

            case R.id.btn_update:
                int sex;
                String gender = ((RadioButton) getView().findViewById(rdgroup_gender.getCheckedRadioButtonId())).getText().toString();
                if(gender.equals("female")){
                    sex = 1;
                }else{
                    sex = 0;
                }
                String name = Util.safelyGetTextFromEditText(register_inputLayoutbabyname.getEditText());
                String birthday = tv_babybirthday.getText().toString();
                String birth_weight = Util.safelyGetTextFromEditText(register_inputLayoutbabyweight.getEditText());
                String birth_height = Util.safelyGetTextFromEditText(register_inputLayoutbabyheight.getEditText());
                if (Session.VACCIN_UPDATE_OR_CREATE == 0) {
                    try {
                        getPresenter().onPostVaccinInfo(name, birthday, sex, birth_weight, birth_height);
                    } catch (Exception ex) {

                    }
                } else {
                    try {

                        Session.vaccinModel.fullname = name;
                        Session.vaccinModel.birth_date = birthday;

                        Session.vaccinModel.gender = sex;
                        Session.vaccinModel.birth_weight = birth_weight;
                        Session.vaccinModel.birth_height = birth_height;
                        getPresenter().updateVaccinInfo(Session.vaccinModel);
                    } catch (Exception ex) {

                    }
                }
                break;

            case R.id.btn_vaccin_list:
                navigateToCreateVaccinSchedule();
                break;
        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void navigateToCreateVaccinSchedule() {
        //        ((BaseActivity) getActivity()).pushFragment(new CreateVaccinScheduleFragment(Session.vaccinModel.vaccination_info), true);
//        ((BaseActivity) getActivity()).pushFragment(new CreateVaccinScheduleFragment(Session.vaccinRequestObject.data.vaccination_info), true);
        ((BaseActivity) getActivity()).pushFragment(new CreateVaccinScheduleFragment(Session.vaccinModel.vaccinations), true);
    }


    @Override
    public void showMessage(int message, boolean success) {
        super.showMessage(message, success);
        Toast.makeText(getActivity(), getResources().getString(message), Toast.LENGTH_SHORT).show();
    }



    private void initViewUpdate() {
        register_inputLayoutbabyname.getEditText().setText(Session.vaccinModel.fullname);
        tv_babybirthday.setText(Session.vaccinModel.birth_date);
        if (Session.vaccinModel.gender == 0) {
            ((RadioButton) rdgroup_gender.getChildAt(0)).setChecked(true);
        } else {
            ((RadioButton) rdgroup_gender.getChildAt(1)).setChecked(true);
        }
        register_inputLayoutbabyweight.getEditText().setText(Session.vaccinModel.birth_weight + "");
        register_inputLayoutbabyheight.getEditText().setText(Session.vaccinModel.birth_height + "");
    }
}
