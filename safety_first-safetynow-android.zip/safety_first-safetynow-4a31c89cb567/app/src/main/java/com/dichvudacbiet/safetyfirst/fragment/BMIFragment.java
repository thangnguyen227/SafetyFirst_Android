
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.BMIAdapter;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.adapter.SOSAdapter;
import com.dichvudacbiet.safetyfirst.model.BMIModel;
import com.dichvudacbiet.safetyfirst.model.SosModel;
import com.dichvudacbiet.safetyfirst.presenter.BMIPresenter;
import com.dichvudacbiet.safetyfirst.presenter.SosPresenter;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.view.BMIView;
import com.dichvudacbiet.safetyfirst.view.SosView;

import java.util.List;


public class BMIFragment extends BaseFragment<BMIView, BMIPresenter>
        implements BMIView, View.OnClickListener , RecyclerViewOnItemClickedListener<BMIModel> {

    private RecyclerView rvList;
    private BMIAdapter adapter;

    private TextView mToolbarTitle;
    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_bmi;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);

        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.bmi_score));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //

        adapter = new BMIAdapter();
        adapter.setOnItemClickListener(this);
        rvList = view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rvList.setAdapter(adapter);
    }

    @NonNull
    @Override
    public BMIPresenter createPresenter() {
        return new BMIPresenter();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }


    @Override
    public void setData(List<BMIModel> listNews) {
        adapter.setListNews(listNews);
        adapter.notifyDataSetChanged();
    }



    @Override
    public void onItemClicked(RecyclerView recyclerView, BMIModel bmiModel, int position) {
        Fragment fragment = BMIDetailFragment.newInstance(position);
        ((BaseActivity) getActivity()).pushFragment(fragment, true);
    }

}
