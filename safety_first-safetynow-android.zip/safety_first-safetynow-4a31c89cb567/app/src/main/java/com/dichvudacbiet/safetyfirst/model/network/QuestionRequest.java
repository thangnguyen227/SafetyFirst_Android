package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.QuestionModel;

import java.util.ArrayList;

public class QuestionRequest {

    public String success;
    public ArrayList<QuestionModel> data;
}