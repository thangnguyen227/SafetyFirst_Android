
package com.dichvudacbiet.safetyfirst.model;

import android.util.Log;

import java.util.ArrayList;



public class UserInfo {

    public int id;
    public String fullname = "";
    public String avatar = "";
    public String email = "";
    public String address = "";
    public String phone_number = "";
    public String mobile_number ="";
    public String emergency ="";
    public String hospital ="";
    public String fire ="";
    public String police ="";
    public JobModel job;
    public String token;
    public LocationModel living_location;
    public int role ;
    public String language_code ;
    public String fcm_token ;

    public ArrayList<RelationModel> relations;

    public void getType_id(){
        for(int i = 0; i<relations.size();i++){
            relations.get(i).type_id = relations.get(i).type.id;
        }

    }
}
