package com.dichvudacbiet.safetyfirst.adapter;

import android.support.v7.widget.RecyclerView;

public interface RecyclerViewVaccinOnItemClickedListener<T> {

    void onItemClicked(RecyclerView recyclerView, T t, int position);
}