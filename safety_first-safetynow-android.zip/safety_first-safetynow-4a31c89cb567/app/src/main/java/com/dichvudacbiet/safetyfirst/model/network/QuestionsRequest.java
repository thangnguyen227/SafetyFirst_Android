package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.QuestionModel;

import java.util.ArrayList;

public class QuestionsRequest {


    public ArrayList<QuestionModel> questions;

    private QuestionsRequest(Builder builder) {
        questions = builder.questions;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private ArrayList<QuestionModel> questions;
        private Builder() {
        }

        public Builder questions(ArrayList<QuestionModel> val) {
            questions = val;
            return this;
        }

        public QuestionsRequest build() {
            return new QuestionsRequest(this);
        }
    }
}
