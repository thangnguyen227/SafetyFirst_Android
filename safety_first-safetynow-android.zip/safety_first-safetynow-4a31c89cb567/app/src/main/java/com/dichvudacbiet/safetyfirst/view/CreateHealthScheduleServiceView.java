
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;
import com.dichvudacbiet.safetyfirst.model.network.HealthCareActivateTitleRequest;

import java.util.List;

public interface CreateHealthScheduleServiceView extends BaseView {
    void navigateBack();
    void showActivityType(HealthCareActivateModel datas);
    void showActivityTitleType(List<HealthCareActivateModel> datas);
    void resetTextField();
    void showTempList(List<HealthCareActivateModel> datas);
    void hideList();
}
