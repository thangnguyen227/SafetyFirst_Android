
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.ActivityNavigationController;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.QuestionAdapter;
import com.dichvudacbiet.safetyfirst.model.EssentialPhone;
import com.dichvudacbiet.safetyfirst.model.QuestionModel;
import com.dichvudacbiet.safetyfirst.presenter.QuestionsPresenter;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.QuestionsView;

import java.util.ArrayList;


public class QuestionsFragment extends BaseFragment<QuestionsView, QuestionsPresenter> implements
        QuestionsView, View.OnClickListener {

    private RecyclerView rvList;

    private EditText edit_emergency, edit_hospital, edit_fire, edit_police;
    private QuestionAdapter adapter;
    private ArrayList<QuestionModel> questionsList = new ArrayList<>();
    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_questions;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView tvTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        tvTitle.setVisibility(View.VISIBLE);
        tvTitle.setText("Thông tin cần thiết khác");
        Button btnRegister = (Button) view.findViewById(R.id.register_btnRegister);
        btnRegister.setOnClickListener(this);
        adapter = new QuestionAdapter(getActivity());
        rvList = (RecyclerView) view.findViewById(R.id.rvListQuestions);
        edit_emergency = (EditText) view.findViewById(R.id.edit_emergency);
        edit_hospital = (EditText) view.findViewById(R.id.edit_hospital);
        edit_fire = (EditText) view.findViewById(R.id.edit_fire);
        edit_police = (EditText) view.findViewById(R.id.edit_police);
    }

    @Override
    public void onDestroyView() {
        Util.hideKeyboard(getActivity());
        super.onDestroyView();
    }

    @NonNull
    @Override
    public QuestionsPresenter createPresenter() {
        return new QuestionsPresenter();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.register_btnRegister:
                String emergency = edit_emergency.getText().toString();
                String hospital = edit_hospital.getText().toString();
                String fire = edit_fire.getText().toString();
                String police = edit_police.getText().toString();
//                getPresenter().postQuestionOthers(edFoods);
                getPresenter().setOtherInformation(new EssentialPhone(emergency,"0","0","0"));
                backToHome();
                break;
        }
    }

    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void showListQuestions(ArrayList<QuestionModel> questionModels) {
        questionsList =  questionModels;
        adapter.setListNews(questionModels);
        adapter.notifyDataSetChanged();
        rvList.setAdapter(adapter);
    }

    @Override
    public void showMessage(int message, boolean success) {
        super.showMessage(message, success);
        Toast.makeText(getActivity(), getResources().getString(message), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void backToHome() {
        // Finish & go home
//        ((BaseActivity) getActivity()).pushFragment(new HomeFragment(), true);
        ActivityNavigationController.showHomeActivity(getActivity());
    }

}

