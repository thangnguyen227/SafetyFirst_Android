
package com.dichvudacbiet.safetyfirst.presenter;

import android.util.Log;

import com.dichvudacbiet.safetyfirst.model.CountryEmergencyNumber;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.PhoneBookModel;
import com.dichvudacbiet.safetyfirst.model.network.CountryEmerNumByCountryRequest;
import com.dichvudacbiet.safetyfirst.model.network.CountryEmerNumRequest;
import com.dichvudacbiet.safetyfirst.model.network.CountryFullRequest;
import com.dichvudacbiet.safetyfirst.model.network.LocationRequest;
import com.dichvudacbiet.safetyfirst.model.network.PhoneBookRequest;
import com.dichvudacbiet.safetyfirst.model.network.RespondData;
import com.dichvudacbiet.safetyfirst.model.network.UnreadNotificationCountRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.HomeView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HomePresenter extends BasePresenter<HomeView> {

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            onGetCurrentCountry();
            loadContent();
            onGetUnreadNotifiCount();

        }
    }

    private void loadContent() {
        /*if (isViewAttached()) {
            addSubscription(Observable.just(PrefUtil.getUserInfo() != null)
                    .flatMap(loggedIn -> {
                        if (loggedIn) {
                            return NetworkService.getListNotificationsHome(1)
                                    .flatMap(zacsNotifications -> {
                                        if (zacsNotifications != null
                                                && zacsNotifications.size() > 0) {
                                            return Observable.just(zacsNotifications);
                                        }
                                        return NetworkService.getListHomeNews();
                                    });
                        }
                        return NetworkService.getListHomeNews();
                    }).subscribe(new SubscriberImpl<List<?>>() {
                        @Override
                        public void onNext(List<?> objects) {
                            if (objects != null && objects.size() > 0) {
                                if (objects.get(0) instanceof ZacsNotification) {
                                    getView().showListNotifications(
                                            (List<ZacsNotification>) objects);
                                } else if (objects.get(0) instanceof News) {
                                    getView().showListNews((List<News>) objects);
                                }
                            }
                        }

                        @Override
                        public void onError(Throwable e) {
                            super.onError(e);
                            getView().showMessage(R.string.load_data_fail, false);
                        }
                    }));
        }*/
    }


    public void onHotLineClicked(String phone) {
        if (isViewAttached()) {
            getView().callHotLine(phone);
        }
    }

    public void onSupportClicked() {
        if (isViewAttached()) {
            getView().callSupport();
        }
    }

    public void onServiceClicked() {
        if (isViewAttached()) {
            getView().callService();
        }
    }

    public void onNotifiClicked() {
        if (isViewAttached()) {
            getView().callNotify();
        }
    }

    public void onProfileClicked() {
        if (isViewAttached()) {
            getView().callProfile();
        }
    }

    public void onRescueClicked() {
        if (isViewAttached()) {
            getView().showRescueSkill();
        }
    }

    public void onInfoClicked() {
        if (isViewAttached()) {
            getView().showInfo();
        }
    }


    public void onCallEngClicked(double lat, double lng, String info, int type, String phone) {
        if (isViewAttached()) {
            if (isViewAttached()) {
                if (isViewAttached()) {
                    Object mData = LocationRequest.newBuilder()
                            .lat(lat).lng(lng).info(info).type(type).notify_to(phone);
                    Call<RespondData> call = ApiService.getClient().postCall(PrefUtil.getTokenInfo(), mData);
                    call.enqueue(new Callback<RespondData>() {
                        @Override
                        public void onResponse(Call<RespondData> call, Response<RespondData> response) {

                            if (response.isSuccessful()) {
                                if (response.body().status == 1) {
                                    getView().showMessage("Gửi thông tin thành công", false);
                                }

                            } else {
                                getView().showMessage("Lỗi tạo kết nối", false);
                            }
                        }

                        @Override
                        public void onFailure(Call<RespondData> call, Throwable t) {
                            getView().showMessage("Lỗi tạo kết nối", false);
                        }
                    });
                }
            }
        }
    }



    public void onGetCurrentCountry() {
        if (isViewAttached()) {
            if (isViewAttached()) {


                    Call<String> call = ApiService.getClientTwo().getCurrentCountry();
                    call.enqueue(new Callback<String>() {
                        @Override
                        public void onResponse(Call<String> call, Response<String> response) {

                            if (response.isSuccessful()) {
                                try {
                                    JSONObject ob = new JSONObject(response.body());
                                    Session.COUNTRY_CODE = ob.getString("countryCode");
                                    onGetPhoneBook();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }




                            } else {
                                getView().showMessage("Lỗi tạo kết nối", false);
                            }
                        }

                        @Override
                        public void onFailure(Call<String> call, Throwable t) {
                            Log.d("/////",t.getMessage());
                            getView().showMessage("Lỗi tạo kết nối ", false);
                        }
                    });
                }
            }

    }


    public void onGetCountryCode() {
        if (isViewAttached()) {
            if (isViewAttached()) {
                if (isViewAttached()) {

                    Call<CountryEmerNumRequest> call = ApiService.getClient().getCountriesEmergencyNumbers();
                    call.enqueue(new Callback<CountryEmerNumRequest>() {
                        @Override
                        public void onResponse(Call<CountryEmerNumRequest> call, Response<CountryEmerNumRequest> response) {

                            if (response.isSuccessful()) {
                                List<CountryEmergencyNumber> countries = response.body().data;
                                getView().getCountry(countries);

                            } else {
                                getView().showMessage("Lỗi tạo kết nối", false);
                            }
                        }

                        @Override
                        public void onFailure(Call<CountryEmerNumRequest> call, Throwable t) {
                            getView().showMessage("Lỗi tạo kết nối", false);
                        }
                    });
                }
            }
        }
    }

    public void onCallEngClicked() {
        if (isViewAttached()) {
            if (isViewAttached()) {
                Call<CountryEmerNumRequest> call = ApiService.getClient().getCountriesEmergencyNumbers();
                call.enqueue(new Callback<CountryEmerNumRequest>() {
                    @Override
                    public void onResponse(Call<CountryEmerNumRequest> call, Response<CountryEmerNumRequest> response) {

                        if (response.isSuccessful()) {
                            List<CountryEmergencyNumber> countries = response.body().data;
                            getView().getCountry(countries);

                        } else {
                            getView().showMessage("Lỗi tạo kết nối", false);
                        }
                    }

                    @Override
                    public void onFailure(Call<CountryEmerNumRequest> call, Throwable t) {
                        getView().showMessage("Lỗi tạo kết nối", false);
                    }
                });
            }
        }
    }

    public void onGetUnreadNotifiCount() {
        if (isViewAttached()) {
            Call<UnreadNotificationCountRequest> call = ApiService.getClient().getUserUnreadNotificationCount(PrefUtil.getTokenInfo());
            call.enqueue(new Callback<UnreadNotificationCountRequest>() {
                @Override
                public void onResponse(Call<UnreadNotificationCountRequest> call, Response<UnreadNotificationCountRequest> response) {
                    try {
                        if (response.isSuccessful()) {
                            int total = response.body().data.number;
                            getView().showUnreadNotifiCount(total);
                        } else {
                            getView().showMessage("Lỗi tạo kết nối", false);
                        }
                    } catch (Exception ex) {

                    }

                }

                @Override
                public void onFailure(Call<UnreadNotificationCountRequest> call, Throwable t) {
                    try {
                        getView().showMessage("Lỗi tạo kết nối", false);
                        Log.d("/////", t.getMessage());
                    } catch (Exception ex) {

                    }

                }
            });
        }

    }

    public void onGetPhoneBook() {
        if (isViewAttached()) {

                Call<PhoneBookRequest> call = ApiService.getClient().getPhoneBook(PrefUtil.getTokenInfo(), Session.COUNTRY_CODE);
                call.enqueue(new Callback<PhoneBookRequest>() {
                    @Override
                    public void onResponse(Call<PhoneBookRequest> call, Response<PhoneBookRequest> response) {
                        try {
                            if (response.isSuccessful()) {
                                List<PhoneBookModel> countries = response.body().data;
                                getView().getPhoneCountry(countries);
                            } else {
                                getView().showMessage("Lỗi tạo kết nối", false);
                            }
                        } catch (Exception ex) {

                        }
                    }

                    @Override
                    public void onFailure(Call<PhoneBookRequest> call, Throwable t) {
                        try {
                        getView().showMessage("Lỗi tạo kết nối", false);
                        } catch (Exception ex) {

                        }
                    }
                });


        }
    }

}
