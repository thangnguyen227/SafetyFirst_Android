
package com.dichvudacbiet.safetyfirst.presenter;


import com.dichvudacbiet.safetyfirst.view.ProfileUserView;

import org.greenrobot.eventbus.EventBus;


public class ProfileUserPresenter extends BasePresenter<ProfileUserView> {

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()){
        }
    }

    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }

    @Override
    public void detachView(boolean retainInstance) {
        EventBus.getDefault().unregister(this);
        super.detachView(retainInstance);
    }

}
