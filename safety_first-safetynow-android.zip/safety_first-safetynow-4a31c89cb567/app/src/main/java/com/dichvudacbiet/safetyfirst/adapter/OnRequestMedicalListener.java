package com.dichvudacbiet.safetyfirst.adapter;

import android.support.v7.widget.RecyclerView;

public interface OnRequestMedicalListener<T> {

    void onDirectionItemClicked(RecyclerView recyclerView, T t, int position);
    void onCallItemClicked(RecyclerView recyclerView, T t, int position);
}