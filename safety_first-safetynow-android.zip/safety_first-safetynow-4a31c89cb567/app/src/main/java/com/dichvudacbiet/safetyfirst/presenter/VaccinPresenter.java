
package com.dichvudacbiet.safetyfirst.presenter;

import android.util.Log;

import com.dichvudacbiet.safetyfirst.model.VaccinModel;
import com.dichvudacbiet.safetyfirst.model.network.VaccinRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.VaccinView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class VaccinPresenter extends BasePresenter<VaccinView> {

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            Call<VaccinRequest> call2 = ApiService.getClient().getUserVaccinationInfo(PrefUtil.getTokenInfo(), Util.getLangCode());
            call2.enqueue(new Callback<VaccinRequest>() {
                @Override
                public void onResponse(Call<VaccinRequest> call2, Response<VaccinRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<VaccinModel> respondData =  response.body().data;
                            getView().setData(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu huhu", false);
                    }

                }
                @Override
                public void onFailure(Call<VaccinRequest> call2, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu huhu ", false);
                    Log.d("//////",t.getMessage());
                }
            });
        }
    }

    public void onNewsClicked(VaccinModel news, int position) {
        if (isViewAttached()) {

        }
    }
    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
