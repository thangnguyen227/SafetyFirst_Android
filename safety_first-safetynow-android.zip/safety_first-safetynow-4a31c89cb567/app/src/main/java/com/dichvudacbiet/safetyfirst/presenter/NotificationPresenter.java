
package com.dichvudacbiet.safetyfirst.presenter;


import android.util.Log;

import com.dichvudacbiet.safetyfirst.model.NotificationModel;
import com.dichvudacbiet.safetyfirst.model.ServiceModel;
import com.dichvudacbiet.safetyfirst.model.network.NotificationRequest;
import com.dichvudacbiet.safetyfirst.model.network.NotificationRequest2;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.view.NotificationView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class NotificationPresenter extends BasePresenter<NotificationView> {

    private List<ServiceModel> serviceModelList = new ArrayList<>();
    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            Call<NotificationRequest> call = ApiService.getClient().getUserNotifications(PrefUtil.getTokenInfo());
            call.enqueue(new Callback<NotificationRequest>() {
                @Override
                public void onResponse(Call<NotificationRequest> call, Response<NotificationRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            getView().setData(response.body().data);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage( response.code()+ " "+ response.message(), false);
                    }

                }
                @Override
                public void onFailure(Call<NotificationRequest> call, Throwable t) {
                    getView().showMessage( t.getMessage(), false);
                    Log.d("///////", t.getMessage());
                }
            });
        }
    }

    public void onNewsClicked(NotificationModel news, int position) {

        if (isViewAttached()) {
            Call<NotificationRequest2> call = ApiService.getClient().markNotificationAsRead(news.id,PrefUtil.getTokenInfo());
            call.enqueue(new Callback<NotificationRequest2>() {
                @Override
                public void onResponse(Call<NotificationRequest2> call, Response<NotificationRequest2> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            getView().showDetail(news);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage( response.code()+ " "+ response.message(), false);
                    }

                }
                @Override
                public void onFailure(Call<NotificationRequest2> call, Throwable t) {
                    getView().showMessage( t.getMessage(), false);
                    Log.d("///////", t.getMessage());
                }
            });

        }
    }
    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
