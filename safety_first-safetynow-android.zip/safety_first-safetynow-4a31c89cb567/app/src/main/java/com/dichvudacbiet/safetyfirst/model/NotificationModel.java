package com.dichvudacbiet.safetyfirst.model;

import java.io.Serializable;

/**
 * Created by loi.doan on 12/12/17.
 */

public class NotificationModel implements Serializable {

    public int id;
    public String title;
    public String content;
    public String type;
    public int is_read;

    public Reference reference;

    public class Reference implements Serializable{
        public String created_at;
        public String updated_at;
        public String number;
        public int type;
        public int is_read;
        public UserLocation user_location;
    }

    public class UserLocation implements Serializable{
        public int id;
        public double lat;
        public double lng;
        public int type;
    }
}
