package com.dichvudacbiet.safetyfirst.model.network;

public class SupportRequest {

    public String country_id;

    private SupportRequest(Builder builder) {
        country_id = builder.country_id;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private String country_id;

        private Builder() {
        }

        public Builder country_id(String val) {
            country_id = val;
            return this;
        }


        public SupportRequest build() {
            return new SupportRequest(this);
        }
    }
}
