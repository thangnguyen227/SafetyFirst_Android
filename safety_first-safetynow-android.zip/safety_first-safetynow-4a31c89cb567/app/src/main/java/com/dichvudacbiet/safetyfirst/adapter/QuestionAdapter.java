
package com.dichvudacbiet.safetyfirst.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.QuestionModel;

import java.util.ArrayList;
import java.util.List;


public class QuestionAdapter extends  RecyclerView.Adapter<QuestionAdapter.MyViewHolder>
        implements View.OnClickListener {

    private List<QuestionModel> moviesList;
    private RecyclerView rvList;
    protected RecyclerViewOnItemClickedListener<QuestionModel> listener;
    private Context mContext;


    public QuestionAdapter(Context context ){
        mContext = context;
    }
    public void setListNews(List<QuestionModel> listNews) {
        this.moviesList = listNews;
    }

    public List<QuestionModel> getListNews() {
        return moviesList;
    }

    public void setOnItemClickListener(RecyclerViewOnItemClickedListener<QuestionModel> listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        View containingView = rvList.findContainingItemView(v);
        int position = rvList.getChildAdapterPosition(containingView);
        if (position == RecyclerView.NO_POSITION) {
            return;
        }

        if (listener != null) {
            listener.onItemClicked(rvList, moviesList.get(position), position);
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView mQuestionTitle;
        public Spinner mSpContact;
        private EditText mEditAnwer;

        public MyViewHolder(View view) {
            super(view);
            mQuestionTitle = (TextView) view.findViewById(R.id.question1);
            mSpContact = (Spinner) view.findViewById(R.id.sp_contact);
            mEditAnwer = (EditText) view.findViewById(R.id.edit_phone);
        }
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_questions, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        QuestionModel questionModel = moviesList.get(position);
        holder.mQuestionTitle.setText(position + 1 +". " +questionModel.text);
        if(questionModel.type.equals("multiple_options")){
            ArrayList<String> mList = new ArrayList<String>();
            for (int i = 0 ; i < questionModel.options.size(); i++){
                mList.add(questionModel.options.get(i).text);
            }
            ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                    mContext, android.R.layout.simple_spinner_item, mList);
            spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
            holder.mSpContact.setAdapter(spinnerArrayAdapter);
            holder.mSpContact.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    //mIdRelation = relation2Models.get(position).id;
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
            holder.mEditAnwer.setVisibility(View.GONE);
            holder.mSpContact.setVisibility(View.VISIBLE);
        }else {
            holder.mEditAnwer.setVisibility(View.VISIBLE);
            holder.mSpContact.setVisibility(View.GONE);
        }

    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        rvList = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        rvList = null;
        super.onDetachedFromRecyclerView(recyclerView);
    }
    //Adapter


}

