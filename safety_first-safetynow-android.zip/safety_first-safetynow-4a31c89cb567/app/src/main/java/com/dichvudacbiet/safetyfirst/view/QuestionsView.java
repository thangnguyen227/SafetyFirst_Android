
package com.dichvudacbiet.safetyfirst.view;

import com.dichvudacbiet.safetyfirst.model.QuestionModel;

import java.util.ArrayList;

/**
 * Created by ducth on 11/18/16.
 */

public interface QuestionsView extends BaseView {
    void navigateBack();
    void showListQuestions(ArrayList<QuestionModel> questionModels);
    void backToHome();
}
