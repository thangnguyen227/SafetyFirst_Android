
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.adapter.SchedueListAdapter;
import com.dichvudacbiet.safetyfirst.model.ScheduleModel;
import com.dichvudacbiet.safetyfirst.presenter.TripPresenter;
import com.dichvudacbiet.safetyfirst.view.TripView;

import java.util.ArrayList;
import java.util.List;


public class TripListFragment extends BaseFragment<TripView, TripPresenter>
        implements TripView, View.OnClickListener , RecyclerViewOnItemClickedListener<ScheduleModel> {

    private RecyclerView rvList;

    private SchedueListAdapter trip_adapter;

    private TextView mToolbarTitle;

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_list_schedule_general;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);

        ImageButton btnSos = (ImageButton) view.findViewById(R.id.top_bar_btnRight);
        btnSos.setImageResource(R.drawable.ic_add_black_24dp);
        btnSos.setOnClickListener(this);

        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.trip_page));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //

        trip_adapter = new SchedueListAdapter(getActivity(),new ArrayList<>());
        trip_adapter.setOnItemClickListener(this);
        rvList = (RecyclerView) view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rvList.setAdapter(trip_adapter);
    }

    @NonNull
    @Override
    public TripPresenter createPresenter() {
        return new TripPresenter();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
            case R.id.top_bar_btnRight:
                ((BaseActivity) getActivity()).pushFragment(new CreateTripSerivceFragment(), true);
                break;
        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }



    @Override
    public void setData(List<ScheduleModel> listNews) {
        trip_adapter.setListNews(listNews);
        trip_adapter.notifyDataSetChanged();
    }

    @Override
    public void showCreateSchedule(ScheduleModel scheduleModel) {
        ((BaseActivity) getActivity()).pushFragment(new CreateTripSerivceFragment(scheduleModel), true);
    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, ScheduleModel scheduleModel, int position) {
        getPresenter().onNewsClicked(scheduleModel, position);
    }


}
