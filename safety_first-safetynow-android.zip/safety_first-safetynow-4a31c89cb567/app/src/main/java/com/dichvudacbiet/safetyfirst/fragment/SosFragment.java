
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.adapter.SOSAdapter;
import com.dichvudacbiet.safetyfirst.model.SosModel;
import com.dichvudacbiet.safetyfirst.presenter.SosPresenter;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.view.SosView;

import java.util.List;


public class SosFragment extends BaseFragment<SosView, SosPresenter>
        implements SosView, View.OnClickListener , RecyclerViewOnItemClickedListener<SosModel> {

    private RecyclerView rvList;
    private SOSAdapter adapter;

    private TextView mToolbarTitle;
    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_sos;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);

        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.sos_page));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //

        adapter = new SOSAdapter();
        adapter.setOnItemClickListener(this);
        rvList = (RecyclerView) view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rvList.setAdapter(adapter);
    }

    @NonNull
    @Override
    public SosPresenter createPresenter() {
        return new SosPresenter();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }


    @Override
    public void setData(List<SosModel> listNews) {
        adapter.setListNews(listNews);
        adapter.notifyDataSetChanged();
    }



    @Override
    public void onItemClicked(RecyclerView recyclerView, SosModel sosModel, int position) {
        getPresenter().onNewsClicked(Session.location.getLatitude(),+ Session.location.getLongitude(),sosModel);
    }

}
