
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.CountryModel;
import com.dichvudacbiet.safetyfirst.model.CoveringModel;
import com.dichvudacbiet.safetyfirst.model.FoodsModel;
import com.dichvudacbiet.safetyfirst.model.LocationModel;

import java.util.ArrayList;

public interface CreateServiceView extends BaseView {
    void navigateBack();
    void showCountryList(ArrayList<LocationModel> countryModel);
    void showCityList(ArrayList<LocationModel> countryModel);
    void showCoveringList(ArrayList<LocationModel> countryModel);
    void showFoodDetail(ArrayList<FoodsModel> foodsModels);
}
