package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by khant on 19/03/2018.
 */

public class VaccinListScheduleModel {
    int id;
    public int kid_vaccination_info_id;
    public int vaccination_schedule_id;
    public String date_time;
    public String info;
    public String created_at;
    public String updated_at;
    public String vaccination_schedule_name;
    public VaccinListScheduleModel() {
    }

    public VaccinListScheduleModel(int kid_vaccination_info_id, String date_time) {
        this.kid_vaccination_info_id = kid_vaccination_info_id;
        this.date_time = date_time;
    }
}
