package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.CountryModel;
import com.dichvudacbiet.safetyfirst.model.LocationModel;

import java.util.ArrayList;

public class CountriesRequest {

    public int status;
    public ArrayList<LocationModel> data;
}