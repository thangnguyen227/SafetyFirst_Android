
package com.dichvudacbiet.safetyfirst.activity;

import android.app.Activity;
import android.content.Intent;

import com.dichvudacbiet.safetyfirst.R;


public class ActivityNavigationController {

    public static void showHomeActivity(Activity activity) {
        activity.startActivity(new Intent(activity, MainActivity.class));
        activity.overridePendingTransition(R.anim.slide_in_bottom, R.anim.stand_still);
        activity.finish();
    }

    public static void showLoginActivity(Activity activity) {
        activity.startActivity(new Intent(activity, LoginActivity.class));
        activity.overridePendingTransition(R.anim.slide_in_bottom, R.anim.stand_still);
        activity.finish();
    }
}
