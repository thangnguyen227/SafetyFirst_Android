package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.CountryEmergencyNumber;

import java.util.ArrayList;

public class CountryEmerNumRequest {

    public int success;
    public ArrayList<CountryEmergencyNumber> data;
}