
package com.dichvudacbiet.safetyfirst.presenter;

import android.util.Log;

import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;
import com.dichvudacbiet.safetyfirst.model.network.HealthCareActivateRequest;
import com.dichvudacbiet.safetyfirst.model.network.HealthCareActivateTitleRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.CreateHealthScheduleServiceView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CreateHealthScheduleServicePresenter extends BasePresenter<CreateHealthScheduleServiceView> {

    public ArrayList<HealthCareActivateModel> activities = new ArrayList<>();
    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            if(activities.size()<1){
                getView().hideList();
            }
            createServiceTile();
        }
    }


    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }


    public void createServiceTile() {
        Call<HealthCareActivateTitleRequest> call = ApiService.getClient().getHealthCareActivity(PrefUtil.getTokenInfo() , Util.getLangCode());
        call.enqueue(new Callback<HealthCareActivateTitleRequest>() {
            @Override
            public void onResponse(Call<HealthCareActivateTitleRequest> call, Response<HealthCareActivateTitleRequest> response) {

                if (response.isSuccessful()) {
                    //RC4
                    try {
                        getView().showActivityTitleType(response.body().data);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }else{
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }

            }
            @Override
            public void onFailure(Call<HealthCareActivateTitleRequest> call, Throwable t) {
                getView().showMessage("Lỗi kết nối dữ liệu", false);
            }
        });



//        ArrayList<String> healthTypes = new ArrayList<>();
//        healthTypes.add("Khám sức khỏe tổng quát(một năm ít nhất 1 lần)");
//        healthTypes.add("Tẩy giun(một năm ít nhất 2 lần)");
//        healthTypes.add("Xét nghiệm HIV");

    }

//    public void onClearSchedule(){
//        mData.activities.clear();
//        getView().showMessage("Đã xóa tất cả",true);
//    }

    public HealthCareActivateModel onCreateNewActivity(int id,String plain_text, String date, String info){
//        getView().showTempList(mData.activities);
//        getView().resetTextField();
//        getView().showMessage("Thành công, bấm nút tạo lịch trình nếu bạn đã tạo đủ lịch trình",true);
        return new HealthCareActivateModel(id,plain_text,date,info);
    }


    public void onCreateHeathCareActivity(HealthCareActivateModel data){
        Call<HealthCareActivateRequest> call = ApiService.getClient().postHealthCareActivities(PrefUtil.getTokenInfo() , data);
        call.enqueue(new Callback<HealthCareActivateRequest>() {
            @Override
            public void onResponse(Call<HealthCareActivateRequest> call, Response<HealthCareActivateRequest> response) {

                if (response.isSuccessful()) {
                    //RC4
                    try {
                        getView().showMessage("Tạo dữ liệu thành công", true);
                        getView().navigateBack();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }else{
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }

            }
            @Override
            public void onFailure(Call<HealthCareActivateRequest> call, Throwable t) {
                Log.d("/////",t.getMessage());
                getView().showMessage("Lỗi kết nối dữ liệu", false);
            }
        });
    }
}
