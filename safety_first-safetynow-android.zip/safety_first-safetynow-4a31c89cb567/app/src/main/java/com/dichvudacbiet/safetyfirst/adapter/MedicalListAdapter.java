
package com.dichvudacbiet.safetyfirst.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.MedicalModel;

import java.util.ArrayList;
import java.util.List;


public class MedicalListAdapter extends  RecyclerView.Adapter<MedicalListAdapter.MyViewHolder>
        implements View.OnClickListener {

    private List<MedicalModel> moviesList;
    private RecyclerView rvList;
    protected RecyclerViewOnItemClickedListener<MedicalModel> listener;
    public MedicalListAdapter() {
        this.moviesList = new ArrayList<>();
    }

    public void setListNews(List<MedicalModel> listNews) {
        this.moviesList.clear();
        this.moviesList.addAll(listNews);
    }

    public List<MedicalModel> getListNews() {
        return moviesList;
    }

    public void setOnItemClickListener(RecyclerViewOnItemClickedListener<MedicalModel> listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        View containingView = rvList.findContainingItemView(v);
        int position = rvList.getChildAdapterPosition(containingView);
        if (position == RecyclerView.NO_POSITION) {
            return;
        }

        if (listener != null) {
            listener.onItemClicked(rvList, moviesList.get(position), position);
        }


    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title , phone , address;

        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.item_support_tvTitle);
            phone = (TextView) view.findViewById(R.id.item_phone);
            address = (TextView) view.findViewById(R.id.item_address);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_medical, parent, false);
        itemView.setOnClickListener(this);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        MedicalModel movie = moviesList.get(position);
        holder.title.setText(movie.name);
        holder.phone.setText(movie.contact_number);
        holder.address.setText(movie.address);
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        rvList = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        rvList = null;
        super.onDetachedFromRecyclerView(recyclerView);
    }

}
