
package com.dichvudacbiet.safetyfirst.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.dichvudacbiet.safetyfirst.fragment.ProfileEditFragment;
import com.dichvudacbiet.safetyfirst.fragment.ProfileInfoFragment;




public class ProfilePagerAdapter extends FragmentStatePagerAdapter {

    public ProfilePagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        ProfileInfoFragment.PromotionTabType tabType = ProfileInfoFragment.PromotionTabType
                .values()[position];
        return ProfileEditFragment.newInstance(tabType);
    }

    @Override
    public int getCount() {
        return ProfileInfoFragment.PromotionTabType.values().length;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return ProfileInfoFragment.PromotionTabType.values()[position].getTitle();
    }
}
