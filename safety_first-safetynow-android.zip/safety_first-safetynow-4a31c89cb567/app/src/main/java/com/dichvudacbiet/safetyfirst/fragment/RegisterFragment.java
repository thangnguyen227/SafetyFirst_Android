
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.model.CountryModel;
import com.dichvudacbiet.safetyfirst.model.CoveringModel;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.Relation2Model;
import com.dichvudacbiet.safetyfirst.model.RelationModel;
import com.dichvudacbiet.safetyfirst.model.JobModel;
import com.dichvudacbiet.safetyfirst.presenter.RegisterPresenter;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.RegisterView;

import java.util.ArrayList;


public class RegisterFragment extends BaseFragment<RegisterView, RegisterPresenter> implements
        RegisterView, View.OnClickListener {

    private TextInputLayout inputLayoutName;
    private TextInputLayout inputLayoutMobilePhone;
    private TextInputLayout inputLayoutPhone;
    private TextInputLayout inputLayoutJob;
    // relation
    private TextInputLayout inputLayoutNameRelation;
    private TextInputLayout inputLayoutMobilePhoneRelation;
    private TextInputLayout inputLayoutPhoneRelation;
    private Spinner mCountry , mCity , mSpinerAddress, mSpinnerJob;

    //
    private LinearLayout mAreaRegister , mAreaRelation;
    private String mName , mAddress , mPhone , mMobile , mJob;
    private int mAddNumer = 0;
    private ArrayList<RelationModel> relationModels;
    private ArrayList<Integer> job_id_list;
    //
    private Spinner mSpRelation;
    private int mIdRelation = 1;
    private String relation_type;
    private int mIdAddress;
    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_register;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView tvTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        tvTitle.setVisibility(View.VISIBLE);
        tvTitle.setText(R.string.register_title);

        Button btnRegister = (Button) view.findViewById(R.id.register_btnRegister);
        btnRegister.setOnClickListener(this);

        Button btnCountenue = (Button) view.findViewById(R.id.register_btnContenue);
        btnCountenue.setOnClickListener(this);

        Button mAddNew = (Button) view.findViewById(R.id.add_info);
        mAddNew.setOnClickListener(this);


        inputLayoutName = (TextInputLayout) view.findViewById(R.id.register_inputLayoutName);
        inputLayoutPhone = (TextInputLayout) view.findViewById(R.id.register_inputLayoutPhone);
        inputLayoutMobilePhone = (TextInputLayout) view.findViewById(R.id.register_inputLayoutPhonemobile);
        inputLayoutJob = (TextInputLayout) view.findViewById(R.id.register_inputLayoutjob);
        mCountry = (Spinner) view.findViewById(R.id.sp_country);
        mSpinnerJob = (Spinner) view.findViewById(R.id.sp_job);
        mCity = (Spinner) view.findViewById(R.id.sp_city);
        mSpinerAddress = (Spinner) view.findViewById(R.id.sp_address);

        //
        inputLayoutNameRelation = (TextInputLayout) view.findViewById(R.id.relation_inputLayoutName);
        inputLayoutMobilePhoneRelation = (TextInputLayout) view.findViewById(R.id.relation_inputLayoutPhonemobile);
        inputLayoutPhoneRelation = (TextInputLayout) view.findViewById(R.id.relation_inputLayoutPhone);
        // inputLayoutRelation = (TextInputLayout) view.findViewById(R.id.relation_inputLayoutRelations);
        mSpRelation = (Spinner) view.findViewById(R.id.sp_contact);
        //
        mAreaRegister = (LinearLayout) view.findViewById(R.id.area_register);
        mAreaRelation = (LinearLayout) view.findViewById(R.id.area_relations);
        mAreaRegister.setVisibility(View.VISIBLE);
        mAreaRelation.setVisibility(View.GONE);
        relationModels = new ArrayList<>();
        //
    }

    @Override
    public void onDestroyView() {
        Util.hideKeyboard(getActivity());
        super.onDestroyView();
    }

    @NonNull
    @Override
    public RegisterPresenter createPresenter() {
        return new RegisterPresenter();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.register_btnContenue:
                String name = Util.safelyGetTextFromEditText(inputLayoutName.getEditText());

                String phone = Util.safelyGetTextFromEditText(inputLayoutPhone.getEditText());
                String mobile = Util.safelyGetTextFromEditText(inputLayoutMobilePhone.getEditText());
                String job = mSpinnerJob.getSelectedItem().toString();
                if(phone.equals("")){
                    getPresenter().onRegister(name, "", " ", mobile, job);
                }else {
                    getPresenter().onRegister(name, "", phone, mobile, job);
                }

                break;
            case R.id.register_btnRegister:
                int job_id = job_id_list.get(mSpinnerJob.getSelectedItemPosition());
                
//                 getPresenter().onRegisterServer(mName, mAddress, mPhone, mMobile, mJob , mIdAddress , relationModels);
                 getPresenter().onRegisterServer(mName, mAddress, mPhone, mMobile, job_id , mIdAddress , relationModels);
                break;
            case R.id.add_info:
                if(mAddNumer == 0){
                    addInfoContact();
                    Toast.makeText(getActivity() , "Đã thêm 1 thông tin liên lạc!" , Toast.LENGTH_SHORT).show();
                    mAddNumer = 1;
                    inputLayoutNameRelation.getEditText().setText("");
                    inputLayoutPhoneRelation.getEditText().setText("");
                    inputLayoutMobilePhoneRelation.getEditText().setText("");
                    mSpRelation.setSelection(0);
                    inputLayoutNameRelation.getEditText().setFocusable(true);
                }else if( mAddNumer == 1){
                    addInfoContact();
                    Toast.makeText(getActivity() , "Đã thêm 2 thông tin liên lạc!" , Toast.LENGTH_SHORT).show();
                    mAddNumer = 2;
                    inputLayoutNameRelation.getEditText().setText("");
                    inputLayoutPhoneRelation.getEditText().setText("");
                    inputLayoutMobilePhoneRelation.getEditText().setText("");
                    mSpRelation.setSelection(0);
                    inputLayoutNameRelation.getEditText().setFocusable(true);
                }else if( mAddNumer == 3){
                    addInfoContact();
                    Toast.makeText(getActivity() , "Đã thêm 3 thông tin liên lạc!" , Toast.LENGTH_SHORT).show();
                    mAddNumer = 3;
                    inputLayoutNameRelation.getEditText().setText("");
                    inputLayoutPhoneRelation.getEditText().setText("");
                    inputLayoutMobilePhoneRelation.getEditText().setText("");
                    mSpRelation.setSelection(0);
                    inputLayoutNameRelation.getEditText().setFocusable(true);
                }else if( mAddNumer == 4){
                    addInfoContact();
                    Toast.makeText(getActivity() , "Đã thêm 4 thông tin liên lạc!" , Toast.LENGTH_SHORT).show();
                    mAddNumer = 4;
                    inputLayoutNameRelation.getEditText().setText("");
                    inputLayoutPhoneRelation.getEditText().setText("");
                    inputLayoutMobilePhoneRelation.getEditText().setText("");
                    mSpRelation.setSelection(0);
                    inputLayoutNameRelation.getEditText().setFocusable(true);
                }else{
                    Toast.makeText(getActivity() , "Bạn không được thêm nữa!" , Toast.LENGTH_SHORT).show();
                }

                break;
        }
    }
    private void addInfoContact(){
        String relationName = Util.safelyGetTextFromEditText(inputLayoutNameRelation.getEditText());
        String relationPhone = Util.safelyGetTextFromEditText(inputLayoutPhoneRelation.getEditText());
        String relationMobile = Util.safelyGetTextFromEditText(inputLayoutMobilePhoneRelation.getEditText());
       // String relation = Util.safelyGetTextFromEditText(inputLayoutRelation.getEditText());
        RelationModel relationModel = new RelationModel();
        relationModel.fullname = relationName;
        relationModel.phone_number = relationPhone;
        relationModel.mobile_number = relationMobile;
        relationModel.relation_type = relation_type;
        relationModel.type_id = mIdRelation;
        relationModels.add(relationModel);
    }
    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void showRelations(String name, String address, String phone, String mobile, String job) {
        mAreaRegister.setVisibility(View.GONE);
        mAreaRelation.setVisibility(View.VISIBLE);
        mName = name;
        mAddress = address;
        mPhone = phone;
        mMobile = mobile;
        mJob = job;
    }

    @Override
    public void showRelation(ArrayList<Relation2Model> relation2Models) {
        ArrayList<String> mList = new ArrayList<String>();
        for (int i = 0 ; i < relation2Models.size(); i++){
            mList.add(relation2Models.get(i).name);
        }
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, mList);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        mSpRelation.setAdapter(spinnerArrayAdapter);
        mSpRelation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mIdRelation = relation2Models.get(position).id;
                relation_type = relation2Models.get(position).name;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void showCountryList(ArrayList<LocationModel> countryModel) {
        ArrayList<String> mList = new ArrayList<String>();
        for (int i = 0 ; i < countryModel.size(); i++){
            mList.add(countryModel.get(i).name);
        }
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, mList);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        mCountry.setAdapter(spinnerArrayAdapter);
        mCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getPresenter().loadDataCity(countryModel.get(position).id);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void showCityList(ArrayList<LocationModel> countryModel) {
        ArrayList<String> mList = new ArrayList<String>();
        for (int i = 0 ; i < countryModel.size(); i++){
            mList.add(countryModel.get(i).name);
        }
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, mList);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        mCity.setAdapter(spinnerArrayAdapter);
        mCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getPresenter().loadDataAddress(countryModel.get(position).id);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void showCoveringList(ArrayList<LocationModel> countryModel) {
        ArrayList<String> mList = new ArrayList<String>();
        for (int i = 0 ; i < countryModel.size(); i++){
            mList.add(countryModel.get(i).name);
        }
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, mList);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        mSpinerAddress.setAdapter(spinnerArrayAdapter);
        mSpinerAddress.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mIdAddress = countryModel.get(position).id;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void showJobs(ArrayList<JobModel> jobs) {
        ArrayList<String> mList = new ArrayList<String>();
        job_id_list = new ArrayList<>();
        for (int i = 0 ; i < jobs.size(); i++){
            mList.add(jobs.get(i).name);
            job_id_list.add(jobs.get(i).id);
        }
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, mList);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        mSpinnerJob.setAdapter(spinnerArrayAdapter);
        mSpinnerJob.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void showMessage(int message, boolean success) {
        super.showMessage(message, success);
        Toast.makeText(getActivity(),  getResources().getString(message), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void backToHome() {
        ((BaseActivity) getActivity()).pushFragment(new QuestionsFragment(), true);
    }
}
