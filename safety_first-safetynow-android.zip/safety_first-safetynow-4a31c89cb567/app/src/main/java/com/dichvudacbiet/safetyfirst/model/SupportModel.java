package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 12/18/17.
 */

public class SupportModel {
    public  String title;
    public int type;
    public SupportModel() {
    }

    public SupportModel(String title, int type) {
        this.type = type;
        this.title = title;
    }
    public String getTitle() {
        return title;
    }

    public void setTitle(String name) {
        this.title = name;
    }
}
