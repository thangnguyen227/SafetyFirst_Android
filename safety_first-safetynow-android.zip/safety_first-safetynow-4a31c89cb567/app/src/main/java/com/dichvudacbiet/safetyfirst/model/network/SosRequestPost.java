package com.dichvudacbiet.safetyfirst.model.network;

/**
 * Created by khant on 01/06/2018.
 */

public class SosRequestPost {
    public int sos_message_id;
    public double lat;
    public double lng;

    public SosRequestPost(int sos_message_id, double lat, double lng) {
        this.sos_message_id = sos_message_id;
        this.lat = lat;
        this.lng = lng;
    }
}
