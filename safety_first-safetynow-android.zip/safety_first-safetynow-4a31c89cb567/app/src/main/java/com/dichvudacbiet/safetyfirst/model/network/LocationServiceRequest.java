package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.MedicalModel;

import java.util.ArrayList;

public class LocationServiceRequest {

    public String success;
    public ArrayList<MedicalModel> data;
}