package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.UserInfo;

/**
 * Created by loi.doan on 12/13/17.
 */

public class DataModel {
    public String token;
    public UserInfo user;
}
