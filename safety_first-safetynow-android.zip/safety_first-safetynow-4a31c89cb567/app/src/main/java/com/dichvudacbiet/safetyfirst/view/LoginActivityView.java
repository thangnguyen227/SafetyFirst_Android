
package com.dichvudacbiet.safetyfirst.view;


public interface LoginActivityView extends BaseView {
    void loginPhone(String phone, String opt);
}
