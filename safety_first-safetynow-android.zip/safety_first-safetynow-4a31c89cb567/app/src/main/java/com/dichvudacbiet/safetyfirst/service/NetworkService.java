
package com.dichvudacbiet.safetyfirst.service;


import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import com.dichvudacbiet.safetyfirst.BuildConfig;
import com.dichvudacbiet.safetyfirst.model.RelationModel;
import com.dichvudacbiet.safetyfirst.model.network.NetworkRequest;
import com.dichvudacbiet.safetyfirst.model.network.NetworkResponse;
import com.dichvudacbiet.safetyfirst.model.network.RegisterRequest;

import java.util.ArrayList;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Url;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;


public class NetworkService {

    private static final String TAG = NetworkService.class.getSimpleName();
    private static Gson gson;
    private static SafetyApi safeApi;
    private static EncryptTransformer encryptTransformer;
    private static NetworkResponseTransformer networkResponseTransformer;
    private interface SafetyApi {

        String BASE_URL = "http://dichvudacbiet.com/api/";

        @GET
        Observable<ResponseBody> getExternalIp(@Url String url);

        @POST("device/submit")
        Observable<NetworkResponse> updateDeviceInfo(@Body NetworkRequest data);


        @POST("content/listhome")
        Observable<NetworkResponse> getListHomeNews();

        @POST("content/list")
        Observable<NetworkResponse> getListNews(@Body NetworkRequest data);

        @POST("user/topstores")
        Observable<NetworkResponse> getListStores(@Body NetworkRequest data);

        @POST("content/promotions")
        Observable<NetworkResponse> getListPromotion(@Body NetworkRequest data);

        @POST("content/promotion")
        Observable<NetworkResponse> getPromotionDetail(@Body NetworkRequest data);

        @POST("content/guarantees")
        Observable<NetworkResponse> getListQuarantees(@Body NetworkRequest data);

        @POST("content/guarantee")
        Observable<NetworkResponse> getQuaranteeDetail(@Body NetworkRequest data);

        @POST("user/guarantee")
        Observable<NetworkResponse> getQuaranteeDetail2(@Body NetworkRequest data);

        @POST("content/detail")
        Observable<NetworkResponse> getNewsDetail(@Body NetworkRequest data);

        @POST("user/notification")
        Observable<NetworkResponse> getNotiDetail(@Body NetworkRequest data);

        @POST("user/register")
        Observable<NetworkResponse> register(@Body Object data);

        @POST("user/loginphone")
        Observable<NetworkResponse> login(@Body NetworkRequest data);

        @POST("user/loginphoneverify")
        Observable<NetworkResponse> loginOPT(@Body NetworkRequest data);

        @POST("user/facebooklogin")
        Observable<NetworkResponse> loginFb(@Body NetworkRequest data);

        @POST("user/googlepluslogin")
        Observable<NetworkResponse> loginGPlus(@Body NetworkRequest data);

        @POST("user/logout")
        Observable<NetworkResponse> logout(@Body NetworkRequest data);

        @POST("user/profile")
        Observable<NetworkResponse> getProfile(@Body NetworkRequest data);

        @POST("user/update")
        Observable<NetworkResponse> updateProfile(@Body NetworkRequest data);

        @POST("user/stats")
        Observable<NetworkResponse> getUserStats(@Body NetworkRequest data);

        @Multipart
        @POST
        Observable<NetworkResponse> uploadImage(@Url String url,
                                                @Part MultipartBody.Part imageFile);

        @POST("job/categories")
        Observable<NetworkResponse> getJobCategories();

        @POST("location/provinces")
        Observable<NetworkResponse> getProvinces(@Body NetworkRequest data);

        @POST("location/districts")
        Observable<NetworkResponse> getDistricts(@Body NetworkRequest data);

        @POST("job/create")
        Observable<NetworkResponse> createJob(@Body NetworkRequest data);

        @POST("job/detail")
        Observable<NetworkResponse> getJobDetail(@Body NetworkRequest data);

        @POST("user/topbuilders")
        Observable<NetworkResponse> getBuildersAll(@Body NetworkRequest data);

        @POST("user/topbuildersrating")
        Observable<NetworkResponse> getBuildersRating(@Body NetworkRequest data);

        @POST("user/topbuilderslocation")
        Observable<NetworkResponse> getBuildersLocation(@Body NetworkRequest data);

        @POST("user/topbuildersprofessional")
        Observable<NetworkResponse> getBuildersProfessional(@Body NetworkRequest data);

        @POST("user/topbuilderspersonal")
        Observable<NetworkResponse> getBuildersPersonal(@Body NetworkRequest data);

        @POST("job/sendrequest")
        Observable<NetworkResponse> requestBuilder(@Body NetworkRequest data);

        @POST("job/sendrequests")
        Observable<NetworkResponse> requestMultipleBuilders(@Body NetworkRequest data);

        @POST("job/listrequest")
        Observable<NetworkResponse> getRequestJobs(@Body NetworkRequest data);

        @POST("job/listrequestaccepted")
        Observable<NetworkResponse> getAcceptedJobs(@Body NetworkRequest data);

        @POST("job/listjobworking")
        Observable<NetworkResponse> getWorkingJobs(@Body NetworkRequest data);

        @POST("job/listjobfinished")
        Observable<NetworkResponse> getFinishedJobs(@Body NetworkRequest data);

        @POST("job/canceljob")
        Observable<NetworkResponse> cancelJob(@Body NetworkRequest data);

        @POST("job/acceptbuilder")
        Observable<NetworkResponse> acceptBuilder(@Body NetworkRequest data);

        @POST("job/finishjob")
        Observable<NetworkResponse> finishJob(@Body NetworkRequest data);

        @POST("job/sendreviews")
        Observable<NetworkResponse> sendJobReviews(@Body NetworkRequest data);

        @POST("product/list")
        Observable<NetworkResponse> getProducts(@Body NetworkRequest data);

        @POST("product/detail")
        Observable<NetworkResponse> getProductDetail(@Body NetworkRequest data);

        @POST("user/notifications")
        Observable<NetworkResponse> getNotifications(@Body NetworkRequest data);

        @POST("user/notificationshome")
        Observable<NetworkResponse> getNotificationsHome(@Body NetworkRequest data);

        @POST("user/hitnotification")
        Observable<NetworkResponse> logNotificationViewed(@Body NetworkRequest data);

        @POST("device/sendreport")
        Observable<NetworkResponse> sendReport(@Body NetworkRequest data);

        @POST("contact/submit")
        Observable<NetworkResponse> sendContact(@Body NetworkRequest data);
    }

    public static void init() {
        gson = new Gson();
        encryptTransformer = new EncryptTransformer();
        networkResponseTransformer = new NetworkResponseTransformer();

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(BuildConfig.DEBUG
                ? new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)
                : new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.NONE));

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .baseUrl(SafetyApi.BASE_URL)
                .client(client)
                .build();

        safeApi = retrofit.create(SafetyApi.class);
    }
//    public static Observable<Integer> register(String name, String address, String phone, String mobile , String job ,  ArrayList<RelationModel> relations) {
//        return Observable.just(RegisterRequest.newBuilder()
//                .name(name).address(address).phone(phone).mobile(mobile).job(job).relations(relations)
//                .device_id("5E156418-BF10-45FA-BBEB-F40D20CDD556"))
//                .compose(encryptTransformer)
//                .flatMap(networkRequest -> safeApi.register(networkRequest))
//                .compose(networkResponseTransformer)
//                .map(networkResponse -> networkResponse.success);
//    }
    private static class EncryptTransformer implements
            Observable.Transformer<Object, Object> {

        @Override
        public Observable<Object> call(Observable<Object> objectObservable) {
            return objectObservable.map(obj -> {
                //String json = gson.toJson(obj);
                return gson.toJson(obj);
            });
        }
    }

    private static class NetworkResponseTransformer implements
            Observable.Transformer<NetworkResponse, NetworkResponse> {

        @Override
        public Observable<NetworkResponse> call(Observable<NetworkResponse> observable) {
            return observable
                    .flatMap(
                            networkResponse -> {
                                Throwable error = validateNetworkResponse(networkResponse);
                                if (error != null) {
                                    return Observable.error(error);
                                }
                                return Observable.just(networkResponse);
                            })
                    .subscribeOn(Schedulers.newThread())
                    .observeOn(AndroidSchedulers.mainThread());
        }

        private Throwable validateNetworkResponse(NetworkResponse response) {
            if (response == null) {
                return new RuntimeException("NetworkResponse null");
            }

            NetworkStatusCode code = gson.fromJson(String.valueOf(response.success),
                    NetworkStatusCode.class);
            if (code == null) {
                return new RuntimeException("NetworkStatusCode null for code = " + response.success);
            }

            switch (code) {
                case SUCCESS:
                case TEMP_SUCCESS:
                    return null;
                case FAIL_WITH_MESSAGE:
                default:
                    return new RuntimeException("Uncaught exception");
            }
        }

        private enum NetworkStatusCode {
            @SerializedName("0")
            FAIL_WITH_MESSAGE,
            @SerializedName("1")
            SUCCESS,
            @SerializedName("200")
            TEMP_SUCCESS
        }

    }

}
