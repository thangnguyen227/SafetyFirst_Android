
package com.dichvudacbiet.safetyfirst.presenter;

import android.util.Log;

import com.dichvudacbiet.safetyfirst.model.BMIModel;
import com.dichvudacbiet.safetyfirst.model.SupportModel;
import com.dichvudacbiet.safetyfirst.model.network.BMIRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.view.BMIDetailView;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class BMIDetailPresenter extends BasePresenter<BMIDetailView> {

    private List<SupportModel> supportModelList = new ArrayList<>();

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {


        }
    }

    public void onGetAdviseBMI(double weight, double height) {
        if (isViewAttached()) {
            BMIModel data = new BMIModel(weight,height);
            Call<BMIRequest> call = ApiService.getClient().getAdviseBMI(PrefUtil.getTokenInfo(),data , "vn");
            call.enqueue(new Callback<BMIRequest>() {
                @Override
                public void onResponse(Call<BMIRequest> call, Response<BMIRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            getView().setBMIScore(response.body().data);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        getView().showMessage("Lỗi tạo kết nối", false);
                    }

                }

                @Override
                public void onFailure(Call<BMIRequest> call, Throwable t) {
                    Log.d("/////",t.getMessage());
                    getView().showMessage("Lỗi tạo kết nối", false);
                }
            });
        }
    }


    public void onGetAdultBMI() {
        if (isViewAttached()) {
            Call<ResponseBody> call = ApiService.getClient().getAdultBMI(PrefUtil.getTokenInfo());
            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            String html = response.body().string();
                            getView().setBodyBMI(html);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        getView().showMessage("Lỗi tạo kết nối", false);
                    }

                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.d("/////",t.getMessage());
                    getView().showMessage("Lỗi tạo kết nối", false);
                }
            });
        }
    }

    public void onGetChildrenBMI() {
        if (isViewAttached()) {
            Call<ResponseBody> call = ApiService.getClient().getChildrenBMI(PrefUtil.getTokenInfo());
            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            String html = response.body().string();
                            getView().setBodyBMI(html);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        getView().showMessage("Lỗi tạo kết nối", false);
                    }

                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.d("/////",t.getMessage());
                    getView().showMessage("Lỗi tạo kết nối", false);
                }
            });
        }
    }

    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
