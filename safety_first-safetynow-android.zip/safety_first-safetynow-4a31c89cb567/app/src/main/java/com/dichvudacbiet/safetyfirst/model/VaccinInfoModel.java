package com.dichvudacbiet.safetyfirst.model;

import java.util.List;

/**
 * Created by khant on 24/03/2018.
 */

public class VaccinInfoModel {
    public int id;
    public String name;
//    public boolean isChoose;

    public List<Times> times;

    public class Times{
        public int id;
        public int vaccination_id;
        public String time;
        public String name;
    }

}
