
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.base.Constants;
import com.dichvudacbiet.safetyfirst.base.SafetyApplication;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.SupportModel;
import com.dichvudacbiet.safetyfirst.model.network.CountriesRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.view.ChooseSupportView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ChooseSupportPresenter extends BasePresenter<ChooseSupportView> {

    private List<SupportModel> supportModelList = new ArrayList<>();
    private boolean isReady = false;

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadCurrentLocation();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            if (supportModelList.size() <= 0) {
                SupportModel movie = new SupportModel(SafetyApplication.self().getString(R.string.info_of_hospital_medical_center), Constants.SUPPORT_MEDICAL);
                supportModelList.add(movie);
                movie = new SupportModel(SafetyApplication.self().getString(R.string.info_of_local_poly_team), Constants.SUPPORT_POLY_TEAM);
                supportModelList.add(movie);
                movie = new SupportModel(SafetyApplication.self().getString(R.string.info_of_local_rescue_team), Constants.SUPPORT_RESCUE_TEAM);
                supportModelList.add(movie);
                movie = new SupportModel(SafetyApplication.self().getString(R.string.info_of_service_travel_agent), Constants.SUPPORT_TRAVEL_AGENT);
                supportModelList.add(movie);
                movie = new SupportModel(SafetyApplication.self().getString(R.string.info_of_embassy_represent_office), Constants.SUPPORT_EMBASSY);
                supportModelList.add(movie);
                movie = new SupportModel(SafetyApplication.self().getString(R.string.info_of_restaurant_shopping_1), Constants.SUPPORT_RESTAURANT_SHOPPING);
                supportModelList.add(movie);
                movie = new SupportModel(SafetyApplication.self().getString(R.string.info_of_best_local_fools_stuffs), Constants.SUPPORT_FOOLS_STUFFS);
                supportModelList.add(movie);
                movie = new SupportModel(SafetyApplication.self().getString(R.string.info_of_local_groups_unions), Constants.SUPPORT_ASSOCIATION);
                supportModelList.add(movie);
               /* SupportModel movie7 = new SupportModel("BMI", 1);
                supportModelList.add(movie7);*/
                getView().setData(supportModelList);
            } else {
                getView().setData(supportModelList);
            }

        }
    }

    private void loadCurrentLocation() {
        getView().loadCurrentLocation();
    }

    public void onLoadLocationCallback() {
        onLoadCountries();
        loadData();
    }

    public void onLoadCountries() {
        isReady = false;
        if (isViewAttached()) {
            getView().showLoading(true);

            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_COUNTRY, null);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<LocationModel> respondData = response.body().data;
                            getView().setCountryData(respondData);
                            getView().showLoading(false);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        //Utility.showSnackBar(RegisterActivity.this, findViewById(android.R.id.content)  ,"Lỗi kết nối dữ liệu" );
                    }

                }

                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    //Utility.showSnackBar(RegisterActivity.this, findViewById(android.R.id.content)  ,"Lỗi kết nối dữ liệu" );
                }
            });
        }
    }


    public void loadDataProvince(int country_id) {
        if (isViewAttached()) {

            getView().showLoading(true);
            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_PROVINCE, country_id);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<LocationModel> respondData = response.body().data;
                            getView().setProvinceData(respondData);
                            getView().showLoading(false);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        getView().showMessage("Lỗi kết nối dữ liệu", false);
                    }

                }

                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }
            });
        }
    }

    public void loadDataAddress(final int id_city) {

        if (isViewAttached()) {
            getView().showLoading(true);
            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_DISTRICT, id_city);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        isReady = true;
                        try {
                            ArrayList<LocationModel> respondData = response.body().data;
                            getView().showCoveringList(respondData);
                            getView().showLoading(false);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        getView().showMessage("Lỗi kết nối dữ liệu", false);
                    }

                }

                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }
            });
        }

    }

    public void onNewsClicked(SupportModel news, int position) {
        if (isViewAttached() && isReady) {
//            if (position == 7)
//                getView().navigateToBMI();
//            else
            getView().showNational(news.type);
        }
    }

    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
