
package com.dichvudacbiet.safetyfirst.adapter;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.fragment.NotificationDetailFragment;
import com.dichvudacbiet.safetyfirst.model.NotificationModel;
import com.dichvudacbiet.safetyfirst.model.network.NotificationRequest2;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class NotificationAdapter extends  RecyclerView.Adapter<NotificationAdapter.MyViewHolder>
        implements View.OnClickListener {

    private List<NotificationModel> notificationList = new ArrayList<>();
    private RecyclerView rvList;
    protected RecyclerViewOnItemClickedListener<NotificationModel> listener;
    private Activity mContext;
    private Calendar myCalendar;
    private DatePickerDialog.OnDateSetListener date;

    public NotificationAdapter(Activity context ){
        mContext = context;
    }
    public void setListNews(List<NotificationModel> listNews) {
        this.notificationList = listNews;
    }

    public List<NotificationModel> getListNews() {
        return notificationList;
    }

    public void setOnItemClickListener(RecyclerViewOnItemClickedListener<NotificationModel> listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        View containingView = rvList.findContainingItemView(v);
        int position = rvList.getChildAdapterPosition(containingView);
        if (position == RecyclerView.NO_POSITION) {
            return;
        }

        if (listener != null) {
            listener.onItemClicked(rvList, notificationList.get(position), position);
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView edit_title,edit_content,edit_date;
        public LinearLayout ln_layout1;
        public MyViewHolder(View view) {
            super(view);
            edit_title = view.findViewById(R.id.edit_title);
            edit_content =  view.findViewById(R.id.edit_content);
            edit_date = view.findViewById(R.id.edit_date);
            ln_layout1 = view.findViewById(R.id.ln_layout1);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onNewsClicked(notificationList.get(getLayoutPosition()),getLayoutPosition());
            Fragment fragment = NotificationDetailFragment.newInstance(notificationList.get(getLayoutPosition()));
            ((BaseActivity) mContext).pushFragment(fragment, true);
        }
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_notification, parent, false);

        return new MyViewHolder(itemView);
    }
    TextView tvTemp;
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        NotificationModel notificationModel = notificationList.get(position);

        holder.edit_title.setText(notificationModel.title);
        holder.edit_content.setText(notificationModel.content);
        holder.edit_date.setText(notificationModel.reference.created_at);
        if(notificationModel.is_read == 1){
            holder.ln_layout1.setBackgroundColor(Color.parseColor("#ffffff"));
        }else{
            holder.ln_layout1.setBackgroundColor(Color.parseColor("#ededed"));
        }

    }



    @Override
    public int getItemCount() {
        return notificationList.size();
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        rvList = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        rvList = null;
        super.onDetachedFromRecyclerView(recyclerView);
    }

        public void onNewsClicked(NotificationModel news, int position) {


                Call<NotificationRequest2> call = ApiService.getClient().markNotificationAsRead(news.id,PrefUtil.getTokenInfo());
                call.enqueue(new Callback<NotificationRequest2>() {
                    @Override
                    public void onResponse(Call<NotificationRequest2> call, Response<NotificationRequest2> response) {

                        if (response.isSuccessful()) {
                            //RC4
//                            try {
//                                Fragment fragment = NotificationDetailFragment.newInstance(news);
//                                ((BaseActivity) mContext).pushFragment(fragment, true);
//                            } catch (Exception e) {
//                                e.printStackTrace();
//                            }

                        }else{
                            Toast.makeText(mContext, response.code()+ " "+ response.message(), Toast.LENGTH_SHORT).show();

                        }

                    }
                    @Override
                    public void onFailure(Call<NotificationRequest2> call, Throwable t) {
                        Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_SHORT).show();

                        Log.d("///////", t.getMessage());
                    }
                });

        }


}

