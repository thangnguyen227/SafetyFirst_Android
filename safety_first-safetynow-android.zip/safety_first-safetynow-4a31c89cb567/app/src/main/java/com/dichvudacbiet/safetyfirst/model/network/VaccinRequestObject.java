package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.VaccinModel;

/**
 * Created by loi.doan on 12/18/17.
 */

public class VaccinRequestObject {
    public int success;
    public VaccinModel data;
}
