
package com.dichvudacbiet.safetyfirst.view;


public interface CreateVaccinServiceView extends BaseView {
    void navigateBack();
    void navigateToCreateVaccinSchedule();
}
