package com.dichvudacbiet.safetyfirst.model;

import java.util.ArrayList;

/**
 * Created by loi.doan on 01/04/18.
 */

public class CountryEmergencyNumber {

    public  String name;
    public String iso2_code;
    public  ArrayList<EmergencyNumber> emergency_numbers;

    public class EmergencyNumber{
        public int id;
        public  String name;
        public String phone;
        public  int country_id;
        public String info;

        public String created_at;
        public String updated_at;
    }

}
