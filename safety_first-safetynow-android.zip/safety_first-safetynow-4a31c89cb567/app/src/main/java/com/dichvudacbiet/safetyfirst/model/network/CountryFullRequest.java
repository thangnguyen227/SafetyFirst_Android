package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.BMIModel;
import com.dichvudacbiet.safetyfirst.model.CountryFullModel;

/**
 * Created by loi.doan on 12/18/17.
 */

public class CountryFullRequest {
    public CountryFullModel data;
}
