package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.UserInfo;

/**
 * Created by ABCD on 10/7/2016.
 */
public class RespondData {
    public int status;
    public UserInfo data;
}
