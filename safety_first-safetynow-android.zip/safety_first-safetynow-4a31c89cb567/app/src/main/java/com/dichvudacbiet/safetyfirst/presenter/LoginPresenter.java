
package com.dichvudacbiet.safetyfirst.presenter;


import com.dichvudacbiet.safetyfirst.view.LoginView;

public class LoginPresenter extends BasePresenter<LoginView> {

    @Override
    public void onNewViewStateInstance() {

    }

    /*public void onLoginEmail(String email) {
        if (isViewAttached()) {
            int errMsg = validateInput(email);
            if (errMsg != -1) {
                getView().showMessage(errMsg, false);
                return;
            }
            getView().loginEmail(email);
        }
    }
    public void onLoginOTP(String phone,String password) {
        if (isViewAttached()) {
            int errMsg = validateInputOTP(phone,password);
            if (errMsg != -1) {
                getView().showMessage(errMsg, false);
                return;
            }

            getView().loginOTP(phone,password);
        }
    }

    private int validateInput(String email) {
        if (Util.isNullOrEmpty(email)) {
            return R.string.please_fill_all_input;
        }


        if (email.length() < 10) {
            return R.string.phone_min_6_digits;
        }

        return -1;
    }
    private int validateInputOTP(String phone,String password) {
        if ( Util.isNullOrEmpty(password) || Util.isNullOrEmpty(phone)) {
            return R.string.please_fill_all_input;
        }
        return -1;
    }
*/
    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }


}
