
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.BMIModel;
import com.dichvudacbiet.safetyfirst.model.ScheduleModel;
import com.dichvudacbiet.safetyfirst.presenter.BMIDetailPresenter;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.BMIDetailView;

import java.util.ArrayList;
import java.util.List;


public class BMIDetailFragment extends BaseFragment<BMIDetailView, BMIDetailPresenter>
        implements BMIDetailView, View.OnClickListener {


    private TextView mToolbarTitle, tv_ibm_score , tv_ibm_text;
    private Button btn_get_advise;
    private EditText ed_weight, ed_height;
    private LinearLayout ll_advise;
    private String fileName;
    private int TYPE;
    WebView webView, webView_advise;
    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_detail_bmi;
    }


    public static BMIDetailFragment newInstance(int type) {
        Bundle args = new Bundle();
        args.putInt("type", type);
        BMIDetailFragment fragment = new BMIDetailFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);

        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.bmi_support));
        mToolbarTitle.setVisibility(View.VISIBLE);

        if(getArguments()!= null){
            TYPE = getArguments().getInt("type");
        }
        //
        ll_advise = view.findViewById(R.id.ll_advise);

        //
        ed_weight = view.findViewById(R.id.ed_weight);
        ed_height = view.findViewById(R.id.ed_height);

        //
        btn_get_advise = view.findViewById(R.id.btn_get_advise);
        btn_get_advise.setOnClickListener(this);

        //
        tv_ibm_score = view.findViewById(R.id.tv_ibm_score);
        tv_ibm_text = view.findViewById(R.id.tv_ibm_text);

        //
        webView = view.findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(false);
        webView.setWebViewClient(new MyBrowser());
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        //
        webView_advise = view.findViewById(R.id.webView_advise);
        webView_advise.getSettings().setJavaScriptEnabled(false);
        webView_advise.setWebViewClient(new MyBrowser());


//        webView.loadUrl(url);


        initView();
    }

    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void setData(List<ScheduleModel> listNews) {

    }

    @Override
    public void setBMIScore(BMIModel bmiModel) {
        tv_ibm_score.setText(bmiModel.score+"");
        if(bmiModel.score < 18.5){
            tv_ibm_text.setText(getString(R.string.substandard));
        }
        if(bmiModel.score >= 18.5 && bmiModel.score < 25){
            tv_ibm_text.setText(getString(R.string.standard));
        }
        if(bmiModel.score >= 25 && bmiModel.score < 30){
            tv_ibm_text.setText(getString(R.string.overweight));
        }
        if(bmiModel.score >= 30 && bmiModel.score < 40){
            tv_ibm_text.setText(getString(R.string.fat));
        }
        if(bmiModel.score > 40){
            tv_ibm_text.setText(getString(R.string.very_fat));
        }
      //  webView_advise.loadUrl("about:blank");
        webView_advise.loadDataWithBaseURL(null,bmiModel.content_html,"text/html", "utf-8", null);
    }

    @Override
    public void setBodyBMI(String html) {
        webView.loadData(html, "text/html; charset=utf-8", "UTF-8");
    }


    private class MyBrowser extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
        @Override
        public void onLoadResource(WebView view, String url) {
            // Notice Here.
            view.clearHistory();
            super.onLoadResource(view, url);
        }
        @Override
        public void onPageFinished(WebView view, String url) {
            // And Here.
            view.clearHistory();
            super.onPageFinished(view,url);
        }

    }



    @Override
    public BMIDetailPresenter createPresenter() {
        return new BMIDetailPresenter();
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id){
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
            case R.id.btn_get_advise:
                Util.hideKeyboard(getActivity());
                int errMsg =  Util.validateInput(ed_weight.getText().toString(),ed_height.getText().toString());
                if(errMsg!=-1){
                    showMessage(errMsg, false);
                    return;
                }
                double weight = Double.parseDouble(ed_weight.getText().toString());
                double height = Double.parseDouble(ed_height.getText().toString());
                getPresenter().onGetAdviseBMI(weight,height / 100);
                break;
        }

    }


    private void initView(){
        if(TYPE==2){
            ll_advise.setVisibility(View.VISIBLE);
            webView.setVisibility(View.GONE);

        }else if(TYPE == 1){
            ll_advise.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            getPresenter().onGetChildrenBMI();
        } else{
            ll_advise.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            getPresenter().onGetAdultBMI();
        }
    }

}
