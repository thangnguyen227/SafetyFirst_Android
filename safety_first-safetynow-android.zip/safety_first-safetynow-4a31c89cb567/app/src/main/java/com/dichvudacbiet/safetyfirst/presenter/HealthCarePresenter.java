
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;
import com.dichvudacbiet.safetyfirst.model.ScheduleModel;
import com.dichvudacbiet.safetyfirst.model.network.HealthCareActivateRequest;
import com.dichvudacbiet.safetyfirst.model.network.HealthCareActivateTitleRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.HealthCareView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HealthCarePresenter extends BasePresenter<HealthCareView> {

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            Call<HealthCareActivateTitleRequest> call1 = ApiService.getClient().getHealthCareActivities(PrefUtil.getTokenInfo(), Util.getLangCode());
            call1.enqueue(new Callback<HealthCareActivateTitleRequest>() {
                @Override
                public void onResponse(Call<HealthCareActivateTitleRequest> call1, Response<HealthCareActivateTitleRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4`
                        try {
                            ArrayList<HealthCareActivateModel> respondData =  response.body().data;
                            if(respondData != null){
                                getView().setData(respondData);
                            }else{
                                getView().showMessage("Dữ liệu rỗng", false);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu", false);
                    }

                }
                @Override
                public void onFailure(Call<HealthCareActivateTitleRequest> call1, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }
            });
        }
    }

    public void onNewsClicked(ScheduleModel news, int position) {
        if (isViewAttached()) {

        }
    }
    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
