
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.VaccinModel;

import java.util.List;

public interface VaccinView extends BaseView {
    void navigateBack();
    void setData(List<VaccinModel> listNews);
}
