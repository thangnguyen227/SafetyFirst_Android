
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.NationalModel;

import java.util.List;

public interface NationalListView extends BaseView {
    void navigateBack();
    void showListData(NationalModel nationalModel);
    void setData(List<NationalModel> listNews);
}
