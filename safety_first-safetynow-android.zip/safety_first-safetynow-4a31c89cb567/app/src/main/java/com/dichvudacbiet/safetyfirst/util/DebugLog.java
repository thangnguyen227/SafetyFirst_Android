
package com.dichvudacbiet.safetyfirst.util;


public class DebugLog {


}
