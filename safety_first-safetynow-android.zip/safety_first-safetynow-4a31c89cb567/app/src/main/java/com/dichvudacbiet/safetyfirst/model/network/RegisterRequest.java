package com.dichvudacbiet.safetyfirst.model.network;

import com.google.gson.annotations.SerializedName;
import com.dichvudacbiet.safetyfirst.model.RelationModel;

import java.util.ArrayList;

public class RegisterRequest {

    public String fullname;
    public String address;
    public String phone_number;
    public String mobile_number;
    public String language_code;
    public int job_id;
    public int living_location_id;
    @SerializedName("device_id")
    public String device_id;
    public String fcm_token;
    public ArrayList<RelationModel> relations;
   /* public ArrayList<Answer> answers;
    public class Answer{
        public int question_id = 1;
        public String text =  "Bánh ướt lòng gà";
        public Answer(){
            question_id = 1;
            text =  "Bánh ướt lòng gà";
        }
    }*/
    public RegisterRequest(){

    }
    private RegisterRequest(Builder builder) {
        fullname = builder.fullname;
        address = builder.address;
        phone_number = builder.phone_number;
        mobile_number = builder.mobile_number;
        job_id = builder.job_id;
        device_id = builder.device_id;
        relations = builder.relations;
        living_location_id = builder.living_location_id;
        fcm_token = builder.fcm_token;
      //  answers = builder.answers;
        language_code = builder.language_code;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private String fullname;
        private String address;
        private String phone_number;
        private String mobile_number;
        private String language_code;
        private int job_id;
        private String device_id;
        private ArrayList<RelationModel> relations;
        private int living_location_id;
        public String fcm_token;
        //public ArrayList<Answer> answers;



        private Builder() {
        }

        public Builder fcm_token(String val) {
            fcm_token = val;
            return this;
        }

        public Builder name(String val) {
            fullname = val;
            return this;
        }

        public Builder address(String val) {
            address = val;
            return this;
        }

        public Builder phone(String val) {
            phone_number = val;
            return this;
        }

        public Builder mobile(String val) {
            mobile_number = val;
            return this;
        }

        public Builder job(int val) {
            job_id = val;
            return this;
        }

        public Builder device_id(String val) {
            device_id = val;
            return this;
        }

        public Builder language_code(String val) {
            language_code = val;
            return this;
        }

        public Builder living_location_id(int val) {
            living_location_id = val;
            return this;
        }

        public Builder relations(ArrayList<RelationModel> val) {
            relations = val;
            return this;
        }

       /* public Builder answer( ArrayList<Answer>  answer) {
            answers = answer;
            return this;
        }*/

        public RegisterRequest build() {
            return new RegisterRequest(this);
        }
    }
}
