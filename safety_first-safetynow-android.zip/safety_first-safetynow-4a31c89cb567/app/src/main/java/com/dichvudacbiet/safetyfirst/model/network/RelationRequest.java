package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.Relation2Model;

import java.util.ArrayList;

public class RelationRequest {

    //public String success;
    public ArrayList<Relation2Model> data;
}