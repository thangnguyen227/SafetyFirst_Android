
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.ServiceModel;

import java.util.List;

public interface ChooseServiceView extends BaseView {
    void navigateBack();
    void showServicePage(int pos);
    void setData(List<ServiceModel> listNews);
}
