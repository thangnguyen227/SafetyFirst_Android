
package com.dichvudacbiet.safetyfirst.util;


import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.support.v4.app.FragmentManager;
import android.content.Context;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.github.jjobes.slidedatetimepicker.SlideDateTimeListener;
import com.github.jjobes.slidedatetimepicker.SlideDateTimePicker;
import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.adapter.HealthReviewAdapter;
import com.dichvudacbiet.safetyfirst.model.CountryModel;
import com.dichvudacbiet.safetyfirst.model.CoveringModel;
import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;
import com.dichvudacbiet.safetyfirst.model.ScheduleModel;
import com.dichvudacbiet.safetyfirst.model.network.CountriesRequest;
import com.dichvudacbiet.safetyfirst.model.network.HealthCareUpdateRequest;
import com.dichvudacbiet.safetyfirst.model.network.ReviewScheduleRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by ducth on 11/21/16.
 */

public class AlertUtil {
    private static Calendar myCalendar;
    private static DatePickerDialog.OnDateSetListener date;
    private static int mIdLocation;

    public static void showDatePickerDialog(Context context, View view, boolean isBirthDay) {

        myCalendar = Calendar.getInstance();
        date = (v, year, monthOfYear, dayOfMonth) -> {
            // TODO Auto-generated method stub
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            SimpleDateFormat sdf = null;
            if (isBirthDay) {
                sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            } else {
                sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.US);
            }

            if (view instanceof TextView) {
                ((TextView) view).setText(sdf.format(myCalendar.getTime()));
            }
            if (view instanceof EditText) {
                ((EditText) view).setText(sdf.format(myCalendar.getTime()));
            }
        };

        DatePickerDialog dpDialog = new DatePickerDialog(context, date, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH));
        dpDialog.show();
    }


    public static void showDateTimePickerDialog(FragmentManager fm, View view, boolean isBirthDay) {


        SlideDateTimeListener listener = new SlideDateTimeListener() {

            @Override
            public void onDateTimeSet(Date date) {
                SimpleDateFormat ft;
                if (isBirthDay) {
                    ft = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                } else {
                    ft = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.US);
                }

                if (view instanceof TextView) {
                    ((TextView) view).setText(ft.format(date.getTime()));
                }
                if (view instanceof EditText) {
                    ((EditText) view).setText(ft.format(date.getTime()));
                }

                // Do something with the date. This Date object contains
                // the date and time that the user has selected.
            }

            @Override
            public void onDateTimeCancel() {
                // Overriding onDateTimeCancel() is optional.
            }
        };

        new SlideDateTimePicker.Builder(fm)
                .setListener(listener)
                .setInitialDate(new Date())
                .setIs24HourTime(true)
                .build()
                .show();
    }

    // Trip dialog
    public static void showScheduleDialog(Activity activity, ScheduleModel msgOb) {
        class ImplementAction {
            public void onSendReviewUserScheule(int id, String reviewText, String rating) {

                ReviewScheduleRequest review = new ReviewScheduleRequest(id,0, reviewText, Double.parseDouble(rating));
                Call<ReviewScheduleRequest> call = ApiService.getClient().postReviewUser(PrefUtil.getTokenInfo(), review);
                call.enqueue(new Callback<ReviewScheduleRequest>() {
                    @Override
                    public void onResponse(Call<ReviewScheduleRequest> call, Response<ReviewScheduleRequest> response) {

                        if (response.isSuccessful()) {
                            //RC4
                            try {
                                Toast.makeText(activity, "Gửi thành công", Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        } else {
                            Toast.makeText(activity, "Gửi thất bại", Toast.LENGTH_SHORT).show();
                        }

                    }

                    @Override
                    public void onFailure(Call<ReviewScheduleRequest> call, Throwable t) {
                        Toast.makeText(activity, "Lỗi kết nối dữ liệu", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
        //
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_trip);
        Button dialogButton = (Button) dialog.findViewById(R.id.btn_dialog);
        //
        RelativeLayout rl_detail, rl_survey;
        rl_detail = dialog.findViewById(R.id.rl_detail);
        rl_survey = dialog.findViewById(R.id.rl_survey);
        TextView alertText = (TextView) dialog.findViewById(R.id.txt_alert);


        Date currentTime = Calendar.getInstance().getTime();


        if (currentTime.after(Util.formatStringToDate(msgOb.return_date))) {
            rl_detail.setVisibility(View.GONE);
            rl_survey.setVisibility(View.VISIBLE);
            alertText.setText("Chuyến đi của bạn đã hoàn thành, vui lòng dành chút thời gian để làm khảo sát");
            EditText edt_thingslike, edt_thingsdislike, edt_plan;

            //
            final String[] rating = new String[1];
            RatingBar ratingBar = dialog.findViewById(R.id.rating_bar);
            rating[0] = "2";
            ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                @Override
                public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                    rating[0] = "" + ratingBar.getRating();
                }
            });
            ratingBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (event.getAction() == MotionEvent.ACTION_UP) {
                        float touchPositionX = event.getX();
                        float width = ratingBar.getWidth();
                        float starsf = (touchPositionX / width) * 5.0f;
                        int stars = (int) starsf + 1;
                        ratingBar.setRating(stars);
                        v.setPressed(false);
                    }
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        v.setPressed(true);
                    }

                    if (event.getAction() == MotionEvent.ACTION_CANCEL) {
                        v.setPressed(false);
                    }


                    return true;
                }
            });

//            ratingBar.setOnRatingBarChangeListener((r,v,b)->{
//                        rating = String.valueOf(v);
//                    });


            //
            edt_thingslike = dialog.findViewById(R.id.edt_thingslike);
            edt_thingsdislike = dialog.findViewById(R.id.edt_thingsdislike);
            edt_plan = dialog.findViewById(R.id.edt_plan);

            //
            String survey = "- Thích: " + edt_thingslike.getText().toString() + "\n- Không thích:"
                    + edt_thingsdislike.getText().toString() + "\n- Dự định sẽ đi: " + edt_plan;

            dialogButton.setOnClickListener(e -> {
                ImplementAction perform = new ImplementAction();
                perform.onSendReviewUserScheule(msgOb.id, survey, rating[0]);
                dialog.dismiss();
            });
        } else {
            alertText.setText("Kế hoạch của bạn đang bắt đầu");
            TextView tv_destination, tv_date, tv_address, tv_name_agent;
            rl_survey.setVisibility(View.GONE);
            rl_detail.setVisibility(View.VISIBLE);

            //
            tv_destination = dialog.findViewById(R.id.tv_destination);
            tv_date = dialog.findViewById(R.id.tv_date);
            tv_address = dialog.findViewById(R.id.tv_address);
            tv_name_agent = dialog.findViewById(R.id.tv_name_agent);

            //
            tv_destination.setText(msgOb.destination.name);
            tv_date.setText(msgOb.depart_date + " -> " + msgOb.return_date);
            tv_address.setText(msgOb.staying_address);
            tv_name_agent.setText(msgOb.travel_company_name);

            dialogButton.setOnClickListener(e -> {
                dialog.dismiss();
            });
        }
        dialog.show();
    }

    public static void showHealthCareReviewDialog(Activity activity, int position, List<HealthCareActivateModel> arr, HealthReviewAdapter adapter) {
        //
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_health);

        RelativeLayout rl_parentContain = dialog.findViewById(R.id.rl_parentContain);
        class HandleService {
            class HealthCareResult {
                String result;

                public HealthCareResult(String result) {
                    this.result = result;
                }

            }

            public void updateUserHealthCareResult(int id, String result, String rating) {
                ReviewScheduleRequest review = new ReviewScheduleRequest(id,1, result, Double.parseDouble(rating));
                Call<ReviewScheduleRequest> call = ApiService.getClient().postReviewUser(PrefUtil.getTokenInfo(), review);
                call.enqueue(new Callback<ReviewScheduleRequest>() {
                    @Override
                    public void onResponse(Call<ReviewScheduleRequest> call, Response<ReviewScheduleRequest> response) {

                        if (response.isSuccessful()) {
                            //RC4
                            try {
                                Toast.makeText(activity, "Gửi kết quả thành công, cảm ơn thông tin của bạn!", Toast.LENGTH_LONG).show();
                                dialog.dismiss();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        } else {
                            Toast.makeText(activity, "Gửi thất bại", Toast.LENGTH_SHORT).show();
                        }

                    }

                    @Override
                    public void onFailure(Call<ReviewScheduleRequest> call, Throwable t) {
                        Toast.makeText(activity, "Lỗi kết nối dữ liệu", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            public void updateHealthSchedule(int id,int activity_id, String name, String date, String info) {

                HealthCareActivateModel data = new HealthCareActivateModel(activity_id, name, date, info);
                Call<HealthCareUpdateRequest> call = ApiService.getClient().postUpdateHealthSchedule(String.valueOf(id), PrefUtil.getTokenInfo(), data);
                call.enqueue(new Callback<HealthCareUpdateRequest>() {
                    @Override
                    public void onResponse(Call<HealthCareUpdateRequest> call, Response<HealthCareUpdateRequest> response) {

                        if (response.isSuccessful()) {
                            //RC4
                            try {
                                Toast.makeText(activity, "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        } else {
                            Toast.makeText(activity, "Gửi thất bại", Toast.LENGTH_SHORT).show();
                        }

                    }

                    @Override
                    public void onFailure(Call<HealthCareUpdateRequest> call, Throwable t) {
                        Toast.makeText(activity, "Lỗi kết nối dữ liệu", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }


        //
        LinearLayout rl_detail, rl_survey;
        rl_detail = dialog.findViewById(R.id.ll_containContent);
        rl_survey = dialog.findViewById(R.id.ll_survey);
        TextView alertText = (TextView) dialog.findViewById(R.id.txt_alert);


        Date currentTime = Calendar.getInstance().getTime();


        if (currentTime.after(Util.formatStringToDate(arr.get(position).time))) {
            EditText ed_result = dialog.findViewById(R.id.ed_result);
            Button dialogButton = (Button) dialog.findViewById(R.id.btn_done);
            final String[] rating = new String[1];
            RatingBar ratingBar = dialog.findViewById(R.id.rating_bar);
            rating[0] = "2";
            ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                @Override
                public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                    rating[0] = "" + ratingBar.getRating();
                }
            });
            ratingBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (event.getAction() == MotionEvent.ACTION_UP) {
                        float touchPositionX = event.getX();
                        float width = ratingBar.getWidth();
                        float starsf = (touchPositionX / width) * 5.0f;
                        int stars = (int) starsf + 1;
                        ratingBar.setRating(stars);
                        v.setPressed(false);
                    }
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        v.setPressed(true);
                    }

                    if (event.getAction() == MotionEvent.ACTION_CANCEL) {
                        v.setPressed(false);
                    }


                    return true;
                }
            });


            rl_detail.setVisibility(View.GONE);
            rl_survey.setVisibility(View.VISIBLE);
            alertText.setText("Lịch khám sức khỏe đã kết thúc!");
            rl_parentContain.setBackgroundColor(Color.parseColor("#f1eec5"));
            dialogButton.setOnClickListener(e -> {
                HandleService perform = new HandleService();
                perform.updateUserHealthCareResult(arr.get(position).activity_id, ed_result.getText().toString(),rating[0]);
            });
        } else {
            alertText.setText("Kế hoạch của bạn đang bắt đầu");
            rl_parentContain.setBackgroundColor(Color.parseColor("#FFFFFF"));
            rl_detail.setVisibility(View.VISIBLE);
            rl_survey.setVisibility(View.GONE);
            EditText edt_date, edt_info;
            TextView tv_health_type;
            Button dialogButton = (Button) dialog.findViewById(R.id.btn_dialog);
            //
            tv_health_type = dialog.findViewById(R.id.tv_health_type);
            edt_date = dialog.findViewById(R.id.edt_date);
            edt_info = dialog.findViewById(R.id.edt_info);

            tv_health_type.setText(arr.get(position).plain_text);
            edt_date.setText(arr.get(position).time);
            edt_info.setText(arr.get(position).note);

            //

            dialogButton.setOnClickListener(e -> {
                String plain_text = tv_health_type.getText().toString();
                String date = edt_date.getText().toString();
                String info = edt_info.getText().toString();
                arr.get(position).plain_text = plain_text;
                arr.get(position).time = date;
                arr.get(position).note = info;
                HandleService perform = new HandleService();
                perform.updateHealthSchedule(arr.get(position).id,arr.get(position).activity.id, plain_text, date, info);
                adapter.notifyDataSetChanged();
                dialog.dismiss();

            });
        }
        dialog.show();
    }

    static class Notifications{
        int location_id;
        public String content;
        public boolean spread_right_now;
        public String scope;
        public String type;
        public String title;
        public Notifications(int location_id, String c){
            content = c;
            this.location_id  = location_id;
            title = "Thông báo";
            spread_right_now= true;
            scope = "system_wide";
            type = "show_popup";
        }
    }

    public static void showPushEmergency(Activity activity) {
        //
        Spinner mCountry, mCity;
        //
        EditText edit_content;

        //
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_push);
        dialog.show();
        //


        //
        mCountry = (Spinner) dialog.findViewById(R.id.sp_country);
        mCity = (Spinner) dialog.findViewById(R.id.sp_city);
       // mSpinerAddress = (Spinner) dialog.findViewById(R.id.sp_address);
        edit_content = (EditText) dialog.findViewById(R.id.edit_content);
        TextView alertText = (TextView) dialog.findViewById(R.id.txt_alert);
        alertText.setText(activity.getResources().getString(R.string.emergency_broadcast));


        class ControllerHandle {
            public ControllerHandle() {
                loadCoutry();
            }

            public void showCountryList(ArrayList<LocationModel> countryModel) {
                ArrayList<String> mList = new ArrayList<String>();
                for (int i = 0; i < countryModel.size(); i++) {
                    mList.add(countryModel.get(i).name);
                }
                ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                        activity, android.R.layout.simple_spinner_item, mList);
                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                mCountry.setAdapter(spinnerArrayAdapter);
                mCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        loadDataCity(countryModel.get(position).id);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
            }


            public void showCityList(ArrayList<LocationModel> countryModel) {
                ArrayList<String> mList = new ArrayList<String>();
                for (int i = 0; i < countryModel.size(); i++) {
                    mList.add(countryModel.get(i).name);
                }
                ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                        activity, android.R.layout.simple_spinner_item, mList);
                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                mCity.setAdapter(spinnerArrayAdapter);
                mCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                        showCoveringList(countryModel.get(position).covering);
                        mIdLocation = countryModel.get(position).id;
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
            }

         /*   public void showCoveringList(ArrayList<CoveringModel> countryModel) {
                ArrayList<String> mList = new ArrayList<String>();
                for (int i = 0; i < countryModel.size(); i++) {
                    mList.add(countryModel.get(i).name);
                }
                ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                        activity, android.R.layout.simple_spinner_item, mList);
                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                mSpinerAddress.setAdapter(spinnerArrayAdapter);
                mSpinerAddress.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                        mIdAddress = countryModel.get(position).id;
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
            }*/


            private void loadCoutry() {

                Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_COUNTRY,null);
                call.enqueue(new Callback<CountriesRequest>() {
                    @Override
                    public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                        if (response.isSuccessful()) {
                            //RC4
                            try {
                                ArrayList<LocationModel> respondData = response.body().data;
                                showCountryList(respondData);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        } else {
//                                getView().showMessage("Lỗi kết nối dữ liệu" , false);
                        }

                    }

                    @Override
                    public void onFailure(Call<CountriesRequest> call, Throwable t) {
//                            getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }
                });
            }

            public void loadDataCity(int country_id) {


                Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_PROVINCE,country_id);
                call.enqueue(new Callback<CountriesRequest>() {
                    @Override
                    public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                        if (response.isSuccessful()) {
                            //RC4
                            try {
                                ArrayList<LocationModel> respondData = response.body().data;
                                showCityList(respondData);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        } else {
//                            getView().showMessage("Lỗi kết nối dữ liệu" , false);
                        }

                    }

                    @Override
                    public void onFailure(Call<CountriesRequest> call, Throwable t) {
//                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }
                });
            }

            public void notifications(int location_id,String c) {


                Call<Object> call = ApiService.getClient().broadcastMessage(PrefUtil.getTokenInfo(),new Notifications(location_id,c));
                call.enqueue(new Callback<Object>() {
                    @Override
                    public void onResponse(Call<Object> call, Response<Object> response) {

                        if (response.isSuccessful()) {
                            //RC4
                            try {
                                Toast.makeText(activity, "Gửi thông báo thành công!", Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        } else {
                            dialog.dismiss();
                            Toast.makeText(activity, "Thất bại! "+ response.errorBody(), Toast.LENGTH_SHORT).show();
//                            getView().showMessage("Lỗi kết nối dữ liệu" , false);
                        }

                    }

                    @Override
                    public void onFailure(Call<Object> call, Throwable t) {
                        dialog.dismiss();
                        Toast.makeText(activity, "Gửi thông báo thất bại! "+ t.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                });

            }

        }

        ControllerHandle controllerHandle = new ControllerHandle();
        Button dialogButton = (Button) dialog.findViewById(R.id.btn_dialog);
        dialogButton.setText("Gửi ngay");
        dialogButton.setOnClickListener(e -> {
            controllerHandle.notifications(mIdLocation,edit_content.getText().toString());


        });
    }


}
