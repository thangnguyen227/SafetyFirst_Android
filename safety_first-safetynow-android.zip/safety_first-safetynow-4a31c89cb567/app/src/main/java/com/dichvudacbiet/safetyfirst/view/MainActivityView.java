
package com.dichvudacbiet.safetyfirst.view;



public interface MainActivityView extends BaseView {
    void showHomePage();
    void showLoginPage();

}
