
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.base.SafetyApplication;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.SupportModel;
import com.dichvudacbiet.safetyfirst.model.network.CountriesRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.view.RescueDetailView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RescueDetailPresenter extends BasePresenter<RescueDetailView> {

    private List<SupportModel> supportModelList = new ArrayList<>();
    private boolean isReady = false;

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
            onLoadCountries();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            if (supportModelList.size() <= 0) {
                SupportModel movie = new SupportModel(SafetyApplication.self().getString(R.string.info_of_hospital_medical_center), 0);
                supportModelList.add(movie);
                SupportModel movie1 = new SupportModel(SafetyApplication.self().getString(R.string.info_of_local_poly_team), 5);
                supportModelList.add(movie1);
                SupportModel movie7 = new SupportModel(SafetyApplication.self().getString(R.string.info_of_local_rescue_team), 4);
                supportModelList.add(movie7);
                SupportModel movie2 = new SupportModel(SafetyApplication.self().getString(R.string.info_of_service_travel_agent), 3);
                supportModelList.add(movie2);
                SupportModel movie3 = new SupportModel(SafetyApplication.self().getString(R.string.info_of_embassy_represent_office), 2);
                supportModelList.add(movie3);
                SupportModel movie4 = new SupportModel(SafetyApplication.self().getString(R.string.info_of_restaurant_shopping_1), 6);
                supportModelList.add(movie4);
                SupportModel movie5 = new SupportModel(SafetyApplication.self().getString(R.string.info_of_best_local_fools_stuffs), 7);
                supportModelList.add(movie5);
                SupportModel movie6 = new SupportModel(SafetyApplication.self().getString(R.string.info_of_local_groups_unions), 1);
                supportModelList.add(movie6);
               /* SupportModel movie7 = new SupportModel("BMI", 1);
                supportModelList.add(movie7);*/
                getView().setData(supportModelList);
            } else {
                getView().setData(supportModelList);
            }

        }
    }

    public void onLoadCountries() {
        isReady = false;
        if (isViewAttached()) {

            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_COUNTRY, null);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<LocationModel> respondData = response.body().data;
                            getView().setCountryData(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        //Utility.showSnackBar(RegisterActivity.this, findViewById(android.R.id.content)  ,"Lỗi kết nối dữ liệu" );
                    }

                }

                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    //Utility.showSnackBar(RegisterActivity.this, findViewById(android.R.id.content)  ,"Lỗi kết nối dữ liệu" );
                }
            });
        }
    }


    public void loadDataProvince(int country_id) {
        if (isViewAttached()) {

            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_PROVINCE, country_id);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<LocationModel> respondData = response.body().data;
                            getView().setProvinceData(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        getView().showMessage("Lỗi kết nối dữ liệu", false);
                    }

                }

                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }
            });
        }
    }

    public void loadDataAddress(final int id_city) {

        if (isViewAttached()) {

            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_DISTRICT, id_city);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        isReady = true;
                        try {
                            ArrayList<LocationModel> respondData = response.body().data;
                            getView().showCoveringList(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        getView().showMessage("Lỗi kết nối dữ liệu", false);
                    }

                }

                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }
            });
        }

    }

    public void onNewsClicked(SupportModel news, int position) {
        if (isViewAttached() && isReady) {
            if (position == 7)
                getView().navigateToBMI();
            else
                getView().showNational(news.type);
        }
    }

    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
