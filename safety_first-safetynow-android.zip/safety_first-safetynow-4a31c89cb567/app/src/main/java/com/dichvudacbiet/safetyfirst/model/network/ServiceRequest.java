package com.dichvudacbiet.safetyfirst.model.network;

public class ServiceRequest {

    public int user_id;
    public int id;
    public int travel_type;
    public String depart_date;
    public String return_date;
    public int destination_id;
    public String travel_company_name;
    public String staying_address;
    public String contact_number;
    public String info;

    private ServiceRequest(Builder builder) {
        user_id = builder.user_id;
        id = builder.id;
        travel_type = builder.travel_type;
        depart_date = builder.depart_date;
        return_date = builder.return_date;
        destination_id = builder.destination_id;
        staying_address = builder.staying_address;
        travel_company_name = builder.travel_company_name;
        contact_number = builder.contact_number;
        info = builder.info;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private int user_id;
        private int id;
        private int travel_type;
        private String depart_date;
        private String return_date;
        private int destination_id;
        private String travel_company_name;
        private String staying_address;
        private String contact_number;
        private String info;

        private Builder() {
        }

        public Builder user_id(int val) {
            user_id = val;
            return this;
        }

        public Builder id(int val) {
            id = val;
            return this;
        }

        public Builder travel_type(int val) {
            travel_type = val;
            return this;
        }

        public Builder from_date(String val) {
            depart_date = val;
            return this;
        }

        public Builder to_date(String val) {
            return_date = val;
            return this;
        }

        public Builder destination_id(int val) {
            destination_id = val;
            return this;
        }

        public Builder staying_address(String val) {
            staying_address = val;
            return this;
        }

        public Builder contact_number(String val) {
            contact_number = val;
            return this;
        }
        public Builder agency(String val) {
            travel_company_name = val;
            return this;
        }
        public Builder info(String val) {
            info = val;
            return this;
        }
        public ServiceRequest build() {
            return new ServiceRequest(this);
        }
    }
}
