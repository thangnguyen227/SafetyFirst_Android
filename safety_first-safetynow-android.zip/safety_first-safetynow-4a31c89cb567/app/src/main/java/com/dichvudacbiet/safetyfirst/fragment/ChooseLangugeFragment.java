package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.ChooseLanguageAdapter;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.model.Language;
import com.dichvudacbiet.safetyfirst.presenter.ChooseLanguagePresenter;
import com.dichvudacbiet.safetyfirst.util.LanguageUtils;
import com.dichvudacbiet.safetyfirst.view.ChooseLanguageView;

import java.util.List;

public class ChooseLangugeFragment extends BaseFragment<ChooseLanguageView, ChooseLanguagePresenter>
        implements ChooseLanguageView, View.OnClickListener , RecyclerViewOnItemClickedListener<Language> {


    private RecyclerView rvList;
    private ChooseLanguageAdapter adapter;
    private TextView mToolbarTitle;
    public ChooseLangugeFragment() {
        // Required empty public constructor
    }

    @Override
    public ChooseLanguagePresenter createPresenter() {
        return new ChooseLanguagePresenter();
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText("Ngôn ngữ");
        mToolbarTitle.setVisibility(View.VISIBLE);
        //

        adapter = new ChooseLanguageAdapter();
        adapter.setOnItemClickListener(this);
        rvList = (RecyclerView) view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rvList.setAdapter(adapter);
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void navigateToRegister() {
        ((BaseActivity) getActivity()).pushFragment(new RegisterFragment(), true);
    }

    @Override
    public void setData(List<Language> datas) {
        adapter.setListNews(datas);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, Language language, int position) {
        LanguageUtils.changeLanguage(language);
        navigateToRegister();
    }

    @Override
    public void onClick(View view) {

    }

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_choose_languge;
    }
}
