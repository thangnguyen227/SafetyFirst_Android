package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.SosModel;

import java.util.ArrayList;

public class SosRequestList {
    public int status;
    public ArrayList<SosModel> data;
}