
package com.dichvudacbiet.safetyfirst.base;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;

import com.google.gson.Gson;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;


/**
 * Created by ducth on 11/17/16.
 */

public class SafetyApplication extends Application {


    public static final Gson GSON = new Gson();
    public static boolean isMainActivityStarted;
    private static SafetyApplication sInstance;
    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        PrefUtil.init(this);
    }

    public static SafetyApplication self() {
        return sInstance;
    }

}
