package com.dichvudacbiet.safetyfirst.util;

import android.location.Location;

import com.dichvudacbiet.safetyfirst.model.UserInfo;
import com.dichvudacbiet.safetyfirst.model.VaccinModel;
import com.dichvudacbiet.safetyfirst.model.network.VaccinRequestObject;

/**
 * Created by khant on 19/03/2018.
 */

public class Session {
    public static VaccinRequestObject vaccinRequestObject;
    public static  VaccinModel vaccinModel;
    public static UserInfo userInfo;
    public static  int VACCIN_UPDATE_OR_CREATE;
    public static String COUNTRY_NAME = "";
    public static String COUNTRY_CODE = "";
    public static String COUNTRY_AMBULANCE_NUMBER = "";
    public static String COUNTRY_POLICE_NUMBER ="";
    public static String COUNTRY_FIRE_NUMBER ="";
    public static final int LEVEL_COUNTRY = 1;
    public static final int LEVEL_PROVINCE = 2;
    public static final int LEVEL_DISTRICT = 3;
    public static Location location;


    public enum PhoneType{
        TYPE_EMERGENCY(0),TYPE_POLICE(1),TYPE_HOSPITAL(2),TYPE_FIRE(3);

        private final int TYPE;
        PhoneType(int type){
            this.TYPE = type;
        }
        public int type(){
            return TYPE;
        }
    }
}
