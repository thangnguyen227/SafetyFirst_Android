package com.dichvudacbiet.safetyfirst.view;

/**
 * Created by ducth on 11/24/16.
 */

public interface ProfileUserView extends BaseView{
    void navigateBack();
}
