
package com.dichvudacbiet.safetyfirst.util;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Point;
import android.net.ParseException;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.Language;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by ducth on 12/23/15.
 */
public class Util {

    public static Observable<Long> delayExecute(int delayTimeInMillisecond) {
        return Observable
                .create(new Observable.OnSubscribe<Long>() {
                    @Override
                    public void call(Subscriber<? super Long> subscriber) {
                        subscriber.onNext(0L);
                        subscriber.onCompleted();
                    }
                })
                .delay(delayTimeInMillisecond, TimeUnit.MILLISECONDS)
                .subscribeOn(AndroidSchedulers.mainThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public static boolean isNullOrEmpty(String text) {
        return text == null || text.length() == 0;
    }

    public static void hideKeyboard(Activity activity) {
        View focusedView = activity.getCurrentFocus();
        if (focusedView == null)
            return;
        hideKeyboard(activity, focusedView);
    }

    public static void hideKeyboard(Context context, View view) {
        view.clearFocus();
        InputMethodManager imm = (InputMethodManager) context
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static String safelyGetTextFromEditText(EditText editText) {
        return editText.getText() != null ? editText.getText().toString() : "";
    }

    public static Point getScreenSize(Activity activity) {
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);

        return new Point(metrics.widthPixels, metrics.heightPixels);
    }

    public static String makeGoogleDocsLink(String link) {
        return "http://docs.google.com/gview?embedded=true&url=" + link;
    }

    public static int dpToPx(int dp) {
        return (int) (dp * Resources.getSystem().getDisplayMetrics().density);
    }

    public static int pxToDp(int px) {
        return (int) (px / Resources.getSystem().getDisplayMetrics().density);
    }

    public static int getNavigationBarHeight(Context context) {
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen",
                "android");
        if (resourceId > 0) {
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    public static boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
    public static String formateDateFromstring(String inputFormat, String outputFormat, String inputDate){

        Date parsed = null;
        String outputDate = "";

        SimpleDateFormat df_input = new SimpleDateFormat(inputFormat);
        df_input.setTimeZone(TimeZone.getTimeZone("UTC"));

        SimpleDateFormat df_output = new SimpleDateFormat(outputFormat);

        try {
            try {
                parsed = df_input.parse(inputDate);
            } catch (java.text.ParseException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            outputDate = df_output.format(parsed);

        } catch (ParseException e) {

        }

        return outputDate;
    }

    public static Date formatStringToDate(String dtStart){
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {
             date = format.parse(dtStart);
        } catch (java.text.ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    public static int validateInput(String...data) {
        if(data.length> 0){
            for(int i = 0 ; i < data.length; i++){
                if(Util.isNullOrEmpty(data[i])){
                    return R.string.please_fill_all_input;
                }
            }
            return -1;
        }
        return  R.string.please_fill_all_input;
    }

    public static String getLangCode(){
        if(PrefUtil.get(PrefUtil.LANGUAGE, Language.class) != null){
            return String.valueOf(PrefUtil.get(PrefUtil.LANGUAGE, Language.class).getCode());
        }else{
            return "vn";
        }

    }




    public static final String CODE = getLangCode();
}
