
package com.dichvudacbiet.safetyfirst.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.fragment.ProfileEditFragment;
import com.dichvudacbiet.safetyfirst.model.Relation2Model;
import com.dichvudacbiet.safetyfirst.model.RelationModel;

import net.cachapa.expandablelayout.ExpandableLayout;

import java.util.ArrayList;
import java.util.List;


public class RelationAdapter extends  RecyclerView.Adapter<RelationAdapter.MyViewHolder>
        implements View.OnClickListener,ProfileEditFragment.SetAgainRelation {

    private List<RelationModel> relationList;
    private RecyclerView rvList;
    protected RecyclerViewOnItemClickedListener<RelationModel> listener;
    private Context mContext;
    private Spinner mSpiner;
    private String name;
    ArrayList<Relation2Model> relation2Models;

    public RelationAdapter(Context context){
        mContext = context;
    }

    public void setListNews(List<RelationModel> listNews) {
        this.relationList = listNews;
    }
    public void setRelation2List(ArrayList<Relation2Model> relation2Models){
        this.relation2Models = relation2Models;

    }

    public List<RelationModel> getListNews() {
        return relationList;
    }

    public void setOnItemClickListener(RecyclerViewOnItemClickedListener<RelationModel> listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        View containingView = rvList.findContainingItemView(v);
        int position = rvList.getChildAdapterPosition(containingView);
        if (position == RecyclerView.NO_POSITION) {
            return;
        }

        if (listener != null) {
            listener.onItemClicked(rvList, relationList.get(position), position);
        }
    }

    @Override
    public void onSetAgainRelation() {
        mSpiner.setSelection(getIndexSpiner(mSpiner, name));
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public EditText edit_telephone,edit_mobilephone,edit_relation;
        private TextView expandButton;
        private ExpandableLayout expandableLayout;
        private Spinner mSpRelation;
        public EditText tv_name;
        public MyViewHolder(View view) {
            super(view);
            tv_name = view.findViewById(R.id.tv_name);
            edit_telephone =  view.findViewById(R.id.edit_telephone);
            edit_mobilephone = view.findViewById(R.id.edit_mobilephone);
            edit_relation = view.findViewById(R.id.edit_relation);
            mSpRelation =  view.findViewById(R.id.sp_contact);
            expandButton = view.findViewById(R.id.expand_button);
            expandableLayout = view.findViewById(R.id.expandable_layout);
//            spn_relation = view.findViewById(R.id.spn_relation);
        }

    }



    @Override
    public int getItemViewType(int position) {

        return position;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_relation, parent, false);
        itemView.setOnClickListener(this);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        RelationModel relationModel = relationList.get(position);
        holder.tv_name.setText(relationModel.fullname);
        holder.edit_telephone.setText(relationModel.phone_number);
        holder.edit_mobilephone.setText(relationModel.mobile_number);
        holder.expandButton.setText(relationModel.fullname);
        holder.expandButton.setOnClickListener(v->{
            holder.expandableLayout.toggle();
        });


//        holder.edit_relation.setText(relationModel.type.name);
        mSpiner = holder.mSpRelation;
        if(relationModel.type!=null){
            name = relationModel.type.name;
            if(relation2Models!=null && relation2Models.size()>0){
                showRelation(holder.mSpRelation,relation2Models,position);
                holder.mSpRelation.setSelection(getIndexSpiner(holder.mSpRelation, relationModel.type.name));
            }
        }


        holder.edit_mobilephone.setTag("mobilephone");
        holder.edit_mobilephone.addTextChangedListener(onTextWatcher(holder.edit_mobilephone, position));
        holder.edit_telephone.setTag("telephone");
        holder.edit_telephone.addTextChangedListener(onTextWatcher(holder.edit_telephone, position));
        holder.tv_name.setTag("name");
        holder.tv_name.addTextChangedListener(onTextWatcher(holder.tv_name, position));
    }

    private TextWatcher onTextWatcher(View v, int p){
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(v.getTag().equals("name")){
                    relationList.get(p).fullname = editable.toString();
                }else if(v.getTag().equals("telephone")){
                    relationList.get(p).phone_number = editable.toString();
                }else if(v.getTag().equals("mobilephone")){
                    relationList.get(p).mobile_number = editable.toString();
                }

            }
        };
        return textWatcher;
    }

    @Override
    public int getItemCount() {
        return relationList!= null? relationList.size(): 0;
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        rvList = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        rvList = null;
        super.onDetachedFromRecyclerView(recyclerView);
    }
    //Adapter

    public void showRelation(Spinner mSpRelation,ArrayList<Relation2Model> relation2Models, int p) {
        ArrayList<String> mList = new ArrayList<String>();
        for (int i = 0 ; i < relation2Models.size(); i++){
            mList.add(relation2Models.get(i).name);
        }

        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                mContext, android.R.layout.simple_spinner_item, mList);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        mSpRelation.setAdapter(spinnerArrayAdapter);
        mSpRelation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                mIdRelation = relation2Models.get(position).id;
//                relation_type = relation2Models.get(position).name;
                relationList.get(p).type_id = relation2Models.get(position).id;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private int getIndexSpiner(Spinner spinner, String myString){

        int index = 0;

        for (int i=0;i<spinner.getCount();i++){
            if (spinner.getItemAtPosition(i).equals(myString)){
                index = i;
            }
        }
        return index;
    }


}

