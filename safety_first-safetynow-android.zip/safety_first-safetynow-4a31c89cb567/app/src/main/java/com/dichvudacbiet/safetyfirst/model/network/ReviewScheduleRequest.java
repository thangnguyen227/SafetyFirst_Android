package com.dichvudacbiet.safetyfirst.model.network;

/**
 * Created by khant on 13/03/2018.
 */

public class ReviewScheduleRequest {
    public int reference_id;
    public int type;
    public String content;
    public double rating;
    public ReviewScheduleRequest(int id, int type, String content, double rating){
        this.reference_id = id;
        this.type = type;
        this.content = content;
        this.rating = rating;
    }
}
