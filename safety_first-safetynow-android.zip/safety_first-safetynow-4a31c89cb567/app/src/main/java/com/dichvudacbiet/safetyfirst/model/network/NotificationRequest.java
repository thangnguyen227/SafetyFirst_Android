package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.NotificationModel;

import java.util.ArrayList;

public class NotificationRequest {

    public int status;
    public ArrayList<NotificationModel> data;
}