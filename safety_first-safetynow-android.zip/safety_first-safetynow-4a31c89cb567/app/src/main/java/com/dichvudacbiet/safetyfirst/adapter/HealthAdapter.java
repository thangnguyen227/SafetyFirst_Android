
package com.dichvudacbiet.safetyfirst.adapter;

import android.app.DatePickerDialog;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;
import com.dichvudacbiet.safetyfirst.util.AlertUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;


public class HealthAdapter extends  RecyclerView.Adapter<HealthAdapter.MyViewHolder>
        implements View.OnClickListener {

    private List<HealthCareActivateModel> healthList = new ArrayList<>();
    private RecyclerView rvList;
    protected RecyclerViewOnItemClickedListener<HealthCareActivateModel> listener;
    private Context mContext;
    private Calendar myCalendar;
    private DatePickerDialog.OnDateSetListener date;

    public HealthAdapter(Context context ){
        mContext = context;
    }
    public void setListNews(List<HealthCareActivateModel> listNews) {
        this.healthList = listNews;
    }

    public List<HealthCareActivateModel> getListNews() {
        return healthList;
    }

    public void setOnItemClickListener(RecyclerViewOnItemClickedListener<HealthCareActivateModel> listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        View containingView = rvList.findContainingItemView(v);
        int position = rvList.getChildAdapterPosition(containingView);
        if (position == RecyclerView.NO_POSITION) {
            return;
        }

        if (listener != null) {
            listener.onItemClicked(rvList, healthList.get(position), position);
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView mName,mInfo,mDate;
        public MyViewHolder(View view) {
            super(view);
            mName = view.findViewById(R.id.tv_name);
            mInfo =  view.findViewById(R.id.tv_info);
            mDate = view.findViewById(R.id.tv_date);
        }

    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_healthy, parent, false);

        return new MyViewHolder(itemView);
    }
    TextView tvTemp;
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        HealthCareActivateModel healthModel = healthList.get(position);
        holder.mName.setText(healthModel.plain_text);
        holder.mInfo.setText(healthModel.note);
        holder.mDate.setText(healthModel.time);
        holder.mDate.setOnClickListener(v->{
            tvTemp = holder.mDate;
            AlertUtil.showDatePickerDialog(mContext,tvTemp,false);
        });
        myCalendar = Calendar.getInstance();
        date = (v,  year,  monthOfYear, dayOfMonth) -> {
            // TODO Auto-generated method stub
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            if(tvTemp!=null)
            updateLabel(tvTemp);
        };


    }





    private void updateLabel(TextView mDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm", Locale.US);
        mDate.setText(sdf.format(myCalendar.getTime()));
    }

    @Override
    public int getItemCount() {
        return healthList.size();
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        rvList = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        rvList = null;
        super.onDetachedFromRecyclerView(recyclerView);
    }
    //Adapter


}

