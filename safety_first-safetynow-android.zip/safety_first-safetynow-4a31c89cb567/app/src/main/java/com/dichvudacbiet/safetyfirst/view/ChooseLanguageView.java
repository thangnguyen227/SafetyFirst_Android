package com.dichvudacbiet.safetyfirst.view;

import com.dichvudacbiet.safetyfirst.model.Language;

import java.util.List;

/**
 * Created by ducth on 11/24/16.
 */

public interface ChooseLanguageView extends BaseView{
    void navigateBack();
    void navigateToRegister();
    void setData(List<Language> datas);
}
