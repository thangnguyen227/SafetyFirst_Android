package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 01/02/18.
 */

public class ScheduleModel {
    public int id;
    public int user_id;
    public int travel_type;
    public String user_name;
    public String depart_date;
    public String return_date;
    public String staying_address;
    public String contact_number;
    public String travel_company_name;
    public LocationModel destination;

    @Override
    public String toString() {
        return "ScheduleModel{" +
                "id=" + id +
                ", user_id=" + user_id +
                ", travel_type=" + travel_type +
                ", user_name='" + user_name + '\'' +
                ", depart_date='" + depart_date + '\'' +
                ", return_date='" + return_date + '\'' +
                ", staying_address='" + staying_address + '\'' +
                ", contact_number='" + contact_number + '\'' +
                ", travel_company_name='" + travel_company_name + '\'' +
                ", destination=" + destination +
                '}';
    }
}
