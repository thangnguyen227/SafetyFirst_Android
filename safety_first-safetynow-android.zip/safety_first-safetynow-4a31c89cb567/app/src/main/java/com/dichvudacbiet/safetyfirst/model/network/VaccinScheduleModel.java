package com.dichvudacbiet.safetyfirst.model.network;

/**
 * Created by khant on 18/03/2018.
 */

public class VaccinScheduleModel {
    public int id;
    public int user_vaccination_info_id;
    public int vaccination_info_id;
    public String name = "";
    public String date_time = "";
    public String location = "";
    public String info = "";
    public String created_at;
    public String updated_at;
}
