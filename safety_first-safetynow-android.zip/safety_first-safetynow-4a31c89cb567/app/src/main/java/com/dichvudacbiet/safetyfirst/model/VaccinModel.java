package com.dichvudacbiet.safetyfirst.model;

import java.util.List;

/**
 * Created by Kha nguyen.
 */
public class VaccinModel {
    public int id;
    public String fullname = "";
    public String info = "";
    public int gender;
    public String birth_date = "";
    public String birth_weight;
    public String birth_height;
    public List<VaccinInfoModel> vaccinations;

}
