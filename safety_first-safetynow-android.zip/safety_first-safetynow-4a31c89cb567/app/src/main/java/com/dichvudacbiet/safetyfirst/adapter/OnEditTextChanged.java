package com.dichvudacbiet.safetyfirst.adapter;

public interface OnEditTextChanged {
    void onTextChanged(int position, String charSeq);
}