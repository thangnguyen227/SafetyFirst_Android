
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.model.UserInfo;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.view.MainActivityView;


public class MainActivityPresenter extends BasePresenter<MainActivityView> {

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {

            onLoginChanged();

            /*addSubscription(Observable
                    .just(PrefUtil.getDeviceInfo())
                    .filter(deviceId -> deviceId == null)
                    .flatMap(deviceId -> Observable.create(new Observable.OnSubscribe<String>() {
                        @Override
                        public void call(Subscriber<? super String> subscriber) {
                            OneSignal.idsAvailable((userId, registrationId) -> {
                                DebugLog.d("userId", "userId=" + userId);
                                DebugLog.d("registrationId", "registrationId=" + registrationId);

                                subscriber.onNext(userId);
                                subscriber.onCompleted();
                            });
                        }
                    }))
                    .filter(userId -> userId != null && userId.length() > 0)
                    .flatMap(userId -> {
                        DebugLog.w("OneSignal", "userId= " + userId);
                        return NetworkService.updateDeviceInfo(userId, 0, 0);
                    })
                    .subscribe(new SubscriberImpl<DeviceInfo>() {
                        @Override
                        public void onNext(DeviceInfo deviceInfo) {
                            DebugLog.w("deviceId", deviceInfo.deviceId);
                            PrefUtil.setDeviceInfo(deviceInfo);
                        }
                    }));*/
        }
    }


    private void onLoginChanged() {
        if (isViewAttached()) {
            UserInfo userInfo = PrefUtil.getUserInfo();
            if (userInfo != null) {
                getView().showHomePage();
                //EventBus.getDefault().post(new LoadUserStatsEvent());
            } else {
                getView().showLoginPage();
            }
        }
    }

}
