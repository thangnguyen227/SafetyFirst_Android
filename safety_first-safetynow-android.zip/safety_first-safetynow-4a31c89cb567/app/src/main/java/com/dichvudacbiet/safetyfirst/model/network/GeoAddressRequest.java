package com.dichvudacbiet.safetyfirst.model.network;
import java.util.List;

public class GeoAddressRequest {

    public PlusCode plus_code;
    public List<AddressComponent> results;

    public class PlusCode {
        public String compound_code;
        public String global_code;
    }

    public class AddressComponent {

    }

}