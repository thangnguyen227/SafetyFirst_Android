
package com.dichvudacbiet.safetyfirst.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.dichvudacbiet.safetyfirst.model.PhoneBookModel;
import com.dichvudacbiet.safetyfirst.util.LanguageUtils;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.model.CountryEmergencyNumber;
import com.dichvudacbiet.safetyfirst.model.network.CountryEmerNumByCountryRequest;
import com.dichvudacbiet.safetyfirst.presenter.HomePresenter;
import com.dichvudacbiet.safetyfirst.util.AlertUtil;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.view.HomeView;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import static com.dichvudacbiet.safetyfirst.util.Session.PhoneType;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;


public class HomeFragment extends BaseFragment<HomeView, HomePresenter>
        implements HomeView, View.OnClickListener , OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener {

    private TextView mToolbarTitle, top_bar_tvBadge;
    private LinearLayout mArea113, mArea114 , mArea115 , mAreaSupport , mAreaService , mAreaInfo , mAreaCallEnge, mRescueSkill, mAreaNotify;
    private ImageButton mUsername, mNotify, mPush;
   // private SupportMapFragment mapFragment;
    GoogleMap mGoogleMap;
    SupportMapFragment mapFrag;
    LocationRequest mLocationRequest;
    GoogleApiClient mGoogleApiClient;
    Location mLastLocation;
    Marker mCurrLocationMarker;
    //

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_home;
    }



    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        LanguageUtils.loadLocale();

        //
        top_bar_tvBadge = view.findViewById(R.id.top_bar_tvBadge);
        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.home));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //
        mUsername = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        mUsername.setOnClickListener(this);
        //
        mNotify = (ImageButton) view.findViewById(R.id.top_bar_btnRight);
        mNotify.setOnClickListener(this);
        //
        mPush = view.findViewById(R.id.top_bar_btn_push);
        mPush.setOnClickListener(this);
        if(PrefUtil.getUserInfo().role==0){
            mPush.setVisibility(View.GONE);
        }else{
            mPush.setVisibility(View.VISIBLE);
        }
        //
        mArea113 = (LinearLayout) view.findViewById(R.id.area_call_113);
        mArea114 = (LinearLayout) view.findViewById(R.id.area_call_114);
        mArea115 = (LinearLayout) view.findViewById(R.id.area_call_115);
        mAreaSupport = (LinearLayout) view.findViewById(R.id.area_support);
        mAreaService = (LinearLayout) view.findViewById(R.id.area_service);
        mAreaCallEnge = (LinearLayout) view.findViewById(R.id.area_call);
        mRescueSkill = (LinearLayout) view.findViewById(R.id.area_medical);
        mAreaInfo = (LinearLayout) view.findViewById(R.id.area_info);
        mArea113.setOnClickListener(this);
        mArea114.setOnClickListener(this);
        mArea115.setOnClickListener(this);

        mAreaSupport.setOnClickListener(this);
        mAreaService.setOnClickListener(this);
        mAreaCallEnge.setOnClickListener(this);
        mRescueSkill.setOnClickListener(this);
        mAreaInfo.setOnClickListener(this);
        //
         /*mapFragment = (SupportMapFragment)getChildFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);*/
        mapFrag = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        mapFrag.getMapAsync(this);


    }

    @NonNull
    @Override
    public HomePresenter createPresenter() {
        return new HomePresenter();
    }

    @Override
    public void showMessage(int msgId, boolean success) {

    }

    /*@Override
    public void onPause() {
        super.onPause();

        //stop location updates when Activity is no longer active
        if (mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, (com.google.android.gms.location.LocationListener) getActivity());
        }
    }*/


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.area_call_113:

                sendLocationAndCall(Session.COUNTRY_POLICE_NUMBER,PhoneType.TYPE_POLICE.type());
            break;

            case R.id.area_call_114:
                sendLocationAndCall(Session.COUNTRY_FIRE_NUMBER,PhoneType.TYPE_FIRE.type());
                break;
            case R.id.area_call_115:
                sendLocationAndCall(Session.COUNTRY_AMBULANCE_NUMBER,PhoneType.TYPE_HOSPITAL.type());
                break;
            case R.id.area_support:
                getPresenter().onSupportClicked();
                break;
            case R.id.area_service:
                getPresenter().onServiceClicked();
                break;
            case R.id.top_bar_btnRight:
                getPresenter().onNotifiClicked();
                break;
            case R.id.top_bar_btnLeft:
                getPresenter().onProfileClicked();
                break;
            case R.id.top_bar_btn_push:
                AlertUtil.showPushEmergency(getActivity());
                break;

            case R.id.area_call:
                if(mLastLocation != null){
                    sendLocationAndCall(PrefUtil.getEssentialPhone().emergency,PhoneType.TYPE_EMERGENCY.type());

                }else{
                    Toast.makeText(getActivity() ,"Vui lòng mở GPS" , Toast.LENGTH_LONG).show();
                }

                break;
            case R.id.area_medical:
                getPresenter().onRescueClicked();
                break;
            case R.id.area_info:
                getPresenter().onInfoClicked();
                break;
        }
    }

    private void sendLocationAndCall(String phone,int phone_type){
        getPresenter().onHotLineClicked(phone);
        if(mLastLocation != null){
            getPresenter().onCallEngClicked(mLastLocation.getLatitude(),  mLastLocation.getLongitude() , "Vị trí hiện tại của tôi" , phone_type, phone);
        }else{
            Toast.makeText(getActivity() ,"Vui lòng mở GPS" , Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void showContactInfoPage() {

    }

    @Override
    public void callHotLine(String phone) {
        Intent intent = new Intent(Intent.ACTION_DIAL,
                Uri.parse("tel:" + phone));
        startActivity(intent);
    }

    @Override
    public void callSupport() {
        ((BaseActivity) getActivity()).pushFragment(new ChooseSupportFragment(), true);
    }

    @Override
    public void callService() {
        ((BaseActivity) getActivity()).pushFragment(new ChooseServiceFragment(), true);
    }

    @Override
    public void callNotify() {
        ((BaseActivity) getActivity()).pushFragment(new NotificationFragment(), true);
    }

    @Override
    public void callProfile() {
        ((BaseActivity) getActivity()).pushFragment(new ProfileInfoFragment(), true);
    }

    @Override
    public void showRescueSkill() {
        ((BaseActivity) getActivity()).pushFragment(new RescueSkillFragment(), true);
    }

    @Override
    public void showInfo() {
        ((BaseActivity) getActivity()).pushFragment(new InfoFragment(), true);
    }

    @Override
    public void showUnreadNotifiCount(int count) {
        if(count>0){
            top_bar_tvBadge.setVisibility(View.VISIBLE);
            top_bar_tvBadge.setText(count+"");
        }else{
            top_bar_tvBadge.setVisibility(View.GONE);
        }
    }

    @Override
    public void getCountryCode(String code) {
        Session.COUNTRY_CODE =  code;
    }

    @Override
    public void getPhoneCountry(List<PhoneBookModel> data) {
        if(Session.COUNTRY_CODE!=null || !Session.COUNTRY_CODE.isEmpty()){
            for(PhoneBookModel ob : data){
                if(ob.type == 0){
                    Session.COUNTRY_POLICE_NUMBER = ob.number;
                }
                if(ob.type == 1){
                    Session.COUNTRY_FIRE_NUMBER = ob.number;
                }
                if(ob.type == 2){
                    Session.COUNTRY_AMBULANCE_NUMBER = ob.number;
                }

            }
        }
    }


    @Override
    public void getCountry(List<CountryEmergencyNumber> data) {
        if(Session.COUNTRY_NAME!=null || !Session.COUNTRY_NAME.isEmpty()){
            for(CountryEmergencyNumber ob : data){
                if(Session.COUNTRY_CODE.equalsIgnoreCase(ob.iso2_code)){
//                    getPresenter().onHotLineClicked();
                    if(ob.emergency_numbers.size()>0){
                        for(CountryEmergencyNumber.EmergencyNumber ob_phone: ob.emergency_numbers){
                           if(ob_phone.name.equals("ambulance")){
                               Session.COUNTRY_AMBULANCE_NUMBER = ob_phone.phone;

                           }
                           if(ob_phone.name.equals("police")){
                               Session.COUNTRY_POLICE_NUMBER = ob_phone.phone;
                           }
                           if(ob_phone.name.equalsIgnoreCase("Fire")){
                               Session.COUNTRY_FIRE_NUMBER = ob_phone.phone;
                           }
                        }
                    }
                }
            }
        }
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
       /* googleMap.addMarker(new MarkerOptions()
                .position(new LatLng(37.3092293, -122.1136845))
                .title("Vị trí bạn ở đây"));

        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(37.4233438, -122.0728817), 10));*/
        mGoogleMap=googleMap;
        mGoogleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        //Initialize Google Play Services
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(getActivity(),
                    ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                //Location Permission already granted
                buildGoogleApiClient();
                mGoogleMap.setMyLocationEnabled(true);
            } else {
                //Request Location Permission
                checkLocationPermission();
            }
        }
        else {
            buildGoogleApiClient();
            mGoogleMap.setMyLocationEnabled(true);
        }
    }
    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(getActivity())
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }
    @Override
    public void onLocationChanged(Location location) {
        mLastLocation = location;
        Session.location = location;
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }


        try {
            getPresenter().onGetCurrentCountry();
//            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
//            if(addresses.size()>0){
//                Address obj = addresses.get(0);
//                obj.getCountryCode();
//                if(Session.COUNTRY_NAME.equals("")){
//                    Session.COUNTRY_NAME =  obj.getCountryName();
//                    Session.COUNTRY_CODE =  obj.getCountryCode();
//                }else if(!obj.getCountryName().equals(Session.COUNTRY_NAME)){
//
//                    Session.COUNTRY_NAME =  obj.getCountryName();
//                    Session.COUNTRY_CODE =  obj.getCountryCode();
//                }
//            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        //Place current location marker
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("Vị trí của bạn");
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA));
        mCurrLocationMarker = mGoogleMap.addMarker(markerOptions);
        //googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(37.4233438, -122.0728817), 10));*/
        //move map camera
        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,14));
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(30000);
        mLocationRequest.setFastestInterval(30000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        if (ContextCompat.checkSelfPermission(getActivity(),
                ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest,this);
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(),ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(getActivity())
                        .setTitle("Location Permission Needed")
                        .setMessage("This app needs the Location permission, please accept to use location functionality")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(getActivity(),
                                        new String[]{ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION );
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION );
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(getActivity(),
                           ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mGoogleApiClient == null) {
                            buildGoogleApiClient();
                        }
                        mGoogleMap.setMyLocationEnabled(true);
                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(getActivity(), "permission denied", Toast.LENGTH_LONG).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
}
