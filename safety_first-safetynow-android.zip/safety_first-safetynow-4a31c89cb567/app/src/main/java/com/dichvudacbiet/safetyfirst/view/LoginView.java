package com.dichvudacbiet.safetyfirst.view;

/**
 * Created by ducth on 11/18/16.
 */

public interface LoginView extends BaseView {

    void loginOTP(String phone, String otp);

    void navigateBack();
}
