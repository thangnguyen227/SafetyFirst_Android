package com.dichvudacbiet.safetyfirst.model.network;

public class NetworkRequest {

    public String data;

    private NetworkRequest(Builder builder) {
        data = builder.data;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private String data;

        private Builder() {
        }

        public Builder data(String val) {
            data = val;
            return this;
        }

        public NetworkRequest build() {
            return new NetworkRequest(this);
        }
    }
}