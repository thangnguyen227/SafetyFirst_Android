package com.dichvudacbiet.safetyfirst.model.network;

/**
 * Created by khant on 15/05/2018.
 */

public class UnreadNotificationCountRequest {
    public int status;
    public Number data;
    public class Number{
        public int number;
    }
}
