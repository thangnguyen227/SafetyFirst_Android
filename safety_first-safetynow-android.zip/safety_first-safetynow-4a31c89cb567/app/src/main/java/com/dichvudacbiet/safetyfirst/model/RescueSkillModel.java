package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 12/18/17.
 */

public class RescueSkillModel {
    public String name;
    public int id;
    public String content;
    private RescueSkillModel(){

    }
    public static RescueSkillModel skillName(String data){
        RescueSkillModel ob = new RescueSkillModel();
        ob.name = data;
        return ob;
    }
}
