
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.MedicalModel;

import java.util.List;

public interface MedicalDetailView extends BaseView {
    void navigateBack();
    void setData(MedicalModel data);
    void setCallPhone(MedicalModel callPhone);
    void setDirection(MedicalModel callPhone);
}
