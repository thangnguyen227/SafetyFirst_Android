package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 01/04/18.
 */

public class PhoneBookModel {
    public int id;
    public LocationModel location;
    public int type;
    public String number;
    public String updated_at;
    public String created_at;



}
