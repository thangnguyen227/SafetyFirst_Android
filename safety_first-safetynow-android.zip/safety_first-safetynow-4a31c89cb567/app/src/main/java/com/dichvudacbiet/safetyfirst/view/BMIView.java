
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.BMIModel;
import com.dichvudacbiet.safetyfirst.model.SosModel;

import java.util.List;

public interface BMIView extends BaseView {
    void navigateBack();
    void setData(List<BMIModel> listNews);
}
