
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.adapter.QuestionAdapter;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.adapter.RelationAdapter;
import com.dichvudacbiet.safetyfirst.model.EssentialPhone;
import com.dichvudacbiet.safetyfirst.model.JobModel;
import com.dichvudacbiet.safetyfirst.model.QuestionModel;
import com.dichvudacbiet.safetyfirst.model.Relation2Model;
import com.dichvudacbiet.safetyfirst.model.RelationModel;
import com.dichvudacbiet.safetyfirst.presenter.ProfileEditPresenter;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.ProfileEditView;

import java.util.ArrayList;
import java.util.List;


public class ProfileEditFragment extends BaseFragment<ProfileEditView, ProfileEditPresenter> implements
        ProfileEditView, View.OnClickListener, RecyclerViewOnItemClickedListener<RelationModel> {

    private static final String ARG_JOB_TAB_TYPE = "job_tab_type";
    private ProfileInfoFragment.PromotionTabType jobTabType;
    private RecyclerView rvList_trip, rvList_health, rvList_vaccin, rc_relation;
    //private PromotionAdapter adapter;

    protected String title;

    // edit profile
    private TextInputLayout inputLayoutName;
    private TextInputLayout inputLayoutAddress;
    private TextInputLayout inputLayoutMobilePhone;
    private TextInputLayout inputLayoutPhone;
    private TextInputLayout inputLayoutJob;
    private TextView tv_power;

    private EditText edit_emergency;

    private Spinner spn_relation;

    private LinearLayout mAreaProfile, mAreaRelation, getmAreaGuarantee;
    private RelationAdapter relationAdapter;
    private RelativeLayout rl_areaRelation;
    private ArrayList<Integer> job_id_list;

    // relation area
    private ArrayList<RelationModel> relationModels = new ArrayList<>();
    private Spinner mSpContact, sp_job;
    private TextInputLayout inputLayoutNameRelation;
    private TextInputLayout inputLayoutMobilePhoneRelation;
    private TextInputLayout inputLayoutPhoneRelation;
    private LinearLayout area_create_relations;
    private int mIdRelation = 1;
    private String relation_type;

    private SetAgainRelation mSetAgainRelationListener;
    int job_id;
    private QuestionAdapter adapter;
    private ArrayList<QuestionModel> questionsList = new ArrayList<>();
    private RecyclerView rvList;
    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_profile_edit;
    }

    public static ProfileEditFragment newInstance(ProfileInfoFragment.PromotionTabType jobTabType) {
        Bundle args = new Bundle();
        args.putString(ARG_JOB_TAB_TYPE, jobTabType.name());

        ProfileEditFragment fragment = new ProfileEditFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            jobTabType = ProfileInfoFragment.PromotionTabType
                    .valueOf(getArguments().getString(ARG_JOB_TAB_TYPE));
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAreaProfile = (LinearLayout) view.findViewById(R.id.area_register);
        getmAreaGuarantee = (LinearLayout) view.findViewById(R.id.ll_areaEmergency);
        rl_areaRelation = (RelativeLayout) view.findViewById(R.id.rl_areaRelation);

        //Info
        inputLayoutName = view.findViewById(R.id.register_inputLayoutName);
        inputLayoutAddress = view.findViewById(R.id.register_inputLayoutAddress);
        inputLayoutPhone = view.findViewById(R.id.register_inputLayoutPhone);
        inputLayoutMobilePhone = view.findViewById(R.id.register_inputLayoutPhonemobile);
        inputLayoutJob = view.findViewById(R.id.register_inputLayoutjob);
        sp_job = view.findViewById(R.id.sp_job);
        tv_power = view.findViewById(R.id.tv_power);

        // Guarantees Emergency
        edit_emergency = (EditText) view.findViewById(R.id.edit_emergency);



        // Relation
//        spn_relation =  view.findViewById(R.id.spn_relation);
        mAreaRelation = (LinearLayout) view.findViewById(R.id.ll_areaRelation);
        relationAdapter = new RelationAdapter(getContext());
        mSetAgainRelationListener = relationAdapter;
        rc_relation = view.findViewById(R.id.rc_relation);
        rc_relation.setNestedScrollingEnabled(false);
        rc_relation.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rc_relation.setAdapter(relationAdapter);

        // Create Relation Area
        area_create_relations = view.findViewById(R.id.area_create_relations);
        inputLayoutNameRelation = view.findViewById(R.id.relation_inputLayoutName);
        inputLayoutMobilePhoneRelation = view.findViewById(R.id.relation_inputLayoutPhone);
        inputLayoutPhoneRelation = view.findViewById(R.id.relation_inputLayoutPhonemobile);
        mSpContact = view.findViewById(R.id.sp_contact);
        Button mAddNew = (Button) view.findViewById(R.id.add_info);
        mAddNew.setOnClickListener(this);

        //listener
        Button btnRegister = (Button) view.findViewById(R.id.register_btnRegister);
        btnRegister.setOnClickListener(this);

        Button btnGuarantee = (Button) view.findViewById(R.id.btnUpdate_Guarantee);
        btnGuarantee.setOnClickListener(this);

        Button btnRelation = (Button) view.findViewById(R.id.btnUpdate_relation);
        btnRelation.setOnClickListener(this);

        Button btnCreateRelation = (Button) view.findViewById(R.id.btn_createRelation);
        btnCreateRelation.setOnClickListener(this);

        /**/
        adapter = new QuestionAdapter(getActivity());
        rvList = (RecyclerView) view.findViewById(R.id.rvListQuestions);

    }


    @Override
    public ProfileEditPresenter createPresenter() {
        return new ProfileEditPresenter(jobTabType);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.register_btnRegister:
                String name = Util.safelyGetTextFromEditText(inputLayoutName.getEditText());
                String address = Util.safelyGetTextFromEditText(inputLayoutAddress.getEditText());
                String phone = Util.safelyGetTextFromEditText(inputLayoutPhone.getEditText());
                String mobile = Util.safelyGetTextFromEditText(inputLayoutMobilePhone.getEditText());
                String job = Util.safelyGetTextFromEditText(inputLayoutJob.getEditText());
                job_id = job_id_list.get(sp_job.getSelectedItemPosition());

                Session.userInfo.getType_id();
                getPresenter().onUpdateInfo(name, address, phone, mobile, job_id, Session.userInfo.relations);
                break;

            case R.id.btnUpdate_Guarantee:
                String emergency = edit_emergency.getText().toString();

                getPresenter().onUpdateGuaranteePhone(new EssentialPhone(emergency,"","",""));
                Toast.makeText(getActivity(), "Cập nhật thành công!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btnUpdate_relation:
                getPresenter().onUpdateInfo(Session.userInfo.fullname, Session.userInfo.living_location.fullname, Session.userInfo.phone_number,
                        Session.userInfo.mobile_number, PrefUtil.getUserInfo().job.id, Session.userInfo.relations);
                break;

            case R.id.btn_createRelation:
                mAreaRelation.setVisibility(View.GONE);
                area_create_relations.setVisibility(View.VISIBLE);
                Session.userInfo = PrefUtil.getUserInfo();
                Session.userInfo.getType_id();
                getPresenter().loadRelation(2);
                break;

            case R.id.add_info:
                addInfoContact();
                break;

        }
    }

    @Override
    public void displayProfile() {
        getmAreaGuarantee.setVisibility(View.GONE);
        rl_areaRelation.setVisibility(View.GONE);
        mAreaProfile.setVisibility(View.VISIBLE);
        inputLayoutName.getEditText().setText(PrefUtil.getUserInfo().fullname);
        inputLayoutAddress.getEditText().setText(PrefUtil.getUserInfo().living_location.fullname);
        inputLayoutPhone.getEditText().setText(PrefUtil.getUserInfo().phone_number);
        inputLayoutMobilePhone.getEditText().setText(PrefUtil.getUserInfo().mobile_number);
        inputLayoutJob.getEditText().setText(PrefUtil.getUserInfo().job.name);

        String role;
        if (PrefUtil.getUserInfo().role == 0) {
            role = "User";
        } else {
            role = "Admin";
        }
        tv_power.setText(role);

    }

    @Override
    public void displayGuarantee() {
        getmAreaGuarantee.setVisibility(View.VISIBLE);
        mAreaProfile.setVisibility(View.GONE);
        rl_areaRelation.setVisibility(View.GONE);
        edit_emergency.setText(PrefUtil.getEssentialPhone().emergency);
    }

    public interface SetAgainRelation {
        void onSetAgainRelation();
    }

    @Override
    public void displayRelations(List<RelationModel> relations) {
        getmAreaGuarantee.setVisibility(View.GONE);
        mAreaProfile.setVisibility(View.GONE);
        rl_areaRelation.setVisibility(View.VISIBLE);
        mAreaRelation.setVisibility(View.VISIBLE);
        area_create_relations.setVisibility(View.GONE);
        relationAdapter.setListNews(relations);
        relationAdapter.notifyDataSetChanged();
    }


    @Override
    public void showRelation(ArrayList<Relation2Model> relation2Models, int type) {
        if (type == 1) {
            relationAdapter.setRelation2List(relation2Models);
            relationAdapter.notifyDataSetChanged();
        } else {
            ArrayList<String> mList = new ArrayList<String>();
            for (int i = 0; i < relation2Models.size(); i++) {
                mList.add(relation2Models.get(i).name);
            }
            ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                    getActivity(), android.R.layout.simple_spinner_item, mList);
            spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            mSpContact.setAdapter(spinnerArrayAdapter);
            mSpContact.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mIdRelation   =   relation2Models.get(position).id;
                    relation_type =   relation2Models.get(position).name;
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }


    }

    @Override
    public void showJobs(ArrayList<JobModel> jobs) {
        ArrayList<String> mList = new ArrayList<String>();
        job_id_list = new ArrayList<>();
        for (int i = 0; i < jobs.size(); i++) {
            mList.add(jobs.get(i).name);
            job_id_list.add(jobs.get(i).id);
        }
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, mList);
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_job.setAdapter(spinnerArrayAdapter);
        sp_job.setSelection(getIndexSpiner(sp_job, PrefUtil.getUserInfo().job.name));
        sp_job.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                PrefUtil.getUserInfo().job.id = job_id_list.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void addInfoContact() {
        String relationName = Util.safelyGetTextFromEditText(inputLayoutNameRelation.getEditText());
        String relationPhone = Util.safelyGetTextFromEditText(inputLayoutPhoneRelation.getEditText());
        String relationMobile = Util.safelyGetTextFromEditText(inputLayoutMobilePhoneRelation.getEditText());
        // String relation = Util.safelyGetTextFromEditText(inputLayoutRelation.getEditText());
        int errMsg = Util.validateInput(relationName, relationMobile);
        if (errMsg != -1) {
            showMessage(errMsg, false);
            return;
        }
        RelationModel relationModel = new RelationModel();
        relationModel.fullname = relationName;
        relationModel.phone_number = relationPhone;
        relationModel.mobile_number = relationMobile;
        relationModel.relation_type = relation_type;
        relationModel.type_id = mIdRelation;
        Session.userInfo.relations.add(relationModel);
        getPresenter().onUpdateInfo(Session.userInfo.fullname, Session.userInfo.living_location.fullname, Session.userInfo.phone_number,
                Session.userInfo.mobile_number, PrefUtil.getUserInfo().job.id, Session.userInfo.relations);

    }

    @Override
    public void showRelationAfterCreate() {
        mAreaRelation.setVisibility(View.VISIBLE);
        area_create_relations.setVisibility(View.VISIBLE);
        relationAdapter.setListNews(Session.userInfo.relations);
        relationAdapter.notifyDataSetChanged();
        mSetAgainRelationListener.onSetAgainRelation();
    }

    @Override
    public void showListQuestions(ArrayList<QuestionModel> questionModels) {
        questionsList =  questionModels;
        adapter.setListNews(questionModels);
        adapter.notifyDataSetChanged();
        rvList.setAdapter(adapter);
    }


    private int getIndexSpiner(Spinner spinner, String myString) {

        int index = 0;

        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).equals(myString)) {
                index = i;
            }
        }
        return index;
    }


    @Override
    public void createRelations() {

    }


    @Override
    public void onItemClicked(RecyclerView recyclerView, RelationModel scheduleModel, int position) {
//        ((BaseActivity) getActivity()).pushFragment(new CreateVaccinScheduleFragment(Session.vaccinModel.vaccination_info), true);
    }

}
