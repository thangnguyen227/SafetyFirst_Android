
package com.dichvudacbiet.safetyfirst.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.adapter.VaccinAdapter;
import com.dichvudacbiet.safetyfirst.model.VaccinInfoModel;
import com.dichvudacbiet.safetyfirst.presenter.CreateVaccinSchedulePresenter;
import com.dichvudacbiet.safetyfirst.view.CreateVaccinScheduleView;

import java.util.List;


@SuppressLint("ValidFragment")
public class CreateVaccinScheduleFragment extends BaseFragment<CreateVaccinScheduleView, CreateVaccinSchedulePresenter>
        implements CreateVaccinScheduleView, View.OnClickListener , RecyclerViewOnItemClickedListener<VaccinInfoModel> {

    private ExpandableListView rvList;
    private VaccinAdapter adapter;
    private TextView mToolbarTitle;
    private Button btn_createVaccin;
    private List<VaccinInfoModel> vaccinList;
    List<VaccinInfoModel> vaccinInfoModels;
    View anchorView;
    @SuppressLint("ValidFragment")
    public CreateVaccinScheduleFragment(List<VaccinInfoModel> list){
        vaccinInfoModels = list;
    }

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_create_vaccin_schedule;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);
        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.create_vaccin_schedule));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //
        rvList =  view.findViewById(R.id.rvList);
        //
        btn_createVaccin = view.findViewById(R.id.btn_createVaccin);
        btn_createVaccin.setOnClickListener(this);

    }

    @NonNull
    @Override
    public CreateVaccinSchedulePresenter createPresenter() {
        return new CreateVaccinSchedulePresenter(vaccinInfoModels);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
            case R.id.btn_createVaccin:
                getPresenter().updateVaccinInfo(vaccinList);
                break;
        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }


    @Override
    public void showMessage(String message, boolean success) {
        super.showMessage(message, success);
    }

    @Override
    public void setData(List<VaccinInfoModel> listNews) {
        if(listNews!=null){
            vaccinList = listNews;
            adapter = new VaccinAdapter(getContext());
            adapter.setOnItemClickListener(this);
            adapter.setListNews(listNews);
            adapter.notifyDataSetChanged();
            rvList.setAdapter(adapter);
        }

    }


    @Override
    public void onItemClicked(RecyclerView recyclerView, VaccinInfoModel vaccinModel, int position) {

    }

}
