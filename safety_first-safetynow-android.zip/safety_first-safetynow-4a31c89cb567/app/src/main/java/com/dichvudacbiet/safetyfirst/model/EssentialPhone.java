package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by khant on 16/03/2018.
 */

public class EssentialPhone {
    public String emergency;
    public String hospital;
    public String fire;
    public String police;

    public EssentialPhone(String emergency, String hospital, String fire, String police) {
        this.emergency = emergency;
        this.hospital = hospital;
        this.fire = fire;
        this.police = police;
    }
}
