
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.NotificationModel;

import java.util.List;

public interface NotificationView extends BaseView {
    void navigateBack();
    void setData(List<NotificationModel> listNews);
    void showDetail(NotificationModel notificationModel);
}
