package com.dichvudacbiet.safetyfirst.model;

import java.util.ArrayList;

/**
 * Created by loi.doan on 01/04/18.
 */

public class LocationModel {
    public int id;
    public LocationModel parent;
    public  String name;
    public String fullname;
    public  String code;
    public int safety_rating;
    public int level;
    public String updated_at;
    public String created_at;
    public String countryCode;


    @Override
    public String toString() {
        return "LocationModel{" +
                "id=" + id +
                ", parent=" + parent +
                ", name='" + name + '\'' +
                ", full_name='" + fullname + '\'' +
                ", code='" + code + '\'' +
                ", safety_rating=" + safety_rating +
                ", level=" + level +
                ", updated_at='" + updated_at + '\'' +
                ", created_at='" + created_at + '\'' +
                '}';
    }
}
