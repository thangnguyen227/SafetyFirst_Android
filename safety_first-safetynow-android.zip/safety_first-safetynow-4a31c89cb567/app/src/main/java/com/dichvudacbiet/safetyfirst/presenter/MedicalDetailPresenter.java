
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.model.MedicalModel;
import com.dichvudacbiet.safetyfirst.model.network.MedicalRequest;
import com.dichvudacbiet.safetyfirst.model.network.SupportRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.view.MedicalDetailView;
import com.dichvudacbiet.safetyfirst.view.MedicalListView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MedicalDetailPresenter extends BasePresenter<MedicalDetailView> {
    private MedicalModel medicalModel;
    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }
    public MedicalDetailPresenter(MedicalModel medicalModel) {
        this.medicalModel = medicalModel;
    }
    private void loadData() {
        if (isViewAttached()) {
            getView().setData(medicalModel);
        }
    }

    public void onCallClicked() {
        if (isViewAttached()) {
            getView().setCallPhone(medicalModel);
        }
    }

    public void onDirectionClicked() {
        if (isViewAttached()) {
            getView().setDirection(medicalModel);
        }
    }

    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
