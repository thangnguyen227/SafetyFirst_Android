package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 01/02/18.
 */

public class JobModel {
    public int id;
    public String name;
}
