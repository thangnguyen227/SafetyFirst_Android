package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;

import java.util.ArrayList;

/**
 * Created by khant on 11/03/2018.
 */

public class HealthCareActivateTitleRequest {
    public int status;
    public ArrayList<HealthCareActivateModel> data;
}
