
package com.dichvudacbiet.safetyfirst.adapter;

import android.app.DatePickerDialog;
import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.VaccinInfoModel;
import com.dichvudacbiet.safetyfirst.model.VaccinListScheduleModel;
import com.dichvudacbiet.safetyfirst.model.VaccinModel;
import com.dichvudacbiet.safetyfirst.util.AlertUtil;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;


public class VaccinAdapter extends BaseExpandableListAdapter
        implements View.OnClickListener {




    private List<VaccinInfoModel> vaccinList;

    private RecyclerView rvList;
    protected RecyclerViewOnItemClickedListener<VaccinInfoModel> listener;
    private Context mContext;
    private Calendar myCalendar;
    private DatePickerDialog.OnDateSetListener date;



    public VaccinAdapter(Context context ){
        mContext = context;
    }
    public void setListNews(List<VaccinInfoModel> listNews) {
        this.vaccinList = listNews;
        Log.d("//////",vaccinList.size()+"");
    }

    public List<VaccinInfoModel> getListNews() {
        return vaccinList;
    }

    public void setOnItemClickListener(RecyclerViewOnItemClickedListener<VaccinInfoModel> listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        View containingView = rvList.findContainingItemView(v);
        int position = rvList.getChildAdapterPosition(containingView);
        if (position == RecyclerView.NO_POSITION) {
            return;
        }

        if (listener != null) {
            listener.onItemClicked(rvList, vaccinList.get(position), position);
        }
    }

    @Override
    public int getGroupCount() {
        return this.vaccinList.size();
    }

    @Override
    public int getChildrenCount(int i) {
        return this.vaccinList.get(i).times
                .size();
    }

    @Override
    public Object getGroup(int i) {
        return this.vaccinList.get(i);
    }

    @Override
    public Object getChild(int i, int i1) {
        return this.vaccinList.get(i).times
                .get(i1);
    }

    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int i, boolean b, View view, ViewGroup viewGroup) {
        final String headerText = ((VaccinInfoModel) getGroup(i)).name;
        if (view == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = infalInflater.inflate(R.layout.item_header_vaccin, null);
        }

        ParentViewHolder viewHolder = new ParentViewHolder(view);
        viewHolder.mName.setText(headerText);
//        viewHolder.cb_choose.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
//        {
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
//            {
//                if ( isChecked )
//                    vaccinList.get(i).isChoose = true;
//                else
//                    vaccinList.get(i).isChoose = false;
//
//            }
//        });
        view.setTag(viewHolder);
        return view;
    }

    @Override
    public View getChildView(int i, int i1, boolean isLastChild, View view, ViewGroup viewGroup) {
        final String date_time = ((VaccinInfoModel.Times)getChild(i, i1)).time;
        final String name = ((VaccinInfoModel.Times)getChild(i, i1)).name;
        if (view == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = infalInflater.inflate(R.layout.item_child_schedule_vaccin, null);
        }
        ChildViewHolder viewHolder = new ChildViewHolder(view);
        viewHolder.mName.setText( name);
        viewHolder.mDate.setText(date_time);
        viewHolder.mDate.setOnClickListener(v ->{
            AlertUtil.showDateTimePickerDialog((((FragmentActivity) mContext).getSupportFragmentManager()),viewHolder.mDate,false);
        });
        viewHolder.mDate.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String text = editable.toString();
                vaccinList.get(i).times.get(i1).time = text;
                //save the value for the given tag :
            }
        });
        view.setTag(viewHolder);
        return view;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }

    public class ChildViewHolder{
        public TextView mName,mDate;
        public CheckBox cb_isDone;
        public ChildViewHolder(View view) {
            mName = view.findViewById(R.id.tv_name_vaccin);
            mDate = view.findViewById(R.id.edt_date_time);
            cb_isDone = view.findViewById(R.id.cb_isDone);
        }

    }


    public class ParentViewHolder{
        public TextView mName;
        public ParentViewHolder(View view) {
            mName = view.findViewById(R.id.txt_head);
        }

    }


    TextView tvTemp;

//    public void onBindViewHolder(MyViewHolder holder, int position) {
//        VaccinModel vaccinModel = vaccinList.get(position);
//        holder.mName.setText(vaccinModel.name);
//        holder.mLocation.setText(vaccinModel.location);
//        holder.mInfo.setText(vaccinModel.info);
//        holder.mDate.setText(vaccinModel.date_time);
//        holder.mDate.setOnClickListener(v->{
//            tvTemp = holder.mDate;
//            AlertUtil.showDatePickerDialog(mContext,tvTemp);
//        });
//        myCalendar = Calendar.getInstance();
//        date = (v,  year,  monthOfYear, dayOfMonth) -> {
//            // TODO Auto-generated method stub
//            myCalendar.set(Calendar.YEAR, year);
//            myCalendar.set(Calendar.MONTH, monthOfYear);
//            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
//            if(tvTemp!=null)
//            updateLabel(tvTemp);
//        };
//
//
//    }





    private void updateLabel(TextView mDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm", Locale.US);
        mDate.setText(sdf.format(myCalendar.getTime()));
    }


    //Adapter


}

