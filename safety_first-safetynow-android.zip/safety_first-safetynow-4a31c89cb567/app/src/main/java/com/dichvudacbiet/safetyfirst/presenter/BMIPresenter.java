
package com.dichvudacbiet.safetyfirst.presenter;

import android.util.Log;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.base.SafetyApplication;
import com.dichvudacbiet.safetyfirst.model.BMIModel;
import com.dichvudacbiet.safetyfirst.model.SosModel;
import com.dichvudacbiet.safetyfirst.model.SupportModel;
import com.dichvudacbiet.safetyfirst.model.network.SosRequest;
import com.dichvudacbiet.safetyfirst.model.network.SosRequestList;
import com.dichvudacbiet.safetyfirst.model.network.SosRequestPost;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.view.BMIView;
import com.dichvudacbiet.safetyfirst.view.SosView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class BMIPresenter extends BasePresenter<BMIView> {

    private List<SupportModel> supportModelList = new ArrayList<>();
    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            ArrayList<BMIModel> datas = new ArrayList<>();
            datas.add(new BMIModel(SafetyApplication.self().getString(R.string.adult)));
            datas.add(new BMIModel(SafetyApplication.self().getString(R.string.children)));
            datas.add(new BMIModel(SafetyApplication.self().getString(R.string.calculate_your_BMI)));
            getView().setData(datas);
        }
    }



    public void onSendSosMessage(int id, double lat, double lng) {
        if (isViewAttached()) {
            if (isViewAttached()) {
                if (isViewAttached()) {
                    Object mData = new SosRequestPost(id,lat,lng);
                    Call<SosRequest> call = ApiService.getClient().postSOSMessageList(PrefUtil.getTokenInfo(),mData);
                    call.enqueue(new Callback<SosRequest>() {
                        @Override
                        public void onResponse(Call<SosRequest> call, Response<SosRequest> response) {

                            if (response.isSuccessful()) {
                                if(response.body().status == 1){
                                    getView().showMessage("Gửi thông tin thành công", false);
                                }
                            }else{
                                getView().showMessage("Lỗi tạo kết nối", false);
                            }
                        }
                        @Override
                        public void onFailure(Call<SosRequest> call, Throwable t) {

                            getView().showMessage("Lỗi tạo kết nối ", false);
                        }
                    });
                }
            }
        }
    }



    public void onNewsClicked(double lat, double lng, BMIModel sos) {
        if (isViewAttached()) {
//            onSendSosMessage(sos.id,lat,lng);
        }
    }
    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
