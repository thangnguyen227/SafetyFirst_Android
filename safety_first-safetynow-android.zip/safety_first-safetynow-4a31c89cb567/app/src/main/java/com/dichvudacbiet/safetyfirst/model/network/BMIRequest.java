package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.BMIModel;
import com.dichvudacbiet.safetyfirst.model.VaccinModel;

import java.util.ArrayList;

/**
 * Created by loi.doan on 12/18/17.
 */

public class BMIRequest {
    public int status;
    public BMIModel data;
}
