
package com.dichvudacbiet.safetyfirst.activity;

import android.os.Bundle;
import android.support.annotation.NonNull;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.base.Constants;
import com.dichvudacbiet.safetyfirst.fragment.ChooseLangugeFragment;
import com.dichvudacbiet.safetyfirst.presenter.LoginActivityPresenter;
import com.dichvudacbiet.safetyfirst.view.LoginActivityView;


public class LoginActivity extends BaseActivity<LoginActivityView, LoginActivityPresenter>
        implements LoginActivityView{

    @NonNull
    @Override
    public LoginActivityPresenter createPresenter() {
        return new LoginActivityPresenter();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        pushFragment(new ChooseLangugeFragment(), Constants.TransitionType.NONE, true);
    }
    @Override
    public void onNewViewStateInstance() {

    }

    @Override
    public void loginPhone(String phone, String opt) {

    }


    @Override
    public void showMessage(int msgId, boolean success) {

    }

    @Override
    public void showMessage(String message, boolean success) {

    }
}
