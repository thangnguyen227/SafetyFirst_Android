
package com.dichvudacbiet.safetyfirst.presenter;



import com.dichvudacbiet.safetyfirst.model.UserInfo;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.view.LoginActivityView;


public class LoginActivityPresenter extends BasePresenter<LoginActivityView> {

    @Override
    public void onNewViewStateInstance() {
    }
}
