package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;

import java.util.ArrayList;

public class HealthCareActivateRequest {
    public int status;
    public HealthCareActivateModel data;

}
