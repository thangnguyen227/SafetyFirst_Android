package com.dichvudacbiet.safetyfirst.model;

public class Answer{
        public int question_id ;
        public String text;

}