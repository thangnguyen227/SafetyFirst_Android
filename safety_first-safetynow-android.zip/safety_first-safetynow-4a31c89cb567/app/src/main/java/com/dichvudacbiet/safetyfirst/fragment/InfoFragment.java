
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.adapter.ServiceAdapter;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.SupportModel;
import com.dichvudacbiet.safetyfirst.presenter.InfoPresenter;
import com.dichvudacbiet.safetyfirst.view.InfoView;

import java.util.ArrayList;
import java.util.List;


public class InfoFragment extends BaseFragment<InfoView, InfoPresenter>
        implements InfoView, View.OnClickListener, RecyclerViewOnItemClickedListener<SupportModel> {

    private RecyclerView rvList;
    private ServiceAdapter adapter;

    private TextView mToolbarTitle;

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_info;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);

        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.information_about_safety));
        mToolbarTitle.setVisibility(View.VISIBLE);
    }

    @Override
    public InfoPresenter createPresenter() {
        return new InfoPresenter();
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
        }
    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, SupportModel supportModel, int position) {

    }

    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void showNational(int pos) {

    }

    @Override
    public void setData(List<SupportModel> listNews) {

    }

    @Override
    public void setCountryData(ArrayList<LocationModel> listNews) {

    }

    @Override
    public void setProvinceData(ArrayList<LocationModel> listNews) {

    }

    @Override
    public void showCoveringList(ArrayList<LocationModel> listNews) {

    }

    @Override
    public void navigateToBMI() {

    }

    @Override
    public void showSOS() {

    }
}
