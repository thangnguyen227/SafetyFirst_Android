
package com.dichvudacbiet.safetyfirst.util;

import android.content.Context;
import android.content.SharedPreferences;

import com.dichvudacbiet.safetyfirst.base.SafetyApplication;
import com.dichvudacbiet.safetyfirst.model.DeviceInfo;
import com.dichvudacbiet.safetyfirst.model.EssentialPhone;
import com.dichvudacbiet.safetyfirst.model.UserInfo;

import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class PrefUtil {

    private static final String PREFERENCE_NAME = "Zacs-Pref";

    private static final String KEY_DEVICE_INFO = "1";
    private static final String KEY_USER_INFO = "2";
    private static final String KEY_TOKEN_INFO = "3";

    private static final String KEY_JOB_ID = "3";

    private static final String KEY_ESSENTIAL_PHONE= "Phone_Essential";


    private static final String PREFS_NAME = "multi_language_active";
    public static final String LANGUAGE = "langauge";

    private static SharedPreferences pref = null;


    public static void init(Context context) {
        pref = context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE);
    }

    public static void setDeviceInfo(DeviceInfo deviceInfo) {
        setString(KEY_DEVICE_INFO, SafetyApplication.GSON.toJson(deviceInfo));
    }

    public static DeviceInfo getDeviceInfo() {
        String json = getString(KEY_DEVICE_INFO, "");
        return SafetyApplication.GSON.fromJson(json, DeviceInfo.class);
    }

    public static void setUserInfo(UserInfo userInfo) {
        setString(KEY_USER_INFO, SafetyApplication.GSON.toJson(userInfo));
    }

    public static UserInfo getUserInfo() {
        String json = getString(KEY_USER_INFO, "");
        return SafetyApplication.GSON.fromJson(json, UserInfo.class);
    }

    public static void setEssentialPhone(EssentialPhone essential) {
        setString(KEY_ESSENTIAL_PHONE, SafetyApplication.GSON.toJson(essential));
    }

    public static EssentialPhone getEssentialPhone() {
        String json = getString(KEY_ESSENTIAL_PHONE, "");
        return SafetyApplication.GSON.fromJson(json, EssentialPhone.class);
    }

    public static void setTokenInfo(String  token) {
        setString(KEY_TOKEN_INFO, token);
    }

    public static String getTokenInfo() {
        String json = getString(KEY_TOKEN_INFO, "");
        return json;
    }

    public static void setJobId(String jobId) {
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(KEY_JOB_ID, jobId);
        editor.commit();
    }

    public static String getJobId() {
        return pref.getString(KEY_JOB_ID, "");
    }






//    public static void setEssentialNumsPhone(List<String> nums){
//        setStringSet(KEY_ESSEN_NUMS,nums);
//    }
//
//    public static List<String> getEssentialNumsPhone(){
//        List<String> nums = new ArrayList<>();
//        nums.addAll(pref.getStringSet(KEY_ESSEN_NUMS,new HashSet<>()));
//        return nums;
//    }

    private static void setString(String key, String value) {
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, value);
        editor.commit();
    }

    private static void setStringSet(String key, List<String> listQuest){
        Set<String> set = new HashSet<String>();
        set.addAll(listQuest);
        SharedPreferences.Editor editor = pref.edit();
        editor.putStringSet(key, set);
        editor.commit();
    }

    private static String getString(String key, String defaultValue) {
        return pref.getString(key, defaultValue);
    }

    private static void setBoolean(String key, boolean value) {
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }

    private static boolean getBoolean(String key, boolean defaultValue) {
        return pref.getBoolean(key, defaultValue);
    }

    private static void setInt(String key, int value) {
        SharedPreferences.Editor editor = pref.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    private static int getInt(String key, int defaultValue) {
        return pref.getInt(key, defaultValue);
    }


    @SuppressWarnings("unchecked")
    public static <T> T get(String key, Class<T> anonymousClass) {
        if (anonymousClass == String.class) {
            return (T) pref.getString(key, "");
        } else if (anonymousClass == Boolean.class) {
            return (T) Boolean.valueOf(pref.getBoolean(key, false));
        } else if (anonymousClass == Float.class) {
            return (T) Float.valueOf(pref.getFloat(key, 0));
        } else if (anonymousClass == Integer.class) {
            return (T) Integer.valueOf(pref.getInt(key, 0));
        } else if (anonymousClass == Long.class) {
            return (T) Long.valueOf(pref.getLong(key, 0));
        } else {
            return (T) SafetyApplication.GSON
                    .fromJson(pref.getString(key, ""), anonymousClass);
        }
    }

    public static <T> void put(String key, T data) {
        SharedPreferences.Editor editor = pref.edit();
        if (data instanceof String) {
            editor.putString(key, (String) data);
        } else if (data instanceof Boolean) {
            editor.putBoolean(key, (Boolean) data);
        } else if (data instanceof Float) {
            editor.putFloat(key, (Float) data);
        } else if (data instanceof Integer) {
            editor.putInt(key, (Integer) data);
        } else if (data instanceof Long) {
            editor.putLong(key, (Long) data);
        } else {
            editor.putString(key, SafetyApplication.GSON.toJson(data));
        }
        editor.apply();
    }
}
