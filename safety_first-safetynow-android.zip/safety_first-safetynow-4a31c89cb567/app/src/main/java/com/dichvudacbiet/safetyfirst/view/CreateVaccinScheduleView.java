
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.VaccinInfoModel;

import java.util.List;

public interface CreateVaccinScheduleView extends BaseView {
    void navigateBack();
    void setData(List<VaccinInfoModel> listNews);
}
