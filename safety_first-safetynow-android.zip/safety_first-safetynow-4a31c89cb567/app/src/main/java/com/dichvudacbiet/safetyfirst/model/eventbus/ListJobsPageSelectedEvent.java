package com.dichvudacbiet.safetyfirst.model.eventbus;

public class ListJobsPageSelectedEvent {

    public int tabIndex;

    public ListJobsPageSelectedEvent(int tabIndex) {
        this.tabIndex = tabIndex;
    }
}
