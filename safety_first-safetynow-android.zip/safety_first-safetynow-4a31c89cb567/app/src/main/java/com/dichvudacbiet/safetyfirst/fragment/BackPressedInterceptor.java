package com.dichvudacbiet.safetyfirst.fragment;

public interface BackPressedInterceptor {
    boolean onBackPressed();
}
