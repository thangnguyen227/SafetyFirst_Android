package com.dichvudacbiet.safetyfirst.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.CountryModel;
import com.dichvudacbiet.safetyfirst.model.LocationModel;

import java.util.ArrayList;

/**
 * Created by khant on 27/03/2018.
 */

public class CountrySpinnerAdapter  extends BaseAdapter {
    Context context;
    LayoutInflater inflter;
    ArrayList<LocationModel> listCountries = new ArrayList<>();

    public CountrySpinnerAdapter(Context applicationContext ) {
        this.context = applicationContext;
        inflter = (LayoutInflater.from(applicationContext));
    }

    public void setNewList(ArrayList<LocationModel> country_adapter){
        this.listCountries.clear();
        this.listCountries.addAll(country_adapter);
    }

    @Override
    public int getCount() {
        return listCountries.size();
    }

    @Override
    public LocationModel getItem(int i) {
        return listCountries.get(i);
    }

    @Override
    public long getItemId(int i) {
        return listCountries.get(i).id;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.spinner_item_country, null);
        ImageView icon = (ImageView) view.findViewById(R.id.img_safe);
        TextView names = (TextView) view.findViewById(R.id.tv_name);

        if (listCountries.get(i).safety_rating == 1) {
            GradientDrawable bgShape = (GradientDrawable)icon.getBackground();
            bgShape.setColor(Color.GREEN);
        } else if(listCountries.get(i).safety_rating == 2) {
            GradientDrawable bgShape = (GradientDrawable)icon.getBackground();
            bgShape.setColor(Color.YELLOW);
        } else if(listCountries.get(i).safety_rating == 3) {
            GradientDrawable bgShape = (GradientDrawable)icon.getBackground();
            bgShape.setColor(Color.parseColor("#FFA500"));
        } else if(listCountries.get(i).safety_rating == 4) {
            GradientDrawable bgShape = (GradientDrawable)icon.getBackground();
            bgShape.setColor(Color.RED);
        }

        names.setText(listCountries.get(i).name);
        return view;
    }
}
