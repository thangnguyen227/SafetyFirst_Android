package com.dichvudacbiet.safetyfirst.service;


import com.dichvudacbiet.safetyfirst.model.FirstAid;
import com.dichvudacbiet.safetyfirst.model.Language;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.RescueSkillModel;
import com.dichvudacbiet.safetyfirst.model.network.BMIRequest;
import com.dichvudacbiet.safetyfirst.model.network.CountryFullRequest;
import com.dichvudacbiet.safetyfirst.model.network.GeoAddressRequest;
import com.dichvudacbiet.safetyfirst.model.network.HealthCareActivateTitleRequest;
import com.dichvudacbiet.safetyfirst.model.network.PhoneBookRequest;
import com.dichvudacbiet.safetyfirst.model.network.SosRequestList;
import com.dichvudacbiet.safetyfirst.model.network.VaccinModelRequest;
import com.dichvudacbiet.safetyfirst.presenter.HomePresenter;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.google.gson.Gson;
import com.dichvudacbiet.safetyfirst.BuildConfig;
import com.dichvudacbiet.safetyfirst.model.network.CountriesRequest;
import com.dichvudacbiet.safetyfirst.model.network.CountryEmerNumByCountryRequest;
import com.dichvudacbiet.safetyfirst.model.network.CountryEmerNumRequest;
import com.dichvudacbiet.safetyfirst.model.network.CountryRequest;
import com.dichvudacbiet.safetyfirst.model.network.FoodsRequest;
import com.dichvudacbiet.safetyfirst.model.network.HealthCareActivateRequest;
import com.dichvudacbiet.safetyfirst.model.network.HealthCareUpdateRequest;
import com.dichvudacbiet.safetyfirst.model.network.JobRequest;
import com.dichvudacbiet.safetyfirst.model.network.MedicalRequest;
import com.dichvudacbiet.safetyfirst.model.network.NetworkResponse;
import com.dichvudacbiet.safetyfirst.model.network.NotificationRequest;
import com.dichvudacbiet.safetyfirst.model.network.NotificationRequest2;
import com.dichvudacbiet.safetyfirst.model.network.QuestionRequest;
import com.dichvudacbiet.safetyfirst.model.network.RelationRequest;
import com.dichvudacbiet.safetyfirst.model.network.RespondData;
import com.dichvudacbiet.safetyfirst.model.network.ReviewScheduleRequest;
import com.dichvudacbiet.safetyfirst.model.network.SchedueRequest;
import com.dichvudacbiet.safetyfirst.model.network.SosRequest;
import com.dichvudacbiet.safetyfirst.model.network.UnreadNotificationCountRequest;
import com.dichvudacbiet.safetyfirst.model.network.UserRepoModel;
import com.dichvudacbiet.safetyfirst.model.network.VaccinModelPostRequest;
import com.dichvudacbiet.safetyfirst.model.network.VaccinRequest;
import com.dichvudacbiet.safetyfirst.model.network.VaccinRequestObject;

import java.net.URI;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;


/**
 * Created by ABCD on 7/5/2016.
 */
public class ApiService {
    private static GitApiInterface gitApiInterface;
    private static GitApiInterface gitApiInterface2;
    private static GoogleApiInterface googleApiInterface;

    private static String baseUrl = "http://dichvudacbiet.com/api/v1/";
    private static String getlocationUrl = "http://ip-api.com/";
    private static String GoogleGeoAPIURL = "https://maps.googleapis.com/maps/api/geocode/";
    private static Gson gson;

    public static GitApiInterface getClient() {
        if (gitApiInterface == null) {

        }
        gson = new Gson();
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(BuildConfig.DEBUG
                ? new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)
                : new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.NONE));

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .baseUrl(baseUrl)
                .client(client)
                .build();
        gitApiInterface = retrofit.create(GitApiInterface.class);
        return gitApiInterface;
    }

    public static GitApiInterface getClientTwo() {
        if (gitApiInterface2 == null) {

        }
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(BuildConfig.DEBUG
                ? new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)
                : new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.NONE));

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .addConverterFactory(ScalarsConverterFactory.create())
                .baseUrl(getlocationUrl)
                .client(client)
                .build();
        gitApiInterface2 = retrofit.create(GitApiInterface.class);
        return gitApiInterface2;
    }

    public static GoogleApiInterface getClientGoogleGeoApi() {
        if (googleApiInterface == null) {

        }
        gson = new Gson();
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(BuildConfig.DEBUG
                ? new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)
                : new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.NONE));

        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .baseUrl(GoogleGeoAPIURL)
                .client(client)
                .build();
        googleApiInterface = retrofit.create(GoogleApiInterface.class);
        return googleApiInterface;
    }

    public interface GoogleApiInterface {
        @GET("json")
        Call<GeoAddressRequest> getFromLocation(@Query("latlng") String latlng, @Query("sensor") boolean sensor, @Query("language") String language, @Query("key")String key);
    }

    public interface GitApiInterface {

        /*-----------------------------------Method $PUT API----------------------------------------------------*/
        @GET("json")
        Call<String> getCurrentCountry();

        @POST("user")
        Call<RespondData> getRegister(@Body Object data,@Query("lang") String lang);

        @POST("user/travel-schedule")
        Call<RespondData> createSchedule(@Query("token") String token, @Body Object data);

        @PUT("user/travel-schedule/{id}")
        Call<RespondData> editUserSchedule(@Path(value = "id", encoded = true) String id,  @Query("token") String token, @Body Object data);

        @POST("user/location")
        Call<RespondData> postLocation(@Query("token") String token, @Body Object data);

        @POST("user/call")
        Call<RespondData> postCall(@Query("token") String token, @Body Object data);

        @POST("user/questions")
        Call<QuestionRequest> postQuestions(@Query("token") String token, @Body Object data);

        @POST("user/services")
        Call<NetworkResponse> postOtherQuestions(@Query("token") String token, @Body Object data);

        @GET("countries/")
        Call<CountryRequest> getCountry(@Query("token") String token);

        @GET("first-aids")
        Call<CountryRequest> getFirstAid(@Query("token") String token);

        @GET("user/travel-schedule")
        Call<SchedueRequest> getSchedueListUser(@Query("token") String token, @Query("user_id") int user_id);

        @GET("user/health-care-schedule")
        Call<HealthCareActivateTitleRequest> getHealthCareActivities(@Query("token") String token,@Query("lang") String lang);

        @GET("health-care-activity")
        Call<HealthCareActivateTitleRequest> getHealthCareActivity(@Query("token") String token, @Query("lang") String lang);

        @GET("relation-type")
        Call<RelationRequest> getRelation(@Query("lang") String lang);

        @POST("user/relations")
        Call<RelationRequest> createUserRelation(@Query("token") String token, @Body Object data);

        @GET("location")
        Call<CountriesRequest> getCountries(@Query("level") int level,@Query("parent_id") Object parent_id);

        @GET("location/services")
        Call<FoodsRequest> getServices(@Query("location_id") int location_id);

        @GET("locations/by-country")
        Call<CountriesRequest> getCities(@Query("country_id") int country_id);

        @GET("job")
        Call<JobRequest> getJobs(@Query("token") String token, @Query("lang") String lang);

        @GET("questions/")
        Call<QuestionRequest> getQuestions(@Query("token") String token);

        @GET("question/")
        Call<QuestionRequest> getQuestion(@Query("token") String token ,  @Query("lang") String lang);

        @GET("support-information")
        Call<MedicalRequest> getSupportInformation(@Query("type") int type, @Query("location_id") int location_id,
                                                   @Query("token") String token, @Query("location_code") String location_code);

        @POST("support/authorities-list")
        Call<MedicalRequest> getAuthoritiesList(@Body Object data);

        @POST("support/service-list")
        Call<MedicalRequest> getServiceList(@Body Object data);

        @POST("religion-places")
        Call<MedicalRequest> getReligionList(@Body Object data);

        @POST("shopping-malls")
        Call<MedicalRequest> getShoppingMallsList(@Body Object data);


        @POST("support/consulate-list")
        Call<MedicalRequest> getConsulateList(@Body Object data);

        @PUT("user/{id}")
        Call<UserRepoModel> getUpdate(@Path(value = "id", encoded = true) int id, @Query("token") String token, @Body Object data);

        @GET("location/services")
        Call<CountryRequest> getLocationService(@Query("location_id") int location_id);


        @POST("user/health-care-schedule")
        Call<HealthCareActivateRequest> postHealthCareActivities(@Query("token") String token, @Body Object data);

        @POST("user/review")
        Call<ReviewScheduleRequest> postReviewUser(@Query("token") String token, @Body Object data);

        @PUT("user/health-care-schedule/{id}")
        Call<HealthCareUpdateRequest> postUpdateHealthSchedule(@Path(value = "id", encoded = true) String id, @Query("token") String token, @Body Object data);

        @PUT("user/health-care-schedule/{id}")
        Call<Object> postUpdateUserHealthCareResult(@Path(value = "id", encoded = true) String id, @Query("token") String token, @Body Object data);

        @GET("user/kid")
        Call<VaccinRequest> getUserVaccinationInfo(@Query("token") String token, @Query("lang") String lang);

        @POST("user/kid")
        Call<VaccinRequestObject> postVaccinationInfo(@Query("token") String token, @Body Object data);

        @PUT("user/kid/{id}")
        Call<VaccinModelRequest> postUpdateVaccinInfo(@Path(value = "id", encoded = true) String id, @Query("token") String token, @Body Object data);

        @GET("support/vaccination-info-list")
        Call<VaccinRequest> getSupportVaccinationInfoList(@Query("token") String token);

        @GET("sos-message")
        Call<SosRequestList> getSOSMessageList(@Query("token") String token,@Query("location_code") String location_code);

        @POST("user/sos-message")
        Call<SosRequest> postSOSMessageList(@Query("token") String token,@Body Object object);

        @GET("user/notification")
        Call<NotificationRequest> getUserNotifications(@Query("token") String token);

        @POST("user/notification/mark-as-read/{id}")
        Call<NotificationRequest2> markNotificationAsRead(@Path(value = "id", encoded = true) int id,@Query("token") String token);

        @POST("emergency-numbers/all-countries/")
        Call<CountryEmerNumRequest> getCountriesEmergencyNumbers();

        @POST("user/broadcast-message")
        Call<Object> broadcastMessage(@Query("token") String token,@Body Object data);

        @GET("phone-book")
        Call<PhoneBookRequest> getPhoneBook(@Query("token") String token, @Query("location_code") String location_code);

        @GET("user/notification/unread-count")
        Call<UnreadNotificationCountRequest> getUserUnreadNotificationCount(@Query("token") String token);

        @GET("bmi/adult")
        Call<ResponseBody> getAdultBMI(@Query("token") String token);

        @GET("bmi/children")
        Call<ResponseBody> getChildrenBMI(@Query("token") String token);

        @POST("bmi/advise")
        Call<BMIRequest> getAdviseBMI(@Query("token") String token,@Body Object data , @Query("lang") String lang);


        @GET("first-aid")
        Call<FirstAid> getfirstAid(@Query("token") String token , @Query("location_code") String location_code);
    }
}
