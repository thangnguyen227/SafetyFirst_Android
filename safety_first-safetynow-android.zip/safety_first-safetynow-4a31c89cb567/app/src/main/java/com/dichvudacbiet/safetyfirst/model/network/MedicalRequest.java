package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.MedicalModel;

import java.util.ArrayList;

public class MedicalRequest {

    public int status;
    public ArrayList<MedicalModel> data;
}