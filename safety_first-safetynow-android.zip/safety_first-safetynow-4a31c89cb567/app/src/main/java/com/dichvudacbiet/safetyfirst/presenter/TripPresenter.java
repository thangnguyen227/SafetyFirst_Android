
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.model.ScheduleModel;
import com.dichvudacbiet.safetyfirst.model.network.SchedueRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.view.TripView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class TripPresenter extends BasePresenter<TripView> {

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            Call<SchedueRequest> call = ApiService.getClient().getSchedueListUser(PrefUtil.getTokenInfo() , PrefUtil.getUserInfo().id);
            call.enqueue(new Callback<SchedueRequest>() {
                @Override
                public void onResponse(Call<SchedueRequest> call, Response<SchedueRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<ScheduleModel> respondData =  response.body().data;
                            getView().setData(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu", false);
                    }

                }
                @Override
                public void onFailure(Call<SchedueRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }
            });
        }
    }

    public void onNewsClicked(ScheduleModel news, int position) {
        if (isViewAttached()) {
            getView().showCreateSchedule(news);
        }
    }
    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
