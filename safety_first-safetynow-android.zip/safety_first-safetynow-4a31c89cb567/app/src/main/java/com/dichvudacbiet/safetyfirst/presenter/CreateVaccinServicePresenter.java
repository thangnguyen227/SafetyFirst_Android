
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.model.VaccinModel;
import com.dichvudacbiet.safetyfirst.model.network.VaccinModelPostRequest;
import com.dichvudacbiet.safetyfirst.model.network.VaccinModelRequest;
import com.dichvudacbiet.safetyfirst.model.network.VaccinRequestObject;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.CreateVaccinServiceView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CreateVaccinServicePresenter extends BasePresenter<CreateVaccinServiceView> {


    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {

        }
    }


    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }


    public void updateVaccinInfo(VaccinModel vaccinModel){

        Object data = VaccinModelRequest.newBuilder()
                .name(vaccinModel.fullname)
                .gender(vaccinModel.gender)
                .birthday(vaccinModel.birth_date)
                .birth_height(vaccinModel.birth_height)
                .birth_weight(vaccinModel.birth_weight).vaccinations(vaccinModel.vaccinations).build();
        Call<VaccinModelRequest> call = ApiService.getClient().postUpdateVaccinInfo(String.valueOf(vaccinModel.id),PrefUtil.getTokenInfo() , data);
        call.enqueue(new Callback<VaccinModelRequest>() {
            @Override
            public void onResponse(Call<VaccinModelRequest> call, Response<VaccinModelRequest> response) {

                if (response.isSuccessful()) {
                    //RC4
                    try {
                        getView().showMessage("Thành công" , false);
                        getView().navigateBack();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }else{
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }

            }
            @Override
            public void onFailure(Call<VaccinModelRequest> call, Throwable t) {
                getView().showMessage("Lỗi kết nối dữ liệu" , false);
            }
        });

    }

    public void onPostVaccinInfo(String name, String birthday, int gender, String birth_weight, String birth_height){

        int errMsg = Util.validateInput(name,birthday,birth_weight,birth_height);
        if(errMsg!=-1){
            getView().showMessage(errMsg, false);
            return;
        }

        Object vaccin = VaccinModelRequest.newBuilder().name(name).birthday(birthday).gender(gender).birth_weight(birth_weight).birth_height(birth_height)
                .vaccinations(new ArrayList<>()).build();
        Call<VaccinRequestObject> call = ApiService.getClient().postVaccinationInfo(PrefUtil.getTokenInfo() , vaccin);
        call.enqueue(new Callback<VaccinRequestObject>() {
            @Override
            public void onResponse(Call<VaccinRequestObject> call, Response<VaccinRequestObject> response) {

                if (response.isSuccessful()) {
                    //RC4
                    try {
//                        VaccinModelPostRequest vaccin = VaccinModelPostRequest
//                                .newBuilder()
//                                .id(response.body().data.id)
//                                .name(response.body().data.name)
//                                .birthday(response.body().data.birthday)
//                                .gender(response.body().data.gender)
//                                .birth_weight(response.body().data.birth_weight)
//                                .birth_height(response.body().data.birth_height)
//                                .build();
//                       Session.vaccinModelRequest = vaccin;
                        Session.vaccinRequestObject = response.body();
                        Session.vaccinModel = response.body().data;
                        getView().showMessage("Tạo dữ liệu thành công", true);
                        getView().navigateBack();
//                        getView().navigateToCreateVaccinSchedule();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }else{
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }

            }
            @Override
            public void onFailure(Call<VaccinRequestObject> call, Throwable t) {
                getView().showMessage("Lỗi kết nối dữ liệu", false);
            }
        });
    }


}
