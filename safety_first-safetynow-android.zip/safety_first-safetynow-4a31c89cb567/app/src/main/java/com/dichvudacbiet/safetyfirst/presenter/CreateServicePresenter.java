
package com.dichvudacbiet.safetyfirst.presenter;

import android.util.Log;

import com.dichvudacbiet.safetyfirst.model.CountryModel;
import com.dichvudacbiet.safetyfirst.model.CoveringModel;
import com.dichvudacbiet.safetyfirst.model.FoodsModel;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.network.CountriesRequest;
import com.dichvudacbiet.safetyfirst.model.network.FoodsRequest;
import com.dichvudacbiet.safetyfirst.model.network.RespondData;
import com.dichvudacbiet.safetyfirst.model.network.ServiceRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.CreateServiceView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CreateServicePresenter extends BasePresenter<CreateServiceView> {


    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {

            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_COUNTRY,null);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<LocationModel> respondData =  response.body().data;
                            getView().showCountryList(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }

    public void loadDataFoods(int id) {
        if (isViewAttached()) {

            Call<FoodsRequest> call = ApiService.getClient().getServices(id);
            call.enqueue(new Callback<FoodsRequest>() {
                @Override
                public void onResponse(Call<FoodsRequest> call, Response<FoodsRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<FoodsModel> respondData =  response.body().data;
                            getView().showFoodDetail(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<FoodsRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }
    public void loadDataCity(int country_id) {
        if (isViewAttached()) {

            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_PROVINCE,country_id);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<LocationModel> respondData =  response.body().data;
                            getView().showCityList(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }


    public void loadDataAddress(final int id_city) {

        if (isViewAttached()) {

            Call<CountriesRequest> call = ApiService.getClient().getCountries(Session.LEVEL_DISTRICT,id_city);
            call.enqueue(new Callback<CountriesRequest>() {
                @Override
                public void onResponse(Call<CountriesRequest> call, Response<CountriesRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<LocationModel> respondData =  response.body().data;
                            getView().showCoveringList(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<CountriesRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }

    }



    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
    public void onCreateService(String mDateTo , String mDateFrom ,int travel_type, int location , String agency ,String mAdress , String mPhone , String info) {
        if (isViewAttached()) {
            int errMsg = Util.validateInput(mAdress,mPhone);
            if(errMsg!=-1){
                getView().showMessage(errMsg, false);
                return;
            }
            if (isViewAttached()) {
                Object mData = ServiceRequest.newBuilder()
                        .user_id(PrefUtil.getUserInfo().id).to_date(mDateFrom).from_date(mDateTo).destination_id(location).agency(agency).staying_address(mAdress).contact_number(mPhone).info(info);
                Call<RespondData> call = ApiService.getClient().createSchedule(PrefUtil.getTokenInfo(),mData);
                call.enqueue(new Callback<RespondData>() {
                    @Override
                    public void onResponse(Call<RespondData> call, Response<RespondData> response) {

                        if (response.isSuccessful()) {
                            if(response.body().status == 1){
                                getView().showMessage("Tạo thành công chuyến đi", false);
                                getView().navigateBack();
                            }else{
                                getView().showMessage(response.message(), false);
                            }

                        }else{
                            getView().showMessage("Lỗi tạo kết nối", false);
                        }

                    }
                    @Override
                    public void onFailure(Call<RespondData> call, Throwable t) {
                        Log.d("////",t.getMessage());
                        getView().showMessage("Lỗi tạo kết nối", false);
                    }
                });
            }
        }
    }

    public void  onEditService(int id,String mDateTo , String mDateFrom ,int travel_type, int location , String agency ,String mAdress , String mPhone , String info) {
        if (isViewAttached()) {
            if (isViewAttached()) {
                Object mData = ServiceRequest.newBuilder().to_date(mDateFrom).from_date(mDateTo).travel_type(travel_type).destination_id(location).agency(agency).staying_address(mAdress).contact_number(mPhone).info(info);
                Call<RespondData> call = ApiService.getClient().editUserSchedule(String.valueOf(id),PrefUtil.getTokenInfo(),mData);
                call.enqueue(new Callback<RespondData>() {
                    @Override
                    public void onResponse(Call<RespondData> call, Response<RespondData> response) {

                        if (response.isSuccessful()) {
                            if(response.body().status == 1){
                                getView().showMessage("Cập nhật thành công chuyến đi", false);
                                getView().navigateBack();
                            }

                        }else{
                            getView().showMessage("Lỗi tạo kết nối", false);
                        }

                    }
                    @Override
                    public void onFailure(Call<RespondData> call, Throwable t) {
                        getView().showMessage("Lỗi tạo kết nối", false);
                    }
                });
            }
        }
    }
}
