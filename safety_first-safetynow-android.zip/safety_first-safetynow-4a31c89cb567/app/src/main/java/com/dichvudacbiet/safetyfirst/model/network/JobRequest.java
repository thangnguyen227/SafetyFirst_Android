package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.JobModel;

import java.util.ArrayList;

public class JobRequest {
    public int success;
    public ArrayList<JobModel> data;
}