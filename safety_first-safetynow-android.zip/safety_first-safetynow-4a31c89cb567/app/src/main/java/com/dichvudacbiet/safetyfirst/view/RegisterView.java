
package com.dichvudacbiet.safetyfirst.view;

import com.dichvudacbiet.safetyfirst.model.CountryModel;
import com.dichvudacbiet.safetyfirst.model.CoveringModel;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.Relation2Model;
import com.dichvudacbiet.safetyfirst.model.JobModel;

import java.util.ArrayList;

/**
 * Created by ducth on 11/18/16.
 */

public interface RegisterView extends BaseView {
    void navigateBack();
    void showRelations(String name, String address, String phone, String mobile, String job);
    void showRelation(ArrayList<Relation2Model> relation2Models);
    void showCountryList(ArrayList<LocationModel> LocationModel);
    void showCityList(ArrayList<LocationModel> countryModel);
    void showCoveringList(ArrayList<LocationModel> countryModel);
    void showJobs(ArrayList<JobModel> jobs);
    void backToHome();
}
