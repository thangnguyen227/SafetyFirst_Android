
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;

import java.util.List;

public interface HealthCareView extends BaseView {
    void navigateBack();
    void setData(List<HealthCareActivateModel> healthModels);
}
