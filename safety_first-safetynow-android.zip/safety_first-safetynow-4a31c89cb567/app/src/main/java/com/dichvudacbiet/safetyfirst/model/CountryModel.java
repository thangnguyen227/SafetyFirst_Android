package com.dichvudacbiet.safetyfirst.model;

import java.util.ArrayList;

/**
 * Created by loi.doan on 01/04/18.
 */

public class CountryModel {
    public int id;
    public  int country_id;
    public  String name;
    public String full_name;
    public String info;
    public ArrayList<CoveringModel> covering;
    public int safety_rating;



}
