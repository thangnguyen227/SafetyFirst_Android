
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.RescueSkillModel;

import java.util.List;

public interface RescueSkillView extends BaseView {
    void navigateBack();
    void setData(List<RescueSkillModel> listNews);
    void showDetail(String fileName);
}
