
package com.dichvudacbiet.safetyfirst.fragment;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.CountryModel;
import com.dichvudacbiet.safetyfirst.model.CoveringModel;
import com.dichvudacbiet.safetyfirst.model.FoodsModel;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.ScheduleModel;
import com.dichvudacbiet.safetyfirst.presenter.CreateServicePresenter;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.CreateServiceView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;


public class CreateTripSerivceFragment extends BaseFragment<CreateServiceView, CreateServicePresenter>
        implements CreateServiceView, View.OnClickListener {

    private TextView mToolbarTitle;
    private TextView mDateTo , mDateFrom;
    private Spinner mCountry , mCity , mSpinerAddress;
    private Calendar myCalendar;
    private DatePickerDialog.OnDateSetListener date;
    private DatePickerDialog.OnDateSetListener date2;
    private TextInputLayout inputLayoutAddress;
    private TextInputLayout inputLayoutPhone;
    private TextInputLayout inputLayoutAgency;
    private RadioGroup mGroupService;
    private Button mCreate;
    private int mIdAddress;
    private Button mShowDetail;
    private ScheduleModel scheduleModel;

    //
    int initCount = 0;

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_create_service;
    }

    public CreateTripSerivceFragment(){

    }

    @SuppressLint("ValidFragment")
    public CreateTripSerivceFragment(ScheduleModel scheduleModel){
        this.scheduleModel = scheduleModel;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);
        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.create_trip));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //
        mDateTo = (TextView) view.findViewById(R.id.date_to);
        mDateFrom = (TextView) view.findViewById(R.id.date_from);
        mCountry = (Spinner) view.findViewById(R.id.sp_country);
        mCity = (Spinner) view.findViewById(R.id.sp_city);
        mSpinerAddress = (Spinner) view.findViewById(R.id.sp_address);
        mShowDetail = (Button) view.findViewById(R.id.show_detail);
        //

        mDateTo.setOnClickListener(this);
        mDateFrom.setOnClickListener(this);
        mShowDetail.setOnClickListener(this);
        myCalendar = Calendar.getInstance();
        date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };
        date2 = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel2();
            }
        };
        //
        mGroupService = (RadioGroup) view.findViewById(R.id.radioServiec);
        inputLayoutAddress = (TextInputLayout) view.findViewById(R.id.register_inputLayoutaddress);
        inputLayoutPhone = (TextInputLayout) view.findViewById(R.id.register_inputLayoutphone);
        inputLayoutAgency = (TextInputLayout) view.findViewById(R.id.register_inputLayoutCompany);
        mCreate = (Button) view.findViewById(R.id.btn_create);
        mCreate.setOnClickListener(this);
        mGroupService.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int radioButtonID = radioGroup.getCheckedRadioButtonId();
                View radioButton = radioGroup.findViewById(radioButtonID);
                int idx = radioGroup.indexOfChild(radioButton);
                RadioButton r = (RadioButton)  radioGroup.getChildAt(idx);
                String selectedtext = r.getText().toString();
                if(selectedtext.equals("Tour")){
                    inputLayoutAgency.setVisibility(View.VISIBLE);
                }else{
                    inputLayoutAgency.setVisibility(View.GONE);
                }
            }
        });


    }
    private void updateLabel() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        mDateTo.setText(sdf.format(myCalendar.getTime()));
    }
    private void updateLabel2() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        mDateFrom.setText(sdf.format(myCalendar.getTime()));
    }
    @NonNull
    @Override
    public CreateServicePresenter createPresenter() {
        return new CreateServicePresenter();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
            case R.id.date_to:
                DatePickerDialog dpDialog = new DatePickerDialog(getActivity(), date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));
                dpDialog.show();

                break;
            case R.id.date_from:
                DatePickerDialog dpDialog2 = new DatePickerDialog(getActivity(), date2, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));
                dpDialog2.show();

                break;
            case R.id.btn_create:
                String relationAddress = Util.safelyGetTextFromEditText(inputLayoutAddress.getEditText());
                String relationPhone = Util.safelyGetTextFromEditText(inputLayoutPhone.getEditText());
                String mAgency = Util.safelyGetTextFromEditText(inputLayoutAgency.getEditText());
                int travel_type;
                if(((RadioButton)mGroupService.getChildAt(0)).isChecked()){
                    travel_type = 0;
                }else{
                    travel_type =1;
                }
                if(scheduleModel==null){

                    getPresenter().onCreateService(mDateTo.getText().toString() , mDateFrom.getText().toString() ,travel_type, mIdAddress, mAgency , relationAddress , relationPhone , null);
                }else{
                    getPresenter().onEditService(scheduleModel.id ,mDateTo.getText().toString(),
                            mDateFrom.getText().toString() ,travel_type, mIdAddress, mAgency , relationAddress , relationPhone , null);
                }
                break;
            case R.id.show_detail:
                getPresenter().loadDataFoods(mIdAddress);
                break;

        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void showCountryList(ArrayList<LocationModel> countryModel) {
        ArrayList<String> mList = new ArrayList<String>();
        for (int i = 0 ; i < countryModel.size(); i++){
            mList.add(countryModel.get(i).name);
        }
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, mList);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        mCountry.setAdapter(spinnerArrayAdapter);
        mCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getPresenter().loadDataCity(countryModel.get(position).id);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void showCityList(ArrayList<LocationModel> countryModel) {
        ArrayList<String> mList = new ArrayList<String>();
        for (int i = 0 ; i < countryModel.size(); i++){
            mList.add(countryModel.get(i).name);
        }
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, mList);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        mCity.setAdapter(spinnerArrayAdapter);
        mCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getPresenter().loadDataAddress(countryModel.get(position).id);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    @Override
    public void showCoveringList(ArrayList<LocationModel> countryModel) {
        ArrayList<String> mList = new ArrayList<String>();
        for (int i = 0 ; i < countryModel.size(); i++){
            mList.add(countryModel.get(i).name);
        }
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, mList);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        mSpinerAddress.setAdapter(spinnerArrayAdapter);
        mSpinerAddress.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                mIdAddress = countryModel.get(position).id;
                if(initCount < 1){
                    initViews();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void showFoodDetail(ArrayList<FoodsModel> foodsModels) {
        AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
        alertDialog.setTitle("Thông tin:");
        alertDialog.setMessage(foodsModels.get(0).info);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private void initViews(){
        if(scheduleModel!=null){
            initCount++;
            mToolbarTitle.setText("Cập nhật chuyến đi");
            mCreate.setText("Cập nhật");

            mDateTo.setText(scheduleModel.return_date);
            mDateFrom.setText(scheduleModel.depart_date);

                mCountry.setSelection(getIndexCountry(mCountry,scheduleModel.destination.parent.parent.name));
                mCity.setSelection(getIndexCountry(mCity,scheduleModel.destination.parent.name));
                mSpinerAddress.setSelection(getIndexCountry(mSpinerAddress,scheduleModel.destination.name));



            inputLayoutPhone.getEditText().setText(scheduleModel.contact_number);
            inputLayoutAddress.getEditText().setText(scheduleModel.staying_address);
            inputLayoutAgency.getEditText().setText(scheduleModel.travel_company_name);
            if(scheduleModel.travel_type == 0){
                mGroupService.check(mGroupService.getChildAt(0).getId());
            }else{
                mGroupService.check(mGroupService.getChildAt(1).getId());
            }


        }
    }


    @Override
    public void showMessage(int message, boolean success) {
        super.showMessage(message, success);
        Toast.makeText(getActivity(), getResources().getString(message), Toast.LENGTH_SHORT).show();
    }


    private int getIndexCountry(Spinner spinner, String myString){

        int index = 0;

        for (int i=0;i<spinner.getCount();i++){
            if (spinner.getItemAtPosition(i).equals(myString)){
                index = i;
            }
        }
        return index;
    }

}
