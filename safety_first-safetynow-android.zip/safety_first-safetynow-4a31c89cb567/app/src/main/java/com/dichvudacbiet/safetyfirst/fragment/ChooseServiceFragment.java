
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.adapter.ServiceAdapter;
import com.dichvudacbiet.safetyfirst.model.ServiceModel;
import com.dichvudacbiet.safetyfirst.presenter.ChooseServicePresenter;
import com.dichvudacbiet.safetyfirst.view.ChooseServiceView;

import java.util.List;


public class ChooseServiceFragment extends BaseFragment<ChooseServiceView, ChooseServicePresenter>
        implements ChooseServiceView, View.OnClickListener , RecyclerViewOnItemClickedListener<ServiceModel> {

    private RecyclerView rvList;
    private ServiceAdapter adapter;

    private TextView mToolbarTitle;

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_choose_service;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);
        //
        mToolbarTitle = view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.service_page));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //

        adapter = new ServiceAdapter();
        adapter.setOnItemClickListener(this);
        rvList = view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rvList.setAdapter(adapter);
    }

    @NonNull
    @Override
    public ChooseServicePresenter createPresenter() {
        return new ChooseServicePresenter();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;

        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void showServicePage(int position) {

        switch (position){
            case 0: ((BaseActivity) getActivity()).pushFragment(new TripListFragment(), true);
                break;
            case 1: ((BaseActivity) getActivity()).pushFragment(new HealhCareFragment(), true);
                break;
            case 2: ((BaseActivity) getActivity()).pushFragment(new VaccinFragment(), true);
                break;
            case 3: ((BaseActivity) getActivity()).pushFragment(new BMIFragment(), true);
                break;
        }

    }

    @Override
    public void setData(List<ServiceModel> listNews) {
        adapter.setListNews(listNews);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, ServiceModel serviceModel, int position) {
        getPresenter().onNewsClicked(serviceModel, position);
    }


}
