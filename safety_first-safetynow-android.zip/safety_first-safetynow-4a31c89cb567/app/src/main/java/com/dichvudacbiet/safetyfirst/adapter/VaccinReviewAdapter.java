
package com.dichvudacbiet.safetyfirst.adapter;

import android.app.DatePickerDialog;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.VaccinModel;
import com.dichvudacbiet.safetyfirst.model.network.VaccinScheduleModel;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;


public class VaccinReviewAdapter extends BaseExpandableListAdapter
        implements View.OnClickListener {




    private List<VaccinModel> vaccinList;

    private RecyclerView rvList;
    protected RecyclerViewOnItemClickedListener<VaccinModel> listener;
    private Context mContext;
    private Calendar myCalendar;
    private DatePickerDialog.OnDateSetListener date;



    public VaccinReviewAdapter(Context context, List<VaccinModel> listNews){
        mContext = context;
        this.vaccinList = listNews;
    }
    public void setListNews(List<VaccinModel> listNews) {
        this.vaccinList = listNews;
    }

    public List<VaccinModel> getListNews() {
        return vaccinList;
    }

    public void setOnItemClickListener(RecyclerViewOnItemClickedListener<VaccinModel> listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        View containingView = rvList.findContainingItemView(v);
        int position = rvList.getChildAdapterPosition(containingView);
        if (position == RecyclerView.NO_POSITION) {
            return;
        }

        if (listener != null) {
            listener.onItemClicked(rvList, vaccinList.get(position), position);
        }
    }

    @Override
    public int getGroupCount() {
        return this.vaccinList.size();
    }

    @Override
    public int getChildrenCount(int i) {
        return 0;
    }

    @Override
    public Object getGroup(int i) {
        return this.vaccinList.get(i);
    }

    @Override
    public Object getChild(int i, int i1) {
        return 0;
    }

    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int i, boolean b, View view, ViewGroup viewGroup) {
        final String name = ((VaccinModel) getGroup(i)).fullname;
        final String birthday = ((VaccinModel) getGroup(i)).birth_date;
         String gender;
        if(((VaccinModel) getGroup(i)).gender == 0){
            gender = "male";
        }else{
            gender = "female";
        }

        if (view == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = infalInflater.inflate(R.layout.item_header_vaccin_review, null);
        }

        ParentViewHolder viewHolder = new ParentViewHolder(view);
        viewHolder.mName.setText(name);
        viewHolder.mGender.setText(gender);
        viewHolder.mBirthday.setText(birthday);
        viewHolder.cb_choose.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
//                if ( isChecked )
//                    vaccinList.get(i).isChoose = true;
//                else
//                    vaccinList.get(i).isChoose = false;

            }
        });
        view.setTag(viewHolder);
        return view;
    }

    @Override
    public View getChildView(int i, int i1, boolean isLastChild, View view, ViewGroup viewGroup) {
        final String date_time = ((VaccinScheduleModel)getChild(i, i1)).date_time;
        final String info = ((VaccinScheduleModel)getChild(i, i1)).info;
        final String create_at = ((VaccinScheduleModel)getChild(i, i1)).created_at;
        final String update_at = ((VaccinScheduleModel)getChild(i, i1)).updated_at;
        if (view == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = infalInflater.inflate(R.layout.item_child_schedule_vaccin_review, null);
        }
        ChildViewHolder viewHolder = new ChildViewHolder(view);
        viewHolder.mDate.setText(date_time);
        viewHolder.mInfo.setText(info);
        viewHolder.mCreatedAt.setText(create_at);
        viewHolder.mUpdatedAt.setText(update_at);

        view.setTag(viewHolder);
        return view;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }

    public class ChildViewHolder{
        public TextView mInfo,mDate, mCreatedAt, mUpdatedAt;
        public ChildViewHolder(View view) {
            mDate =  view.findViewById(R.id.edt_date_time);
            mCreatedAt =  view.findViewById(R.id.tv_created_at);
            mUpdatedAt = view.findViewById(R.id.tv_updated_at);
            mInfo = view.findViewById(R.id.tv_info);
        }

    }


    public class ParentViewHolder{
        public TextView mName,mGender,mBirthday,mBirthWeight,mBirthHeight;
        public CheckBox cb_choose;
        public ParentViewHolder(View view) {
            mName = view.findViewById(R.id.tv_name);
            mGender = view.findViewById(R.id.tv_gender);
            mBirthday = view.findViewById(R.id.tv_birthday);
            mBirthWeight = view.findViewById(R.id.tv_birth_weight);
            mBirthHeight = view.findViewById(R.id.tv_birth_height);
            cb_choose = view.findViewById(R.id.cb_chosen);
        }

    }


    TextView tvTemp;

//    public void onBindViewHolder(MyViewHolder holder, int position) {
//        VaccinModel vaccinModel = vaccinList.get(position);
//        holder.mName.setText(vaccinModel.name);
//        holder.mLocation.setText(vaccinModel.location);
//        holder.mInfo.setText(vaccinModel.info);
//        holder.mDate.setText(vaccinModel.date_time);
//        holder.mDate.setOnClickListener(v->{
//            tvTemp = holder.mDate;
//            AlertUtil.showDatePickerDialog(mContext,tvTemp);
//        });
//        myCalendar = Calendar.getInstance();
//        date = (v,  year,  monthOfYear, dayOfMonth) -> {
//            // TODO Auto-generated method stub
//            myCalendar.set(Calendar.YEAR, year);
//            myCalendar.set(Calendar.MONTH, monthOfYear);
//            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
//            if(tvTemp!=null)
//            updateLabel(tvTemp);
//        };
//
//
//    }





    private void updateLabel(TextView mDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm", Locale.US);
        mDate.setText(sdf.format(myCalendar.getTime()));
    }


    //Adapter


}

