
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.HealthReviewAdapter;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;
import com.dichvudacbiet.safetyfirst.model.ScheduleModel;
import com.dichvudacbiet.safetyfirst.presenter.HealthCarePresenter;
import com.dichvudacbiet.safetyfirst.view.HealthCareView;

import java.util.ArrayList;
import java.util.List;


public class HealhCareFragment extends BaseFragment<HealthCareView, HealthCarePresenter>
        implements HealthCareView, View.OnClickListener , RecyclerViewOnItemClickedListener<ScheduleModel> {

    private RecyclerView rvList;

    private HealthReviewAdapter health_adapter;

    private TextView mToolbarTitle;

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_list_schedule_general;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);

        ImageButton btnSos = (ImageButton) view.findViewById(R.id.top_bar_btnRight);
        btnSos.setImageResource(R.drawable.ic_add_black_24dp);
        btnSos.setOnClickListener(this);

        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.healthy_schedule_page));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //

        health_adapter = new HealthReviewAdapter(getActivity(),new ArrayList<>());
        rvList = (RecyclerView) view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rvList.setAdapter(health_adapter);

    }

    @NonNull
    @Override
    public HealthCarePresenter createPresenter() {
        return new HealthCarePresenter();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
            case R.id.top_bar_btnRight:
                ((BaseActivity) getActivity()).pushFragment(new CreateHealthScheduleServiceFragment(), true);
                break;
        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }



    @Override
    public void setData(List<HealthCareActivateModel> healthModels) {
        health_adapter.setListNews(healthModels);
        health_adapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, ScheduleModel scheduleModel, int position) {
        getPresenter().onNewsClicked(scheduleModel, position);
    }


}
