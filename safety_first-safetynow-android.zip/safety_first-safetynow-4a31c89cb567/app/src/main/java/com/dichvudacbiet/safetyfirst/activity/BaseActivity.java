package com.dichvudacbiet.safetyfirst.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.MotionEvent;

import com.dichvudacbiet.safetyfirst.base.Constants;
import com.dichvudacbiet.safetyfirst.model.AddressModel;
import com.dichvudacbiet.safetyfirst.service.FetchAddressIntentService;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.hannesdorfmann.mosby.mvp.MvpPresenter;
import com.hannesdorfmann.mosby.mvp.MvpView;
import com.hannesdorfmann.mosby.mvp.viewstate.MvpViewStateActivity;
import com.hannesdorfmann.mosby.mvp.viewstate.RestorableViewState;
import com.hannesdorfmann.mosby.mvp.viewstate.ViewState;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.base.SubscriberImpl;
import com.dichvudacbiet.safetyfirst.fragment.BackPressedInterceptor;
import com.dichvudacbiet.safetyfirst.util.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;


public abstract class BaseActivity<V extends MvpView, P extends MvpPresenter<V>> extends
        MvpViewStateActivity<V, P> {
    protected BaseActivity() {
    }

    public interface IOnFocusListenable {
        void dispatchTouchEvent(MotionEvent ev);
    }

    protected Stack<String> fragmentNames = new Stack<>();
    protected Stack<String> fragmentOverlayNames = new Stack<>();
    protected boolean blockAllTouchEvent = false;

    private FusedLocationProviderClient mFusedLocationClient;
    private AddressResultReceiver mResultReceiver;
    private Location mCurrentlocation;
    private boolean isLocationServiceGranted = false;
    public AddressModel CurrentAddressModel;
    private ProgressDialog progressDialog;
    private Handler handler;

    private List<OnRequestLocationReady> listRequestLocationWaiting = new ArrayList<>();


    public void pushFragment(Fragment fragment, boolean addToBackStack) {
        pushFragment(fragment, Constants.TransitionType.SLIDE_IN_RIGHT_TO_LEFT, addToBackStack);

    }

    public void pushFragment(Fragment fragment, Constants.TransitionType transitionType,
                             boolean addToBackStack) {
        blockAllTouchEventOnAnimation();

        String fragmentName = fragment.getClass().getSimpleName() + System.currentTimeMillis();

        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(transitionType.enter, transitionType.exit,
                        transitionType.popEnter, transitionType.popExit)
                .replace(R.id.fragment_container, fragment, fragmentName)
                .addToBackStack(fragmentName)
                .commitAllowingStateLoss();

        if (addToBackStack) {
            fragmentNames.push(fragmentName);
        }
    }

    public void pushOverlayFragment(Fragment fragment, boolean addToBackStack) {
        pushOverlayFragment(fragment, Constants.TransitionType.SLIDE_IN_RIGHT_TO_LEFT,
                addToBackStack);
    }

    public void pushOverlayFragment(Fragment fragment, Constants.TransitionType transitionType,
                                    boolean addToBackStack) {
        blockAllTouchEventOnAnimation();

        String fragmentName = fragment.getClass().getSimpleName() + System.currentTimeMillis();

        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(transitionType.enter, transitionType.exit,
                        transitionType.popEnter, transitionType.popExit)
                .replace(R.id.fragment_overlay_container, fragment, fragmentName)
                .addToBackStack(fragmentName)
                .commitAllowingStateLoss();

        if (addToBackStack) {
            fragmentOverlayNames.push(fragmentName);
        }
    }

    public void popFragment() {
        blockAllTouchEventOnAnimation();
        if (!fragmentNames.empty()) {
            String tag = fragmentNames.pop();
            getSupportFragmentManager().popBackStack(tag,
                    FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }

    }

    public void popOverlayFragment() {
        blockAllTouchEventOnAnimation();

        String tag = fragmentOverlayNames.pop();
        getSupportFragmentManager().popBackStack(tag, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }

    public void popAllOverlayFragment() {
        blockAllTouchEventOnAnimation();

        String tag = fragmentOverlayNames.get(0);
        fragmentOverlayNames.clear();
        getSupportFragmentManager().popBackStack(tag,
                android.support.v4.app.FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }

    public void popToFragment(int index, boolean shouldPopNamedFragment) {
        String fragmentName = fragmentNames.peek();
        getSupportFragmentManager().popBackStack(fragmentName,
                shouldPopNamedFragment ? FragmentManager.POP_BACK_STACK_INCLUSIVE : 0);

        for (int i = fragmentNames.size() - 1; i > index; i--) {
            fragmentNames.pop();
        }

        if (shouldPopNamedFragment) {
            fragmentNames.pop();
        }
    }

    public void blockAllTouchEventOnAnimation() {
        Util.delayExecute(300)
                .doOnSubscribe(() -> blockAllTouchEvent = true)
                .doOnNext(aLong -> blockAllTouchEvent = false)
                .subscribe(new SubscriberImpl<>());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkPermissionGranted();
        initLocationService();
//        requestLocationService();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    public void checkPermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                Log.v("Permission", "Permission is granted");

            } else {

                Log.v("Permission", "Permission is revoked");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);

            }
        }
    }

    public void showLoading(boolean isShow) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (isShow && progressDialog == null) {
//                    progressDialog = new ProgressDialog(BaseActivity.this);
//                    progressDialog.setMessage("Loading");
//                    progressDialog.setCancelable(false);
//                    progressDialog.show();
                } else {
                    if (progressDialog != null && progressDialog.isShowing()) {
//                        progressDialog.dismiss();
//                        progressDialog = null;
                    }
                }
            }
        });

    }

    private void initLocationService() {
        handler = new Handler();

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        isLocationServiceGranted = true;
    }

    public void requestLocationService(OnRequestLocationReady listener) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            isLocationServiceGranted = false;
            listener.OnRequestLocationResponse(false);
            return;
        }
        if (!listRequestLocationWaiting.contains(listener)) {
            listRequestLocationWaiting.add(listener);
        }

        isLocationServiceGranted = true;
        showLoading(true);
        mFusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {
                            // Logic to handle location object
                            mCurrentlocation = location;
                            // In some rare cases the location returned can be null
                            if (mCurrentlocation == null) {
                                broadcastLocationResponse(false);
                                return;
                            }

                            if (!Geocoder.isPresent()) {
//                                Toast.makeText(this, "no_geocoder_available", Toast.LENGTH_LONG).show();
                                broadcastLocationResponse(false);
                                return;
                            }
                            // Start service and update UI to reflect new location
                            startRequestLocationAddress();
                            //updateUI();
                        }
                    }
                });
    }

    protected void broadcastLocationResponse(boolean isSuccess) {
        for (OnRequestLocationReady listner : listRequestLocationWaiting) {
            listner.OnRequestLocationResponse(isSuccess);
        }
        listRequestLocationWaiting.clear();
    }

    protected void startRequestLocationAddress() {
        Intent intent = new Intent(this, FetchAddressIntentService.class);
        mResultReceiver = new AddressResultReceiver(handler);
        intent.putExtra(FetchAddressIntentService.RECEIVER, mResultReceiver);
        intent.putExtra(FetchAddressIntentService.LOCATION_DATA_EXTRA, mCurrentlocation);
        startService(intent);
    }

    @NonNull
    @Override
    public ViewState createViewState() {

        return new RestorableViewState() {
            @Override
            public void saveInstanceState(@NonNull Bundle out) {
            }

            @Override
            public RestorableViewState restoreInstanceState(Bundle in) {
                return null;
            }

            @Override
            public void apply(MvpView view, boolean retained) {
            }
        };
    }

    @Override
    public void onBackPressed() {
        int overlayFragmentCount = fragmentOverlayNames.size();
        if (overlayFragmentCount > 0) {
            String tag = fragmentOverlayNames.peek();
            Fragment fragment = getSupportFragmentManager().findFragmentByTag(
                    tag);
            if (fragment != null) {
                if (fragment instanceof BackPressedInterceptor) {
                    if (((BackPressedInterceptor) fragment).onBackPressed()) {
                        return;
                    }
                }
                popOverlayFragment();
                return;
            }
        }

        int fragmentCount = fragmentNames.size();
        if (fragmentCount > 1) {
            String tag = fragmentNames.peek();
            Fragment fragment = getSupportFragmentManager().findFragmentByTag(
                    tag);
            if (fragment != null) {
                if (fragment instanceof BackPressedInterceptor) {
                    if (((BackPressedInterceptor) fragment).onBackPressed()) {
                        return;
                    }
                }
                popFragment();
                return;
            }
        }

        finish();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        /*if(fragment instanceof MainActivity.IOnFocusListenable) {
            ((MainActivity.IOnFocusListenable) fragment).dispatchTouchEvent(ev);
        }
        return blockAllTouchEvent || super.dispatchTouchEvent(ev);*/
        return blockAllTouchEvent || super.dispatchTouchEvent(ev);
    }

    class AddressResultReceiver extends ResultReceiver {
        public AddressResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {
            showLoading(false);
            if (resultData == null) {
                broadcastLocationResponse(false);
                return;
            }

            CurrentAddressModel = (AddressModel) resultData.getSerializable(FetchAddressIntentService.RESULT_DATA_KEY);
            broadcastLocationResponse(true);
        }
    }

    public interface OnRequestLocationReady {
        public void OnRequestLocationResponse(boolean isSuccess);
    }
}
