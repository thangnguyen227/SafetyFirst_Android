
package com.dichvudacbiet.safetyfirst.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;
import com.dichvudacbiet.safetyfirst.util.AlertUtil;

import java.util.List;


public class HealthReviewAdapter extends  RecyclerView.Adapter<HealthReviewAdapter.MyViewHolder>
        implements View.OnClickListener {
    private Activity mContext;
    private List<HealthCareActivateModel> healthList;
    private RecyclerView rvList;
    protected RecyclerViewOnItemClickedListener<HealthCareActivateModel> listener;

    public void setListNews(List<HealthCareActivateModel> listNews) {
        this.healthList = listNews;
    }

    public List<HealthCareActivateModel> getListNews() {
        return healthList;
    }

    public void setOnItemClickListener(RecyclerViewOnItemClickedListener<HealthCareActivateModel> listener) {
        this.listener = listener;
    }

    public HealthReviewAdapter(Activity context, List<HealthCareActivateModel> healthModelList) {
        mContext = context;
        this.healthList = healthModelList;
    }

    @Override
    public void onClick(View v) {
        View containingView = rvList.findContainingItemView(v);
        int position = rvList.getChildAdapterPosition(containingView);
        if (position == RecyclerView.NO_POSITION) {
            return;
        }

        if (listener != null) {
            listener.onItemClicked(rvList, healthList.get(position), position);
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public TextView datetime;
        public TextView info;
        public Button btn_review;
        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.item_tvTitle);
            datetime = (TextView) view.findViewById(R.id.item_datetime);
            info = (TextView) view.findViewById(R.id.item_info);
            btn_review = view.findViewById(R.id.btn_review);
        }
    }




    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_health, parent, false);
        itemView.setOnClickListener(this);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        HealthCareActivateModel health = healthList.get(position);
        holder.title.setText("Hoạt động: "+health.activity.name);
        holder.datetime.setText("Thời gian: "+health.time);
        holder.info.setText("Thông tin: "+health.note);
        holder.btn_review.setOnClickListener(v->{
            AlertUtil.showHealthCareReviewDialog(mContext,position,healthList, this);
        });

    }

    @Override
    public int getItemCount() {
        return healthList.size();
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        rvList = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        rvList = null;
        super.onDetachedFromRecyclerView(recyclerView);
    }

}
