
package com.dichvudacbiet.safetyfirst.presenter;

import android.util.Log;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.base.Constants;
import com.dichvudacbiet.safetyfirst.fragment.ProfileInfoFragment;
import com.dichvudacbiet.safetyfirst.model.EssentialPhone;
import com.dichvudacbiet.safetyfirst.model.JobModel;
import com.dichvudacbiet.safetyfirst.model.QuestionModel;
import com.dichvudacbiet.safetyfirst.model.Relation2Model;
import com.dichvudacbiet.safetyfirst.model.RelationModel;
import com.dichvudacbiet.safetyfirst.model.UserInfo;
import com.dichvudacbiet.safetyfirst.model.network.JobRequest;
import com.dichvudacbiet.safetyfirst.model.network.QuestionRequest;
import com.dichvudacbiet.safetyfirst.model.network.RelationRequest;
import com.dichvudacbiet.safetyfirst.model.network.UpdateProfileRequest;
import com.dichvudacbiet.safetyfirst.model.network.UserRepoModel;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.ProfileEditView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ProfileEditPresenter extends BasePresenter<ProfileEditView> {

    private ProfileInfoFragment.PromotionTabType jobTabType;
    private int currentPage = 1;
    private Constants.LoadDataState loadDataState = Constants.LoadDataState.NONE;

    public ProfileEditPresenter(ProfileInfoFragment.PromotionTabType jobTabType) {
        this.jobTabType = jobTabType;
    }

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();

        }
    }

    public void onUpdateInfo(String name, String address, String phone, String mobile, int job_id, ArrayList<RelationModel> relations) {
        if (isViewAttached()) {
            int errMsg = validateInput(name, address, phone, mobile);
            if (errMsg != -1) {
                getView().showMessage(errMsg, false);
                return;
            }
            onUpdateInfoServer(name, address, phone, mobile, job_id, relations);
        }
    }

    public void onUpdateGuaranteePhone(EssentialPhone essPhone) {
        PrefUtil.setEssentialPhone(essPhone);
    }

    public void onUpdateInfoServer(String name, String address, String phone, String mobile, int job_id, ArrayList<RelationModel> relations) {
        if (isViewAttached()) {
            Object mData = UpdateProfileRequest.newBuilder()
                    .user_id(PrefUtil.getUserInfo().id).name(name).address(address).phone(phone).mobile(mobile)
                    .fcm_token(PrefUtil.getDeviceInfo().deviceId).job_id(job_id).language_code(Util.getLangCode())
                    .relations(relations);
            Call<UserRepoModel> call = ApiService.getClient().getUpdate(PrefUtil.getUserInfo().id,PrefUtil.getTokenInfo(), mData);
            call.enqueue(new Callback<UserRepoModel>() {
                @Override
                public void onResponse(Call<UserRepoModel> call, Response<UserRepoModel> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            UserInfo respondData = response.body().data;
                            if (respondData != null) {
                                PrefUtil.setUserInfo(respondData);
                                Session.userInfo = PrefUtil.getUserInfo();
                                getView().showMessage("Cập nhật thành công", false);
                                getView().showRelationAfterCreate();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        getView().showMessage("Lỗi kết nối dữ liệu", false);
                    }

                }

                @Override
                public void onFailure(Call<UserRepoModel> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu", false);
                }
            });
        }
    }



    public void loadJob() {
        if (isViewAttached()) {

            Call<JobRequest> call = ApiService.getClient().getJobs(PrefUtil.getTokenInfo(),Util.getLangCode());

            call.enqueue(new Callback<JobRequest>() {
                @Override
                public void onResponse(Call<JobRequest> call, Response<JobRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<JobModel> respondData =  response.body().data;
                            getView().showJobs(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<JobRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }

    public void onCreateRelation(ArrayList<RelationModel> data) {

        if (isViewAttached()) {
           ArrayList<RelationModel>  mData = data;
            Call<RelationRequest> call = ApiService.getClient().createUserRelation(PrefUtil.getTokenInfo(), mData.get(0));
            call.enqueue(new Callback<RelationRequest>() {
                @Override
                public void onResponse(Call<RelationRequest> call, Response<RelationRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {

                                getView().showMessage("Tạo thành công", false);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        getView().showMessage("Lỗi kết nối dữ liệu " + response.message(), false);
                    }

                }

                @Override
                public void onFailure(Call<RelationRequest> call, Throwable t) {
                    Log.d("//////",t.getMessage());
                    getView().showMessage("Lỗi kết nối dữ liệu "+ t.getMessage(), false);
                }
            });
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            unsubscribeAllSubscriptions();
            loadDataState = Constants.LoadDataState.NEW;

            switch (jobTabType) {
                case PROMOTION:
                    Session.userInfo = PrefUtil.getUserInfo();
                    getView().displayProfile();
                    loadJob();
                    break;
                case GUARANTEES:
                    if (isViewAttached()) {
                        Session.userInfo = PrefUtil.getUserInfo();
                        getView().displayGuarantee();
                        loadQuestions();
                    }
                    break;
                case RELATIVES:
                    if (isViewAttached()) {
                        Session.userInfo = PrefUtil.getUserInfo();
                        getView().displayRelations(Session.userInfo.relations);
                        loadRelation(1);
                    }
                    break;
            }

        }
    }

    private void loadQuestions() {
        if (isViewAttached()) {

            Call<QuestionRequest> call = ApiService.getClient().getQuestion(PrefUtil.getTokenInfo() , Session.COUNTRY_CODE);
            call.enqueue(new Callback<QuestionRequest>() {
                @Override
                public void onResponse(Call<QuestionRequest> call, Response<QuestionRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<QuestionModel> respondData =  response.body().data;
                            getView().showListQuestions(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<QuestionRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }
    public void loadRelation(int type) {
        if (isViewAttached()) {

            Call<RelationRequest> call = ApiService.getClient().getRelation(Util.getLangCode());
            call.enqueue(new Callback<RelationRequest>() {
                @Override
                public void onResponse(Call<RelationRequest> call, Response<RelationRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<Relation2Model> respondData =  response.body().data;
                            getView().showRelation(respondData,type);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<RelationRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }

    private void loadAllDataSchedule() {
//
//        // Trip
//        Call<SchedueRequest> call = ApiService.getClient().getSchedueListUser(PrefUtil.getTokenInfo() , PrefUtil.getUserInfo().id);
//        call.enqueue(new Callback<SchedueRequest>() {
//            @Override
//            public void onResponse(Call<SchedueRequest> call, Response<SchedueRequest> response) {
//
//                if (response.isSuccessful()) {
//                    //RC4
//                    try {
//                        ArrayList<ScheduleModel> respondData =  response.body().data;
//                        getView().showDataListSchedue(respondData);
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//
//                }else{
//                    getView().showMessage("Lỗi kết nối dữ liệu", false);
//                }
//
//            }
//            @Override
//            public void onFailure(Call<SchedueRequest> call, Throwable t) {
//                getView().showMessage("Lỗi kết nối dữ liệu", false);
//            }
//        });
//
//        //Health care
//
//        Call<HealthCareActivateRequest> call1 = ApiService.getClient().getHealthCareActivities(PrefUtil.getTokenInfo());
//        call1.enqueue(new Callback<HealthCareActivateRequest>() {
//            @Override
//            public void onResponse(Call<HealthCareActivateRequest> call1, Response<HealthCareActivateRequest> response) {
//
//                if (response.isSuccessful()) {
//                    //RC4
//                    try {
//                        ArrayList<HealthCareActivateModel> respondData =  response.body().data;
//                        getView().showDataListHealth(respondData);
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//
//                }else{
//                    getView().showMessage("Lỗi kết nối dữ liệu", false);
//                }
//
//            }
//            @Override
//            public void onFailure(Call<HealthCareActivateRequest> call1, Throwable t) {
//                getView().showMessage("Lỗi kết nối dữ liệu", false);
//            }
//        });
//
//        // Vaccin
//
//        Call<VaccinRequest> call2 = ApiService.getClient().getUserVaccinationInfo(PrefUtil.getTokenInfo());
//        call2.enqueue(new Callback<VaccinRequest>() {
//            @Override
//            public void onResponse(Call<VaccinRequest> call2, Response<VaccinRequest> response) {
//
//                if (response.isSuccessful()) {
//                    //RC4
//                    try {
//                        ArrayList<VaccinModel> respondData =  response.body().data;
//                        getView().showDataListVaccin(respondData);
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//
//                }else{
//                    getView().showMessage("Lỗi kết nối dữ liệu huhu", false);
//                }
//
//            }
//            @Override
//            public void onFailure(Call<VaccinRequest> call2, Throwable t) {
//                getView().showMessage("Lỗi kết nối dữ liệu huhu ", false);
//                Log.d("//////",t.getMessage());
//            }
//        });
    }

    private int validateInput(String name, String address, String phone, String mobile) {
        if (Util.isNullOrEmpty(name) || Util.isNullOrEmpty(address) || Util.isNullOrEmpty(phone)
                || Util.isNullOrEmpty(mobile)) {
            return R.string.please_fill_all_input;
        }
        return -1;
    }
}
