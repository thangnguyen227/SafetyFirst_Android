
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.ScheduleModel;

import java.util.List;

public interface TripView extends BaseView {
    void navigateBack();
    void setData(List<ScheduleModel> listNews);
    void showCreateSchedule(ScheduleModel scheduleModel);
}
