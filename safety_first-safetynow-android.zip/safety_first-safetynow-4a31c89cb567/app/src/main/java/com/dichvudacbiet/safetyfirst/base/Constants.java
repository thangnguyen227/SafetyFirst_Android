package com.dichvudacbiet.safetyfirst.base;

import com.dichvudacbiet.safetyfirst.R;

public class Constants {

    public static final String ENCRYPT_KEY = "18d38d09f1fb4d0862bb6a4aa67aa90c";
    public static final int TRANSITION_DURATION = 300;
    public static final int CAMERA_REQUEST_CODE = 1000;
    public static final int IMAGE_PICKER_REQUEST_CODE = 1001;

    public class Value {
        public static final int DEFAULT_LANGUAGE_ID = 0;
    }

    public enum TransitionType {
        NONE(R.anim.stand_still, R.anim.stand_still, R.anim.stand_still, R.anim.stand_still),
        SLIDE_IN_RIGHT_TO_LEFT(R.anim.slide_in_right, R.anim.slide_out_left, R.anim.slide_in_left, R.anim.slide_out_right),
        SLIDE_IN_LEFT_TO_RIGHT(R.anim.slide_in_left, R.anim.slide_out_right, R.anim.slide_in_right, R.anim.slide_out_left),
        SLIDE_IN_BOTTOM(R.anim.slide_in_bottom, R.anim.stand_still, R.anim.stand_still, R.anim.slide_out_bottom),
        CROSS_FADE(R.anim.fade_in, R.anim.fade_out, R.anim.fade_in, R.anim.fade_out);

        public int enter;
        public int exit;
        public int popEnter;
        public int popExit;

        TransitionType(int enter, int exit, int popEnter, int popExit) {
            this.enter = enter;
            this.exit = exit;
            this.popEnter = popEnter;
            this.popExit = popExit;
        }
    }

    public enum LoadDataState {
        NONE,
        NEW,
        MORE
    }

    public static final int SUPPORT_MEDICAL = 0;
    public static final int SUPPORT_ASSOCIATION = 5;
    public static final int SUPPORT_EMBASSY = 2;
    public static final int SUPPORT_TRAVEL_AGENT = 3;
    public static final int SUPPORT_RESCUE_TEAM = 4;
    public static final int SUPPORT_POLY_TEAM = 1;
    public static final int SUPPORT_RESTAURANT_SHOPPING = 6;
    public static final int SUPPORT_FOOLS_STUFFS = 7;
    public static final int SUPPORT_BMI = 8;

}
