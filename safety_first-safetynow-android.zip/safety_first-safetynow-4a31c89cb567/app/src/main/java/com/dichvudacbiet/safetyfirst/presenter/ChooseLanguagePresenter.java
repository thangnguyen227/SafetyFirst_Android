
package com.dichvudacbiet.safetyfirst.presenter;


import com.dichvudacbiet.safetyfirst.util.LanguageUtils;
import com.dichvudacbiet.safetyfirst.view.ChooseLanguageView;

import org.greenrobot.eventbus.EventBus;


public class ChooseLanguagePresenter extends BasePresenter<ChooseLanguageView> {
    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()){
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            getView().setData(LanguageUtils.getLanguageData());
        }
    }

    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }

    @Override
    public void detachView(boolean retainInstance) {
        EventBus.getDefault().unregister(this);
        super.detachView(retainInstance);
    }
}
