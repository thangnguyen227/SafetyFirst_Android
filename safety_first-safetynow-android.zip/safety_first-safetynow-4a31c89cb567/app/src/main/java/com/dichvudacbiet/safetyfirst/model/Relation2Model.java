package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 12/12/17.
 */

public class Relation2Model {
    public int id;
    public String name;
    public String phone;
    public String mobile;
    public String relation_type;
}
