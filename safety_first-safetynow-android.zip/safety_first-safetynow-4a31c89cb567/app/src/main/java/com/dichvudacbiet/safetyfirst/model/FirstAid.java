package com.dichvudacbiet.safetyfirst.model;

import java.util.ArrayList;

public class FirstAid {
    public ArrayList<RescueSkillModel> data;
}
