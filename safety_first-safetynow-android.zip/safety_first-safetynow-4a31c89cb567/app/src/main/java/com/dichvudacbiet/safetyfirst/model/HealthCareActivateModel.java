package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by khant on 11/03/2018.
 */

public class HealthCareActivateModel {
    public int id;
    public int activity_id;
    public String plain_text;
    public String name;
    public String time;
    public String note;
    public HealthCareActivateModel activity;
    public HealthCareActivateModel(int activity_id,String plain_text,String date_time,String info ){
        this.activity_id = activity_id;
        this.plain_text = plain_text;
        this.time = date_time;
        this.note = info;
    }

}
