
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.base.SafetyApplication;
import com.dichvudacbiet.safetyfirst.model.ServiceModel;
import com.dichvudacbiet.safetyfirst.view.ChooseServiceView;

import java.util.ArrayList;
import java.util.List;


public class ChooseServicePresenter extends BasePresenter<ChooseServiceView> {

    private List<ServiceModel> serviceModelList = new ArrayList<>();
    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            if(serviceModelList.size() <= 0){
                ServiceModel service = new ServiceModel(SafetyApplication.self().getString(R.string.trip_schedule));
                serviceModelList.add(service);
                ServiceModel service1 = new ServiceModel(SafetyApplication.self().getString(R.string.healthy_schedule));
                serviceModelList.add(service1);
                ServiceModel service2 = new ServiceModel(SafetyApplication.self().getString(R.string.vaccination_kid_schedule));
                serviceModelList.add(service2);
                ServiceModel service3 = new ServiceModel(SafetyApplication.self().getString(R.string.bmi_score));
                serviceModelList.add(service3);
                getView().setData(serviceModelList);
            }else{
                getView().setData(serviceModelList);
            }
        }
    }

    public void onNewsClicked(ServiceModel news, int position) {
        if (isViewAttached()) {
            getView().showServicePage(position);
        }
    }

    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
