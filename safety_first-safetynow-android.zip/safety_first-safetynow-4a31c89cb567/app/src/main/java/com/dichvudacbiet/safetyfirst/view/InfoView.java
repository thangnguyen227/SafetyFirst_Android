
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.SupportModel;

import java.util.ArrayList;
import java.util.List;

public interface InfoView extends BaseView {
    void navigateBack();
    void showNational(int pos);
    void setData(List<SupportModel> listNews);
    void setCountryData(ArrayList<LocationModel> listNews);
    void setProvinceData(ArrayList<LocationModel> listNews);
    void showCoveringList(ArrayList<LocationModel> listNews);
    void navigateToBMI();
    void showSOS();
}
