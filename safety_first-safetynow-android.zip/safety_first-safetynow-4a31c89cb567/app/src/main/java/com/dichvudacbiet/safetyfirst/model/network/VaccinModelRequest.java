package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.VaccinInfoModel;

import java.util.List;

/**
 * Created by khant on 14/03/2018.
 */

public class VaccinModelRequest {
    public String fullname;
    public int gender;
    public String birth_date;
    public String birth_weight;
    public String birth_height;
    public List<VaccinInfoModel> vaccinations;

    public VaccinModelRequest(Builder builder) {
        fullname = builder.fullname;
        gender = builder.gender;
        birth_date = builder.birth_date;
        birth_weight = builder.birth_weight;
        birth_height = builder.birth_height;
        vaccinations = builder.vaccinations;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private String fullname;
        private int gender;
        private String birth_date;
        private String birth_weight;
        private String birth_height;
        public List<VaccinInfoModel> vaccinations;
        private Builder() {
        }

        public Builder name(String val) {
            fullname = val;
            return this;
        }

        public Builder gender(int val) {
            gender = val;
            return this;
        }

        public Builder birthday(String val) {
            birth_date = val;
            return this;
        }

        public Builder birth_weight(String val) {
            birth_weight = val;
            return this;
        }

        public Builder birth_height(String val) {
            birth_height = val;
            return this;
        }

        public Builder vaccinations(List<VaccinInfoModel> val) {
            vaccinations = val;
            return this;
        }

        public VaccinModelRequest build() {
            return new VaccinModelRequest(this);
        }
    }
}
