
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.JobModel;
import com.dichvudacbiet.safetyfirst.model.QuestionModel;
import com.dichvudacbiet.safetyfirst.model.Relation2Model;
import com.dichvudacbiet.safetyfirst.model.RelationModel;

import java.util.ArrayList;
import java.util.List;

public interface ProfileEditView extends BaseView {

    void displayProfile();
    void displayGuarantee();
    void displayRelations(List<RelationModel> relationModels);
    void createRelations();
    void showRelation(ArrayList<Relation2Model> relation2Models,int type);
    void showJobs(ArrayList<JobModel> jobs);
    void showRelationAfterCreate();
    void showListQuestions(ArrayList<QuestionModel> questionModels);
}
