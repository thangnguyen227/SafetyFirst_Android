
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.SupportModel;
import com.dichvudacbiet.safetyfirst.presenter.RescueDetailPresenter;
import com.dichvudacbiet.safetyfirst.view.RescueDetailView;

import java.util.ArrayList;
import java.util.List;


public class RescueDetailFragment extends BaseFragment<RescueDetailView, RescueDetailPresenter>
        implements RescueDetailView, View.OnClickListener, RecyclerViewOnItemClickedListener<SupportModel> {


    private TextView mToolbarTitle;
    private String fileName;
    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_detail_rescue;
    }


    public static RescueDetailFragment newInstance(String file) {
        Bundle args = new Bundle();
        args.putString("FILE", file);
        RescueDetailFragment fragment = new RescueDetailFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);

        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.view_detail));
        mToolbarTitle.setVisibility(View.VISIBLE);

        if(getArguments()!= null){
            fileName = getArguments().getString("FILE");
        }


        //String url = "file:///android_asset/"+fileName;
        WebView webView = view.findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(false);
        webView.loadData(fileName , "text/html", "UTF-8");
        webView.setWebViewClient(new MyBrowser());
    }


    private class MyBrowser extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }



    @Override
    public RescueDetailPresenter createPresenter() {
        return new RescueDetailPresenter();
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id){
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
        }

    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, SupportModel supportModel, int position) {

    }

    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void showNational(int pos) {

    }

    @Override
    public void setData(List<SupportModel> listNews) {

    }

    @Override
    public void setCountryData(ArrayList<LocationModel> listNews) {

    }

    @Override
    public void setProvinceData(ArrayList<LocationModel> listNews) {

    }

    @Override
    public void showCoveringList(ArrayList<LocationModel> listNews) {

    }

    @Override
    public void navigateToBMI() {

    }

    @Override
    public void showSOS() {

    }
}
