package com.dichvudacbiet.safetyfirst.model.network;

public class OtherQuestionRequest {

    public String name;
    public String info;
    private OtherQuestionRequest(Builder builder) {
        name = builder.name;
        info = builder.info;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private String name;
        private String info;

        private Builder() {
        }

        public Builder name(String val) {
            name = val;
            return this;
        }

        public Builder info(String val) {
            info = val;
            return this;
        }
        public OtherQuestionRequest build() {
            return new OtherQuestionRequest(this);
        }
    }
}
