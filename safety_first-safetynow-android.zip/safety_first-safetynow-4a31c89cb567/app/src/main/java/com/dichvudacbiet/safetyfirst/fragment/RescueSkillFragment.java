
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.adapter.RescueSkillAdapter;
import com.dichvudacbiet.safetyfirst.model.RescueSkillModel;
import com.dichvudacbiet.safetyfirst.presenter.RescueSkillPresenter;
import com.dichvudacbiet.safetyfirst.view.RescueSkillView;

import java.util.List;


public class RescueSkillFragment extends BaseFragment<RescueSkillView, RescueSkillPresenter>
        implements RescueSkillView, View.OnClickListener , RecyclerViewOnItemClickedListener<RescueSkillModel> {

    private RecyclerView rvList;
    private RescueSkillAdapter adapter;
    private TextView mToolbarTitle;

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_medical;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);
        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.first_aid));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //

        adapter = new RescueSkillAdapter();
        adapter.setOnItemClickListener(this);
        rvList = (RecyclerView) view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));

    }

    @NonNull
    @Override
    public RescueSkillPresenter createPresenter() {
        return new RescueSkillPresenter();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;

        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }


    @Override
    public void setData(List<RescueSkillModel> listNews) {

        adapter.setListNews(listNews);
        adapter.notifyDataSetChanged();
        rvList.setAdapter(adapter);
    }

    @Override
    public void showDetail(String fileName) {
        Fragment fragment = RescueDetailFragment.newInstance(fileName);
        ((BaseActivity) getActivity()).pushFragment(fragment, true);
    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, RescueSkillModel rescueModel, int position) {
        getPresenter().onNewsClicked(rescueModel, position);
    }

}
