
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.adapter.VaccinInfoReviewAdapter;
import com.dichvudacbiet.safetyfirst.model.VaccinModel;
import com.dichvudacbiet.safetyfirst.presenter.VaccinPresenter;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.view.VaccinView;

import java.util.ArrayList;
import java.util.List;


public class VaccinFragment extends BaseFragment<VaccinView, VaccinPresenter>
        implements VaccinView, View.OnClickListener , RecyclerViewOnItemClickedListener<VaccinModel> {

    private RecyclerView rvList;

    private VaccinInfoReviewAdapter vaccin_adapter;

    private TextView mToolbarTitle;

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_list_schedule_general;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);

        ImageButton btnSos = (ImageButton) view.findViewById(R.id.top_bar_btnRight);
        btnSos.setImageResource(R.drawable.ic_add_black_24dp);
        btnSos.setOnClickListener(this);

        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.vaccination_schedule_page));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //

        vaccin_adapter = new VaccinInfoReviewAdapter(getActivity(),new ArrayList<>());
        vaccin_adapter.setOnItemClickListener(this);
        rvList = (RecyclerView) view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rvList.setAdapter(vaccin_adapter);
    }

    @NonNull
    @Override
    public VaccinPresenter createPresenter() {
        return new VaccinPresenter();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
            case R.id.top_bar_btnRight:
                Session.VACCIN_UPDATE_OR_CREATE = 0 ;
                ((BaseActivity) getActivity()).pushFragment(new CreateVaccinSerivceFragment(), true);
                break;
        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }



    @Override
    public void setData(List<VaccinModel> listNews) {
        vaccin_adapter.setListNews(listNews);
        vaccin_adapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, VaccinModel vaccinModel, int position) {
        Session.vaccinModel = vaccinModel;
        Session.VACCIN_UPDATE_OR_CREATE = 1;
        ((BaseActivity) getActivity()).pushFragment(new CreateVaccinSerivceFragment(), true);
    }


}
