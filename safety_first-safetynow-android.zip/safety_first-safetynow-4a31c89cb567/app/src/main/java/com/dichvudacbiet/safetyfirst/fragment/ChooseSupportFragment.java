
package com.dichvudacbiet.safetyfirst.fragment;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.CountrySpinnerAdapter;
import com.dichvudacbiet.safetyfirst.adapter.ProvinceSpinnerAdapter;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.adapter.SupportAdapter;
import com.dichvudacbiet.safetyfirst.model.AddressModel;
import com.dichvudacbiet.safetyfirst.model.LocationModel;
import com.dichvudacbiet.safetyfirst.model.SupportModel;
import com.dichvudacbiet.safetyfirst.presenter.ChooseSupportPresenter;
import com.dichvudacbiet.safetyfirst.view.ChooseSupportView;

import java.util.ArrayList;
import java.util.List;


public class ChooseSupportFragment extends BaseFragment<ChooseSupportView, ChooseSupportPresenter>
        implements ChooseSupportView, BaseActivity.IOnFocusListenable, View.OnClickListener,
        RecyclerViewOnItemClickedListener<SupportModel>, BaseActivity.OnRequestLocationReady {

    private RecyclerView rvList;
    private SupportAdapter adapter;
    private Spinner spn_country, spn_province , mSpinerAddress;
    private CountrySpinnerAdapter countryAdapter;
    private ProvinceSpinnerAdapter provinceAdapter, coverAdapter;
    private TextView mToolbarTitle;
    private int countryId = -1;
    private int mIdAddress;
    //lấy điểm "X", "Y" trên màn hình của rating_bar.
    private Point point;
    private RatingBar ratingBar;


    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_choose_suport;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);


        ImageButton btnSos = (ImageButton) view.findViewById(R.id.top_bar_btnRight);
        btnSos.setImageResource(R.drawable.sos_icon);
        btnSos.setVisibility(View.GONE);
        btnSos.setOnClickListener(this);

        TextView tvSos =  view.findViewById(R.id.top_bar_tvRight);
        tvSos.setText(R.string.name_sos_message);
        tvSos.setVisibility(View.VISIBLE);
        tvSos.setOnClickListener(this);


        //
        spn_country = view.findViewById(R.id.spn_country);
        countryAdapter = new CountrySpinnerAdapter(getContext());
        spn_country.setAdapter(countryAdapter);
        spn_country.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                getPresenter().loadDataProvince((int) id);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        //
        spn_province = view.findViewById(R.id.spn_province);
        provinceAdapter = new ProvinceSpinnerAdapter(getContext());
        spn_province.setAdapter(provinceAdapter);

        spn_province.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                getPresenter().loadDataAddress((int) id);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        mSpinerAddress = view.findViewById(R.id.sp_address);
        coverAdapter = new ProvinceSpinnerAdapter(getContext());
        mSpinerAddress.setAdapter(coverAdapter);
        mSpinerAddress.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mIdAddress = coverAdapter.getItem(position).id;
                ratingBar.setRating(coverAdapter.getItem(position).safety_rating);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.support_page));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //

        adapter = new SupportAdapter();
        adapter.setOnItemClickListener(this);
        rvList = (RecyclerView) view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rvList.setAdapter(adapter);

        //
        ratingBar = view.findViewById(R.id.rating_bar);
        ratingBar.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    showPopup(getActivity(), point);
                }
                return true;
            }
        });

    }

    private void showPopup(final Activity context, Point p) {

        // Inflate the popup_layout.xml
        LinearLayout viewGroup = (LinearLayout) context.findViewById(R.id.popup);
        LayoutInflater layoutInflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = layoutInflater.inflate(R.layout.popup_layout, viewGroup);

        // Creating the PopupWindow
        final PopupWindow popup = new PopupWindow(context);
        popup.setContentView(layout);
        popup.setFocusable(true);
        popup.setBackgroundDrawable(new BitmapDrawable());
        popup.setOutsideTouchable(true);
        // Some offset to align the popup a bit to the right, and a bit down, relative to button's position.
        int OFFSET_X = -200;
        int OFFSET_Y = 30;

        // Clear the default translucent background
        popup.setBackgroundDrawable(new BitmapDrawable());

        // Displaying the popup at the specified location, + offsets.
        popup.showAtLocation(layout, Gravity.NO_GRAVITY, p.x + OFFSET_X, p.y + OFFSET_Y);

        // Getting a reference to Close button, and close the popup when clicked.


    }


    @NonNull
    @Override
    public ChooseSupportPresenter createPresenter() {
        return new ChooseSupportPresenter();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
            case R.id.top_bar_tvRight:
                showSOS();
                break;
        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void showNational(int type) {
        Fragment fragment = MedicalListFragment.newInstance(type, mIdAddress);
        ((BaseActivity) getActivity()).pushOverlayFragment(fragment, true);
    }

    @Override
    public void setData(List<SupportModel> listNews) {
        adapter.setListNews(listNews);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void setCountryData(ArrayList<LocationModel> listNews) {
        countryAdapter.setNewList(listNews);
        countryAdapter.notifyDataSetChanged();

        BaseActivity baseActivity = (BaseActivity) getActivity();
        AddressModel addressModel = baseActivity.CurrentAddressModel;
        if (addressModel != null) {
            for (int i = 0; i < listNews.size(); i++) {
                LocationModel locationModel = listNews.get(i);
                if (locationModel.code.equals(addressModel.countryCode)) {
                    spn_country.setSelection(i);
                    break;
                }
            }

        }
    }

    private void initCurrentAddress(Spinner view, ArrayList<LocationModel> listData, String currentLocation) {
        for (int i = 0; i < listData.size(); i++) {
            LocationModel locationModel = listData.get(i);
            if (locationModel.name.contains(currentLocation)) {
                view.setSelection(i);
                break;
            }

        }
    }

    @Override
    public void setProvinceData(ArrayList<LocationModel> listNews) {
        provinceAdapter.setNewList(listNews);
        provinceAdapter.notifyDataSetChanged();

        BaseActivity baseActivity = (BaseActivity) getActivity();
        AddressModel addressModel = baseActivity.CurrentAddressModel;
        if (addressModel != null) {
            initCurrentAddress(spn_province, listNews, addressModel.adminArea);
        }
    }


    @Override
    public void showCoveringList(ArrayList<LocationModel> listNews) {
        coverAdapter.setNewList(listNews);
        coverAdapter.notifyDataSetChanged();

        BaseActivity baseActivity = (BaseActivity) getActivity();
        AddressModel addressModel = baseActivity.CurrentAddressModel;
        if (addressModel != null) {
            initCurrentAddress(mSpinerAddress, listNews, addressModel.subAdminArea);
        }
    }

    @Override
    public void navigateToBMI() {
        Fragment fragment = new BMIFragment();
        ((BaseActivity) getActivity()).pushFragment(fragment, true);
    }

    @Override
    public void showSOS() {
        Fragment fragment = new SosFragment();
        ((BaseActivity) getActivity()).pushFragment(fragment, true);
    }

    @Override
    public void showLoading(boolean isShow) {
        BaseActivity baseActivity = (BaseActivity)getActivity();
        baseActivity.showLoading(isShow);
    }

    @Override
    public void loadCurrentLocation() {
        BaseActivity baseActivity = (BaseActivity) getActivity();
        baseActivity.requestLocationService(this);
    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, SupportModel supportModel, int position) {
        getPresenter().onNewsClicked(supportModel, position);
    }



    @Override
    public void dispatchTouchEvent(MotionEvent ev) {

        int[] location = new int[2];

        // Get the x, y location and store it in the location[] array
        // location[0] = x, location[1] = y.
        ratingBar.getLocationOnScreen(location);
        //Initialize the Point with x, and y positions
        point = new Point();
        point.x = location[0];
        point.y = location[1];
    }

    @Override
    public void OnRequestLocationResponse(boolean isSuccess) {
        getPresenter().onLoadLocationCallback();
    }
}
