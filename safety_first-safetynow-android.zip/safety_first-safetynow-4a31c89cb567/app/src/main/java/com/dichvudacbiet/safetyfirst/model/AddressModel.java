package com.dichvudacbiet.safetyfirst.model;

import java.io.Serializable;

public class AddressModel implements Serializable {
    public String address; // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
    public String city;
    public String adminArea;
    public String subAdminArea;
    public String countryName;
    public String countryCode;
    public String knownName;

    public String toString() {
        String st = "address:" + address + " city:" + city
                + " adminArea:" + adminArea + " subAdminArea:" + subAdminArea + " countryName:" + countryName
                + " countryCode:" + countryCode + " knownName:" + knownName;
        return st;
    }
}
