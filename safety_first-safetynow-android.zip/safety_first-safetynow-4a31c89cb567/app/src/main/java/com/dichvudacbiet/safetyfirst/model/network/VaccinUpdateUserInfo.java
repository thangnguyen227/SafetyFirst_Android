package com.dichvudacbiet.safetyfirst.model.network;

/**
 * Created by khant on 25/03/2018.
 */

public class VaccinUpdateUserInfo {
    public int i;

}
