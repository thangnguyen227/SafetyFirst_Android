package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by khant on 15/05/2018.
 */

public class UnreadNotificationCount {
    public int success;
    public int data;
}
