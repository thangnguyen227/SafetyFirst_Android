
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.model.EssentialPhone;
import com.dichvudacbiet.safetyfirst.model.QuestionModel;
import com.dichvudacbiet.safetyfirst.model.network.NetworkResponse;
import com.dichvudacbiet.safetyfirst.model.network.OtherQuestionRequest;
import com.dichvudacbiet.safetyfirst.model.network.QuestionRequest;
import com.dichvudacbiet.safetyfirst.model.network.QuestionsRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.QuestionsView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class QuestionsPresenter extends BasePresenter<QuestionsView> {

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
//            loadQuestions();
        }
    }

    private void loadQuestions() {
        if (isViewAttached()) {

            Call<QuestionRequest> call = ApiService.getClient().getQuestions(PrefUtil.getTokenInfo());
            call.enqueue(new Callback<QuestionRequest>() {
                @Override
                public void onResponse(Call<QuestionRequest> call, Response<QuestionRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<QuestionModel> respondData =  response.body().data;
                            getView().showListQuestions(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<QuestionRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });
        }
    }
    public void postQuestions(ArrayList<QuestionModel> questionModels){
        if (isViewAttached()) {
            if (isViewAttached()) {

                Object mData = QuestionsRequest.newBuilder().questions(questionModels);
                Call<QuestionRequest> call = ApiService.getClient().postQuestions(PrefUtil.getTokenInfo(),mData);
                call.enqueue(new Callback<QuestionRequest>() {
                    @Override
                    public void onResponse(Call<QuestionRequest> call, Response<QuestionRequest> response) {

                        if (response.isSuccessful()) {
                            getView().backToHome();
                        }else{
                            getView().showMessage("Lỗi tạo kết nối", false);
                        }

                    }
                    @Override
                    public void onFailure(Call<QuestionRequest> call, Throwable t) {
                        getView().showMessage("Lỗi tạo kết nối", false);
                    }
                });
            }
        }
    }
    public void postQuestionOthers(String data){
        if (isViewAttached()) {
            int errMsg = Util.validateInput(data);
            if(errMsg!=-1){
                getView().showMessage(errMsg, false);
                return;
            }
            if (isViewAttached()) {

                Object mData = OtherQuestionRequest.newBuilder().name("Nếu là khách du lịch đến địa phương của bạn, bạn khuyên nên ăn món đặc sản gì? ở đâu? mua gì mang về?").info(data);
                Call<NetworkResponse> call = ApiService.getClient().postOtherQuestions(PrefUtil.getTokenInfo(),mData);
                call.enqueue(new Callback<NetworkResponse>() {
                    @Override
                    public void onResponse(Call<NetworkResponse> call, Response<NetworkResponse> response) {

                        if (response.isSuccessful()) {
                            getView().backToHome();
                        }else{
                            getView().showMessage("Lỗi tạo kết nối", false);
                        }

                    }
                    @Override
                    public void onFailure(Call<NetworkResponse> call, Throwable t) {
                        getView().showMessage("Lỗi tạo kết nối", false);
                    }
                });
            }
        }
    }

    public void setOtherInformation(EssentialPhone phones){
        PrefUtil.setEssentialPhone(phones);
    }

    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }


}
