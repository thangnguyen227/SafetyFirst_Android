
package com.dichvudacbiet.safetyfirst.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.adapter.ProfilePagerAdapter;
import com.dichvudacbiet.safetyfirst.model.eventbus.ListJobsPageSelectedEvent;
import com.dichvudacbiet.safetyfirst.presenter.ProfileUserPresenter;
import com.dichvudacbiet.safetyfirst.view.ProfileUserView;

import org.greenrobot.eventbus.EventBus;


public class ProfileInfoFragment extends
        BaseFragment<ProfileUserView, ProfileUserPresenter> implements ProfileUserView,
        View.OnClickListener {
    private static Context context;
    private ProfilePagerAdapter pagerAdapter;
    private ViewPager viewPager;
    private TabLayout tabLayout;

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_profile;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        context = getContext();
        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);

        TextView tvTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        tvTitle.setVisibility(View.VISIBLE);
        tvTitle.setText(getString(R.string.personal_info));

        pagerAdapter = new ProfilePagerAdapter(getChildFragmentManager());
        viewPager = (ViewPager) view.findViewById(R.id.jobs_management_viewPager);
        viewPager.setAdapter(pagerAdapter);

        tabLayout = (TabLayout) view.findViewById(R.id.jobs_management_tabLayout);
        tabLayout.setupWithViewPager(viewPager);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            private ListJobsPageSelectedEvent event = new ListJobsPageSelectedEvent(0);

            @Override
            public void onPageScrolled(int position, float positionOffset,
                    int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                event.tabIndex = position;
                EventBus.getDefault().post(event);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @NonNull
    @Override
    public ProfileUserPresenter createPresenter() {
        return new ProfileUserPresenter();
    }

    @Override
    public void showMessage(int msgId, boolean success) {

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    public enum PromotionTabType {
        PROMOTION(context.getString(R.string.infomation)),
        GUARANTEES(context.getString(R.string.emergency)),
        RELATIVES(context.getString(R.string.relationship));
        String title;

        PromotionTabType(String title) {
            this.title = title;
        }

        public String getTitle() {
            return title;
        }
    }

}
