
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.model.MedicalModel;
import com.dichvudacbiet.safetyfirst.model.network.MedicalRequest;
import com.dichvudacbiet.safetyfirst.model.network.SupportRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.util.Util;
import com.dichvudacbiet.safetyfirst.view.MedicalListView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MedicalListPresenter extends BasePresenter<MedicalListView> {

    private int country_id = 0;
    private int mPos = 0;
    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }
    public MedicalListPresenter(int mPos,int country) {
        this.country_id = country;
        this.mPos = mPos;
    }
    private void loadData() {
        if (isViewAttached()) {
            Call<MedicalRequest> call = ApiService.getClient().getSupportInformation(mPos,country_id, PrefUtil.getTokenInfo(), Session.COUNTRY_CODE);

            call.enqueue(new Callback<MedicalRequest>() {
                @Override
                public void onResponse(Call<MedicalRequest> call, Response<MedicalRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<MedicalModel> respondData =  response.body().data;
                            getView().setData(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }else{
                        //Utility.showSnackBar(RegisterActivity.this, findViewById(android.R.id.content)  ,"Lỗi kết nối dữ liệu" );
                    }
                }
                @Override
                public void onFailure(Call<MedicalRequest> call, Throwable t) {
                    //Utility.showSnackBar(RegisterActivity.this, findViewById(android.R.id.content)  ,"Lỗi kết nối dữ liệu" );
                }
            });
        }
    }

    public void onNewsClicked(MedicalModel data) {
        if (isViewAttached()) {
            getView().openMedicalDetailView(data);
        }
    }

    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
