package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 12/12/17.
 */

public class RelationModel {
    public String user_id;

    public String relation_type_id;
    public String relation_type;
    public String fullname;
    public String phone_number;
    public String mobile_number;
    public Type type;
    public int type_id;

    public class Type{
        public int id;
        public String name;
    }


}
