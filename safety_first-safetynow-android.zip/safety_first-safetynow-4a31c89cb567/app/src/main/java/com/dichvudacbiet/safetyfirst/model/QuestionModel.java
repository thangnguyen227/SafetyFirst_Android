package com.dichvudacbiet.safetyfirst.model;

import java.util.ArrayList;

/**
 * Created by loi.doan on 12/18/17.
 */

public class QuestionModel {
    public int id;
    public String text = "";
    public String type = "";
    public ArrayList<OptionModel> options;
}
