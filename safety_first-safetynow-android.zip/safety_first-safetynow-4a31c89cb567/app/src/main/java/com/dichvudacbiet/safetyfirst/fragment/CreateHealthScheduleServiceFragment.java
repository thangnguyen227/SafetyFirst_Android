package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.adapter.HealthAdapter;
import com.dichvudacbiet.safetyfirst.model.HealthCareActivateModel;
import com.dichvudacbiet.safetyfirst.presenter.CreateHealthScheduleServicePresenter;
import com.dichvudacbiet.safetyfirst.util.AlertUtil;
import com.dichvudacbiet.safetyfirst.view.CreateHealthScheduleServiceView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by khant on 09/03/2018.
 */

public class CreateHealthScheduleServiceFragment extends BaseFragment<CreateHealthScheduleServiceView, CreateHealthScheduleServicePresenter>
        implements CreateHealthScheduleServiceView, View.OnClickListener {



    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_create_health_schedule_service;
    }



    private TextView mToolbarTitle;
    private TextView mDateFrom;
    private Spinner spnActType;
    private Button btn_create;
    private Button btn_done,btn_clear;
    private EditText edtInfo;
    private RecyclerView rvList;
    private HealthAdapter adapter;
    private LinearLayout ll_containList;
    List<HealthCareActivateModel> healthCareActivateModelList;
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.date_from:
                AlertUtil.showDateTimePickerDialog(getActivity().getSupportFragmentManager(),mDateFrom,false);
                break;

            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;
            case R.id.btn_create:
//                getPresenter().onCreateHeathCareActivity();
                break;
            case R.id.btn_done:
                String activateType = spnActType.getSelectedItem().toString();
                String date_time = mDateFrom.getText().toString();
                String info = edtInfo.getText().toString();
                int activity_id = healthCareActivateModelList.get(spnActType.getSelectedItemPosition()).id;
                getPresenter().onCreateHeathCareActivity(getPresenter().onCreateNewActivity(activity_id,activateType,date_time,info));
                break;
            case R.id.btn_clear:
//                getPresenter().onClearSchedule();
//                rvList.setAdapter(adapter);
                break;

        }
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //
        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);

        //
        edtInfo = view.findViewById(R.id.edtInfo);

        //
        btn_create = view.findViewById(R.id.btn_create);
        btn_create.setOnClickListener(this);
        btn_done = view.findViewById(R.id.btn_done);
        btn_done.setOnClickListener(this);
        btn_clear = view.findViewById(R.id.btn_clear);
        btn_clear.setOnClickListener(this);

        //
        mDateFrom = (TextView) view.findViewById(R.id.date_from);
        mDateFrom.setOnClickListener(this);
        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.create_healthy_schedule));
        mToolbarTitle.setVisibility(View.VISIBLE);

        //
        spnActType = view.findViewById(R.id.sp_actType);

        //
        adapter = new HealthAdapter(getActivity());
        rvList = (RecyclerView) view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));

        //
        ll_containList = view.findViewById(R.id.ll_containList);

    }


    @Override
    public CreateHealthScheduleServicePresenter createPresenter() {
        return new CreateHealthScheduleServicePresenter();
    }

    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void showActivityType(HealthCareActivateModel datas) {

    }

    @Override
    public void showActivityTitleType(List<HealthCareActivateModel> datas) {
        healthCareActivateModelList = datas;
        List<String> listName = new ArrayList<>();
        for(HealthCareActivateModel data: datas){
            listName.add(data.name);
        }
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, listName);
        spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        spnActType.setAdapter(spinnerArrayAdapter);
    }

    @Override
    public void resetTextField() {
        mDateFrom.setText("choose date");
        edtInfo.setText("");
    }

    @Override
    public void showTempList(List<HealthCareActivateModel> datas) {
        ll_containList.setVisibility(View.VISIBLE);
        adapter.setListNews(datas);
        rvList.setAdapter(adapter);
    }

    @Override
    public void hideList() {
        ll_containList.setVisibility(View.GONE);
    }

}
