package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 12/18/17.
 */

public class ServiceModel {
    private String title;
    public ServiceModel() {
    }

    public ServiceModel(String title) {
        this.title = title;
    }
    public String getTitle() {
        return title;
    }

    public void setTitle(String name) {
        this.title = name;
    }
}
