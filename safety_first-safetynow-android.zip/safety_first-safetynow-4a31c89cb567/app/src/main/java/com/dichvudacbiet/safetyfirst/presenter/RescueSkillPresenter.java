
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.model.FirstAid;
import com.dichvudacbiet.safetyfirst.model.NationalModel;
import com.dichvudacbiet.safetyfirst.model.RescueSkillModel;
import com.dichvudacbiet.safetyfirst.model.network.CountryRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.view.RescueSkillView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RescueSkillPresenter extends BasePresenter<RescueSkillView> {

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {
            Call<FirstAid> call = ApiService.getClient().getfirstAid(PrefUtil.getTokenInfo() , Session.COUNTRY_CODE);
            call.enqueue(new Callback<FirstAid>() {
                @Override
                public void onResponse(Call<FirstAid> call, Response<FirstAid> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<RescueSkillModel> respondData =  response.body().data;
                            getView().setData(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        //Utility.showSnackBar(RegisterActivity.this, findViewById(android.R.id.content)  ,"Lỗi kết nối dữ liệu" );
                    }

                }
                @Override
                public void onFailure(Call<FirstAid> call, Throwable t) {
                    //Utility.showSnackBar(RegisterActivity.this, findViewById(android.R.id.content)  ,"Lỗi kết nối dữ liệu" );
                }
            });
        }
    }


    public void onNewsClicked(RescueSkillModel news, int position) {
        if (isViewAttached()) {
            getView().showDetail(news.content);

        }
    }

    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
