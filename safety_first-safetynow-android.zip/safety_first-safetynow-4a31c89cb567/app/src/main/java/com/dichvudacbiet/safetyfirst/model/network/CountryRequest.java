package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.NationalModel;

import java.util.ArrayList;

public class CountryRequest {

    public String success;
    public ArrayList<NationalModel> data;
}