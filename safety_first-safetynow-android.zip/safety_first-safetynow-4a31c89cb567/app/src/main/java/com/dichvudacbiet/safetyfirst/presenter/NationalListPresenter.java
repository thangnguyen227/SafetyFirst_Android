
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.model.NationalModel;
import com.dichvudacbiet.safetyfirst.model.network.CountryRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.view.NationalListView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class NationalListPresenter extends BasePresenter<NationalListView> {

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    private void loadData() {
        if (isViewAttached()) {

            Call<CountryRequest> call = ApiService.getClient().getCountry(PrefUtil.getTokenInfo());
            call.enqueue(new Callback<CountryRequest>() {
                @Override
                public void onResponse(Call<CountryRequest> call, Response<CountryRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            ArrayList<NationalModel> respondData =  response.body().data;
                            getView().setData(respondData);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        //Utility.showSnackBar(RegisterActivity.this, findViewById(android.R.id.content)  ,"Lỗi kết nối dữ liệu" );
                    }

                }
                @Override
                public void onFailure(Call<CountryRequest> call, Throwable t) {
                    //Utility.showSnackBar(RegisterActivity.this, findViewById(android.R.id.content)  ,"Lỗi kết nối dữ liệu" );
                }
            });
        }
    }

    public void onNewsClicked(NationalModel news, int position) {
        if (isViewAttached()) {
            getView().showListData(news);
        }
    }
    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
