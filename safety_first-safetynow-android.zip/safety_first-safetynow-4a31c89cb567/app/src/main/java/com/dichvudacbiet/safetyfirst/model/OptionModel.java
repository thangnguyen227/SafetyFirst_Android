package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 01/02/18.
 */

public class OptionModel {
    public int id;
    public String text;
}
