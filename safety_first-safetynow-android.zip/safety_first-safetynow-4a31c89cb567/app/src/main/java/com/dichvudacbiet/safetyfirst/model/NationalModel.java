package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 12/18/17.
 */

public class NationalModel {
    public int id;
    public String name;
}
