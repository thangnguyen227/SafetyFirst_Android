package com.dichvudacbiet.safetyfirst.model.network;

/**
 * Created by khant on 11/03/2018.
 */

public class HealthCareUpdateRequest {
    public int id;
    public int activity_id;
    public String plain_text;
    public String date_time;
    public String time;
    public String info;
    public HealthCareUpdateRequest(int id, String plain_text, String date_time, String info ){
        this.id = id;
        this.plain_text = plain_text;
        this.date_time = date_time;
        this.info = info;
    }

}
