package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.PhoneBookModel;

import java.util.List;

public class PhoneBookRequest {

    public int status;
    public List<PhoneBookModel> data;

}