package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by khant on 30/03/2018.
 */

public class SosModel {
    public int id;
    public String content;

    public SosModel(int id, String content) {
        this.id = id;
        this.content = content;
    }
}
