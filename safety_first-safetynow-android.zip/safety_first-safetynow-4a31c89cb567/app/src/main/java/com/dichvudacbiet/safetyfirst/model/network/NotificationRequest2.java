package com.dichvudacbiet.safetyfirst.model.network;

import com.dichvudacbiet.safetyfirst.model.NotificationModel;

public class NotificationRequest2 {

    public String success;
    public NotificationModel data;
}