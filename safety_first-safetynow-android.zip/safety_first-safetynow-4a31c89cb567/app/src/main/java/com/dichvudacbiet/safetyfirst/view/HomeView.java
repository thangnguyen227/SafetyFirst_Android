
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.CountryEmergencyNumber;
import com.dichvudacbiet.safetyfirst.model.PhoneBookModel;
import com.dichvudacbiet.safetyfirst.model.network.CountryEmerNumByCountryRequest;

import java.util.List;

public interface HomeView extends BaseView {
    void showContactInfoPage();
    void callHotLine(String phone);
    void callSupport();
    void callService();
    void callNotify();
    void callProfile();
    void showRescueSkill();
    void showInfo();
    void showUnreadNotifiCount(int count);
    void getCountryCode(String code);
    void getPhoneCountry(List<PhoneBookModel> data);
//    void getCountry(List<CountryEmerNumByCountryRequest.EmergencyNumber> data);
    void getCountry(List<CountryEmergencyNumber> data);
}
