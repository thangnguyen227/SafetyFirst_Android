
package com.dichvudacbiet.safetyfirst.presenter;

import com.dichvudacbiet.safetyfirst.model.SupportModel;
import com.dichvudacbiet.safetyfirst.model.VaccinInfoModel;
import com.dichvudacbiet.safetyfirst.model.network.VaccinModelPostRequest;
import com.dichvudacbiet.safetyfirst.model.network.VaccinModelRequest;
import com.dichvudacbiet.safetyfirst.service.ApiService;
import com.dichvudacbiet.safetyfirst.util.PrefUtil;
import com.dichvudacbiet.safetyfirst.util.Session;
import com.dichvudacbiet.safetyfirst.view.CreateVaccinScheduleView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CreateVaccinSchedulePresenter extends BasePresenter<CreateVaccinScheduleView> {

    List<VaccinInfoModel> vaccinInfoModels;

    @Override
    public void onNewViewStateInstance() {
        if (isViewAttached()) {
            loadData();
        }
    }

    public CreateVaccinSchedulePresenter(List<VaccinInfoModel> list){
        vaccinInfoModels = list;
    }

    private void loadData() {
        if (isViewAttached()) {
            getView().setData(vaccinInfoModels);
//            Call<VaccinRequest> call = ApiService.getClient().getSupportVaccinationInfoList(PrefUtil.getTokenInfo());
//            call.enqueue(new Callback<VaccinRequest>() {
//                @Override
//                public void onResponse(Call<VaccinRequest> call, Response<VaccinRequest> response) {
//
//                    if (response.isSuccessful()) {
//                        //RC4
//                        try {
//                            ArrayList<VaccinModel> respondData =  response.body().data;
//                            getView().setData(respondData);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//
//                    }else{
//                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
//                    }
//                }
//                @Override
//                public void onFailure(Call<VaccinRequest> call, Throwable t) {
//                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
//                }
//            });
        }
    }

    public void updateVaccinInfo(List<VaccinInfoModel> arr){

            Object data = VaccinModelRequest.newBuilder()
                    .name(Session.vaccinModel.fullname)
                    .birthday(Session.vaccinModel.birth_date)
                    .birth_height(Session.vaccinModel.birth_height)
                    .birth_weight(Session.vaccinModel.birth_weight).vaccinations(arr).build();
            Call<VaccinModelRequest> call = ApiService.getClient().postUpdateVaccinInfo(String.valueOf(Session.vaccinModel.id),PrefUtil.getTokenInfo() , data);
            call.enqueue(new Callback<VaccinModelRequest>() {
                @Override
                public void onResponse(Call<VaccinModelRequest> call, Response<VaccinModelRequest> response) {

                    if (response.isSuccessful()) {
                        //RC4
                        try {
                            getView().showMessage("Thành công" , false);
                            getView().navigateBack();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }else{
                        getView().showMessage("Lỗi kết nối dữ liệu" , false);
                    }

                }
                @Override
                public void onFailure(Call<VaccinModelRequest> call, Throwable t) {
                    getView().showMessage("Lỗi kết nối dữ liệu" , false);
                }
            });

    }

//    private boolean isCheckItem(List<VaccinInfoModel> arr){
//        int i = 0;
//        for (VaccinInfoModel ob: arr){
//            if(ob.isChoose){
//               i++;
//            }
//        }
//        if(i <= 0){
//            getView().showMessage("Bạn phải chọn ít nhất 1 lịch tiêm chủng!", false);
//            return false;
//        }
//        return true;
//    }

    public void onNewsClicked(SupportModel news, int position) {
        if (isViewAttached()) {
//            getView().showNational(position);
        }
    }
    public void onBackPressed() {
        if (isViewAttached()) {
            getView().navigateBack();
        }
    }
}
