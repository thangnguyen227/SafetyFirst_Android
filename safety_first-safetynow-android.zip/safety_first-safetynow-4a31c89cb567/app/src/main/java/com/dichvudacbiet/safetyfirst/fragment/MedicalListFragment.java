
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.MedicalListAdapter;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.model.MedicalModel;
import com.dichvudacbiet.safetyfirst.presenter.MedicalListPresenter;
import com.dichvudacbiet.safetyfirst.view.MedicalListView;

import java.util.List;


public class MedicalListFragment extends BaseFragment<MedicalListView, MedicalListPresenter>
        implements MedicalListView, View.OnClickListener , RecyclerViewOnItemClickedListener<MedicalModel> {

    private RecyclerView rvList;
    private MedicalListAdapter adapter;
    private TextView mToolbarTitle;
    private int mPos;
    private int mCountryId;

    public static MedicalListFragment newInstance(int pos,int country_id) {
        Bundle args = new Bundle();
        args.putInt("ID", country_id);
        args.putInt("POS", pos);
        MedicalListFragment fragment = new MedicalListFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_list_national;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mCountryId = getArguments().getInt("ID");
            mPos = getArguments().getInt("POS");
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);
        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.infomation_detail));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //
        adapter = new MedicalListAdapter();
        adapter.setOnItemClickListener(this);
        rvList = (RecyclerView) view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rvList.setAdapter(adapter);
    }

    @NonNull
    @Override
    public MedicalListPresenter createPresenter() {
        return new MedicalListPresenter(mPos,mCountryId);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;

        }
    }


    @Override
    public void navigateBack() {
        getFragmentManager().popBackStack();
    }



    @Override
    public void setData(List<MedicalModel> listNews) {
        adapter.setListNews(listNews);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void openMedicalDetailView(MedicalModel medicalModel) {
        Fragment fragment = MedicalDetailFragment.newInstance(medicalModel);
        ((BaseActivity) getActivity()).pushOverlayFragment(fragment, true);
    }


    @Override
    public void onItemClicked(RecyclerView recyclerView, MedicalModel supportModel, int position) {
        getPresenter().onNewsClicked(supportModel);
    }
}
