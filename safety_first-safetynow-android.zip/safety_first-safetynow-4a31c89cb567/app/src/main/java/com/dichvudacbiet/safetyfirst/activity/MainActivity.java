package com.dichvudacbiet.safetyfirst.activity;

import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.widget.Toast;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.base.Constants;
import com.dichvudacbiet.safetyfirst.fragment.BaseFragment;
import com.dichvudacbiet.safetyfirst.fragment.HomeFragment;
import com.dichvudacbiet.safetyfirst.presenter.MainActivityPresenter;
import com.dichvudacbiet.safetyfirst.view.MainActivityView;

public class MainActivity extends BaseActivity<MainActivityView, MainActivityPresenter> implements
        MainActivityView{




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @NonNull
    @Override
    public MainActivityPresenter createPresenter() {
        return new MainActivityPresenter();
    }

    @Override
    public void onNewViewStateInstance() {
        getPresenter().onNewViewStateInstance();
    }

    @Override
    public void showHomePage() {
        pushFragment(new HomeFragment(), Constants.TransitionType.NONE, true);
    }

    @Override
    public void showLoginPage() {
        ActivityNavigationController.showLoginActivity(this);
    }

    @Override
    public void showMessage(int msgId, boolean success) {

    }

    @Override
    public void showMessage(String message, boolean success) {
        Toast.makeText(MainActivity.this , message , Toast.LENGTH_SHORT).show();
    }
    private Fragment getTopFragment() {
        return getSupportFragmentManager().findFragmentById(R.id.fragment_container);
    }
    @Override
    public void onBackPressed() {
        if (blockAllTouchEvent) {
            return;
        }

        BaseFragment overlayFragment = (BaseFragment) getTopFragment();
        if (overlayFragment != null && !overlayFragment.onBackPressed()) {
            popFragment();
            return;
        }

        super.onBackPressed();
    }
    private Fragment getTopOverlayFragment() {
        return getSupportFragmentManager().findFragmentById(R.id.fragment_overlay_container);
    }
}
