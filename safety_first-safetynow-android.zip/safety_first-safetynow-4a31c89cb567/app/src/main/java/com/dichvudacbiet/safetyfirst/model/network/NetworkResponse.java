package com.dichvudacbiet.safetyfirst.model.network;
/**
 * Created by ducth on 11/17/16.
 */

public class NetworkResponse {
    public int success;
    //public String data;
}
