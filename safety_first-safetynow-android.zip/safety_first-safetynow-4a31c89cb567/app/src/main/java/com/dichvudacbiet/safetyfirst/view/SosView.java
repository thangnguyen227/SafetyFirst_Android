
package com.dichvudacbiet.safetyfirst.view;


import com.dichvudacbiet.safetyfirst.model.SosModel;

import java.util.List;

public interface SosView extends BaseView {
    void navigateBack();
    void setData(List<SosModel> listNews);
}
