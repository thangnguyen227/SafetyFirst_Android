
package com.dichvudacbiet.safetyfirst.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by ducth on 11/17/16.
 */

public class DeviceInfo {
    @SerializedName("device_id")
    public String deviceId = "";
}
