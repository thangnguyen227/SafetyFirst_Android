package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 01/04/18.
 */

public class CoveringModel {
    public int id;
    public  int country_id;
    public  String name;
    public String full_name;
    public String info;
    public String within;
}
