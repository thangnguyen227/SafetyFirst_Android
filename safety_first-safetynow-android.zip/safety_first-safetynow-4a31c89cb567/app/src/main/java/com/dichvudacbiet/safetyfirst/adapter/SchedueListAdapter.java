
package com.dichvudacbiet.safetyfirst.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.ScheduleModel;
import com.dichvudacbiet.safetyfirst.util.AlertUtil;

import java.util.List;


public class SchedueListAdapter extends  RecyclerView.Adapter<SchedueListAdapter.MyViewHolder>
        implements View.OnClickListener {

    private List<ScheduleModel> moviesList;
    private RecyclerView rvList;
    private Activity mContext;
    protected RecyclerViewOnItemClickedListener<ScheduleModel> listener;


    public void setListNews(List<ScheduleModel> listNews) {
        this.moviesList = listNews;
    }

    public List<ScheduleModel> getListNews() {
        return moviesList;
    }

    public void setOnItemClickListener(RecyclerViewOnItemClickedListener<ScheduleModel> listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        View containingView = rvList.findContainingItemView(v);
        int position = rvList.getChildAdapterPosition(containingView);
        if (position == RecyclerView.NO_POSITION) {
            return;
        }

        if (listener != null) {
            listener.onItemClicked(rvList, moviesList.get(position), position);
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title , mName;
        public Button btn_review;
        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.item_support_tvTitle);
            mName = (TextView) view.findViewById(R.id.item_support_address);
            btn_review = view.findViewById(R.id.btn_review);
        }
    }


    public SchedueListAdapter(Activity context,List<ScheduleModel> moviesList) {
        mContext = context;
        this.moviesList = moviesList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_schedue, parent, false);
        itemView.setOnClickListener(this);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ScheduleModel movie = moviesList.get(position);
        holder.title.setText("Thời gian: "+movie.depart_date + " -> " + movie.return_date);
        holder.mName.setText("Kế hoạch đi : " + movie.destination.name);
        holder.btn_review.setOnClickListener(v->{
            AlertUtil.showScheduleDialog(mContext,movie);
        });
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        rvList = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        rvList = null;
        super.onDetachedFromRecyclerView(recyclerView);
    }

}
