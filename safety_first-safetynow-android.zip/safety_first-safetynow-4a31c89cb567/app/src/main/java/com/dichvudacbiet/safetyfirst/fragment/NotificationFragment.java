
package com.dichvudacbiet.safetyfirst.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.activity.BaseActivity;
import com.dichvudacbiet.safetyfirst.adapter.NotificationAdapter;
import com.dichvudacbiet.safetyfirst.adapter.RecyclerViewOnItemClickedListener;
import com.dichvudacbiet.safetyfirst.model.NotificationModel;
import com.dichvudacbiet.safetyfirst.presenter.NotificationPresenter;
import com.dichvudacbiet.safetyfirst.view.NotificationView;

import java.util.List;


public class NotificationFragment extends BaseFragment<NotificationView, NotificationPresenter>
        implements NotificationView, View.OnClickListener , RecyclerViewOnItemClickedListener<NotificationModel> {

    private RecyclerView rvList;
    private NotificationAdapter adapter;

    private TextView mToolbarTitle;

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_notification;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);
        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.notification_page));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //

        adapter = new NotificationAdapter(getActivity());
        adapter.setOnItemClickListener(this);
        rvList = (RecyclerView) view.findViewById(R.id.rvList);
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        rvList.setAdapter(adapter);
    }

    @NonNull
    @Override
    public NotificationPresenter createPresenter() {
        return new NotificationPresenter();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;

        }
    }


    @Override
    public void navigateBack() {
        getActivity().onBackPressed();
    }

    @Override
    public void showDetail(NotificationModel notificationModel) {
        Fragment fragment = NotificationDetailFragment.newInstance(notificationModel);
        ((BaseActivity) getActivity()).pushFragment(fragment, true);
    }

    @Override
    public void setData(List<NotificationModel> listNews) {
        adapter.setListNews(listNews);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClicked(RecyclerView recyclerView, NotificationModel notificationModel, int position) {

//        getPresenter().onNewsClicked(notificationModel, position);
    }


}
