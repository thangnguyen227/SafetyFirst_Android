
package com.dichvudacbiet.safetyfirst.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.base.Constants;
import com.dichvudacbiet.safetyfirst.model.MedicalModel;
import com.dichvudacbiet.safetyfirst.presenter.MedicalDetailPresenter;
import com.dichvudacbiet.safetyfirst.view.MedicalDetailView;

public class MedicalDetailFragment extends BaseFragment<MedicalDetailView, MedicalDetailPresenter>
        implements MedicalDetailView, View.OnClickListener  {

    private MedicalModel medicalModel;

    private TextView mToolbarTitle;

    private ImageView mIconDetail, btnCall, btnDirection;
    private TextView itemSupportTvTitle, itemAddress, itemPhone, itemDescription;


    public static MedicalDetailFragment newInstance(MedicalModel medicalModel) {
        Bundle args = new Bundle();
        args.putSerializable("medicalModel", medicalModel);

        MedicalDetailFragment fragment = new MedicalDetailFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected int getFragmentLayoutId() {
        return R.layout.fragment_medical_detail;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            medicalModel = (MedicalModel) getArguments().getSerializable("medicalModel");
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnBack = (ImageButton) view.findViewById(R.id.top_bar_btnLeft);
        btnBack.setImageResource(R.drawable.icon_back);
        btnBack.setOnClickListener(this);
        //
        mToolbarTitle = (TextView) view.findViewById(R.id.top_bar_tvTitle);
        mToolbarTitle.setText(getString(R.string.infomation_detail));
        mToolbarTitle.setVisibility(View.VISIBLE);
        //
        mIconDetail = view.findViewById(R.id.iv_detail);
        itemSupportTvTitle = view.findViewById(R.id.item_support_tvTitle);
        itemAddress = view.findViewById(R.id.item_address);
        itemPhone = view.findViewById(R.id.item_phone);
        itemDescription = view.findViewById(R.id.item_description);

        btnCall = view.findViewById(R.id.btn_call);
        btnDirection = view.findViewById(R.id.btn_direction);
    }

    @NonNull
    @Override
    public MedicalDetailPresenter createPresenter() {
        return new MedicalDetailPresenter(medicalModel);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_bar_btnLeft:
                getPresenter().onBackPressed();
                break;

        }
    }


    @Override
    public void navigateBack() {
        getFragmentManager().popBackStack();
    }



    @Override
    public void setData(MedicalModel data) {
        mToolbarTitle.setText(data.name);
        itemSupportTvTitle.setText(data.name);
        itemPhone.setText(getString(R.string.phone) + " " +data.contact_number);
        itemAddress.setText(getString(R.string.address) + " " + data.address);
        itemDescription.setText(TextUtils.isEmpty(data.description) ? getString(R.string.description) : (getString(R.string.description) + " " + data.description));
        itemDescription.setVisibility(TextUtils.isEmpty(data.description) ? View.GONE :View.VISIBLE);

        //Todo: change via data type
        mIconDetail.setImageResource(R.drawable.hospital);

        switch (data.type) {
            case Constants.SUPPORT_MEDICAL:
                mIconDetail.setImageResource(R.drawable.hospital); //1
                break;
            case Constants.SUPPORT_ASSOCIATION:    //8 - ton giao dia phuong
                mIconDetail.setImageResource(R.drawable.association);
                break;
            case Constants.SUPPORT_EMBASSY:             //5 - lanh su quan
                mIconDetail.setImageResource(R.drawable.embassy);
                break;
            case Constants.SUPPORT_TRAVEL_AGENT:
                mIconDetail.setImageResource(R.drawable.travel_detail); //4
                break;
            case Constants.SUPPORT_RESCUE_TEAM:
                mIconDetail.setImageResource(R.drawable.rescue); //3
                break;
            case Constants.SUPPORT_POLY_TEAM:
                mIconDetail.setImageResource(R.drawable.committee); //2
                break;
            case Constants.SUPPORT_RESTAURANT_SHOPPING:  //6- di san van hoa dia phuong
                mIconDetail.setImageResource(R.drawable.festival);
                break;
            case Constants.SUPPORT_FOOLS_STUFFS:
                mIconDetail.setImageResource(R.drawable.local_food); //7 - am thuc
                break;
        }

        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPresenter().onCallClicked();
            }
        });

        btnDirection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPresenter().onDirectionClicked();
            }
        });

    }

    @Override
    public void setCallPhone(MedicalModel callPhone) {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + callPhone.contact_number));
        startActivity(intent);
    }

    @Override
    public void setDirection(MedicalModel callPhone) {
        //Todo: call Maps
        Uri gmmIntentUri = Uri.parse("google.navigation:q=" + callPhone.address);
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);
    }
}
