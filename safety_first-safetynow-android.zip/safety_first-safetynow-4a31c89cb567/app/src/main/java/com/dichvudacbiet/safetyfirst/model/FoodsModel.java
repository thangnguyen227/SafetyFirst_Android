package com.dichvudacbiet.safetyfirst.model;

/**
 * Created by loi.doan on 01/04/18.
 */

public class FoodsModel {
    public  String name;
    public String info;
}
