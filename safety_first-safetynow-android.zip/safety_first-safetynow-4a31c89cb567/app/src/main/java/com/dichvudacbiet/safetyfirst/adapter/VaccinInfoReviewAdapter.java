
package com.dichvudacbiet.safetyfirst.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dichvudacbiet.safetyfirst.R;
import com.dichvudacbiet.safetyfirst.model.VaccinModel;

import java.util.List;


public class VaccinInfoReviewAdapter extends  RecyclerView.Adapter<VaccinInfoReviewAdapter.MyViewHolder>
        implements View.OnClickListener {
    private Activity mContext;
    private List<VaccinModel> vaccinList;
    private RecyclerView rvList;
    protected RecyclerViewOnItemClickedListener<VaccinModel> listener;

    public void setListNews(List<VaccinModel> listNews) {
        this.vaccinList = listNews;
    }

    public List<VaccinModel> getListNews() {
        return vaccinList;
    }

    public void setOnItemClickListener(RecyclerViewOnItemClickedListener<VaccinModel> listener) {
        this.listener = listener;
    }

    public VaccinInfoReviewAdapter(Activity context, List<VaccinModel> healthModelList) {
        mContext = context;
        this.vaccinList = healthModelList;
    }

    @Override
    public void onClick(View v) {
        View containingView = rvList.findContainingItemView(v);
        int position = rvList.getChildAdapterPosition(containingView);
        if (position == RecyclerView.NO_POSITION) {
            return;
        }

        if (listener != null) {
            listener.onItemClicked(rvList, vaccinList.get(position), position);
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView mName,mGender,mBirthday;

        public MyViewHolder(View view) {
            super(view);
            mName = view.findViewById(R.id.tv_name);
            mGender = view.findViewById(R.id.tv_gender);
            mBirthday = view.findViewById(R.id.tv_birthday);
        }
    }




    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_vaccin_info_review, parent, false);
        itemView.setOnClickListener(this);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        VaccinModel vaccin = vaccinList.get(position);
        holder.mName.setText(mContext.getString(R.string.name) + " " +vaccin.fullname);
        String gender;
        if(vaccin.gender == 0)
            gender = mContext.getString(R.string.male);
        else gender = mContext.getString(R.string.female);
        holder.mGender.setText(mContext.getString(R.string.gender) + " " +gender);
        holder.mBirthday.setText(mContext.getString(R.string.birthday) + " " + vaccin.birth_date);


    }

    @Override
    public int getItemCount() {
        return vaccinList.size();
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        rvList = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        rvList = null;
        super.onDetachedFromRecyclerView(recyclerView);
    }

}
